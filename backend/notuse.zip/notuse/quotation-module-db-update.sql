-- =====================================================
-- Quotation Module DB Update
-- Supports multi-row quotation items, product price fetch,
-- automatic totals, preview, and PDF download.
-- MySQL 8+
-- =====================================================

DELIMITER $$

DROP PROCEDURE IF EXISTS add_column_if_missing $$
CREATE PROCEDURE add_column_if_missing(
    IN p_table_name VARCHAR(64),
    IN p_column_name VARCHAR(64),
    IN p_column_definition TEXT
)
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_schema = DATABASE()
          AND table_name = p_table_name
          AND column_name = p_column_name
    ) THEN
        SET @sql_text = CONCAT('ALTER TABLE `', p_table_name, '` ADD COLUMN ', p_column_definition);
        PREPARE stmt FROM @sql_text;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END $$

DROP PROCEDURE IF EXISTS add_index_if_missing $$
CREATE PROCEDURE add_index_if_missing(
    IN p_table_name VARCHAR(64),
    IN p_index_name VARCHAR(64),
    IN p_index_definition TEXT
)
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.statistics
        WHERE table_schema = DATABASE()
          AND table_name = p_table_name
          AND index_name = p_index_name
    ) THEN
        SET @sql_text = CONCAT('ALTER TABLE `', p_table_name, '` ADD INDEX `', p_index_name, '` ', p_index_definition);
        PREPARE stmt FROM @sql_text;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END $$

DELIMITER ;

-- Products must expose selling_price for quotation item price fetch.
CALL add_column_if_missing('products', 'selling_price', '`selling_price` DECIMAL(12,2) DEFAULT 0 AFTER `purchase_price`');

-- Quotation master stores header, customer, workflow status, and calculated totals.
-- customer_id is added nullable if missing so old rows do not block migration.
CALL add_column_if_missing('quotation_master', 'valid_until', '`valid_until` DATE AFTER `quotation_date`');
CALL add_column_if_missing('quotation_master', 'customer_id', '`customer_id` INT AFTER `valid_until`');
CALL add_column_if_missing('quotation_master', 'prepared_by_employee_id', '`prepared_by_employee_id` INT AFTER `customer_id`');
CALL add_column_if_missing('quotation_master', 'requirement_details', '`requirement_details` TEXT AFTER `prepared_by_employee_id`');
CALL add_column_if_missing('quotation_master', 'total_amount', '`total_amount` DECIMAL(12,2) DEFAULT 0 AFTER `requirement_details`');
CALL add_column_if_missing('quotation_master', 'discount_amount', '`discount_amount` DECIMAL(12,2) DEFAULT 0 AFTER `total_amount`');
CALL add_column_if_missing('quotation_master', 'tax_amount', '`tax_amount` DECIMAL(12,2) DEFAULT 0 AFTER `discount_amount`');
CALL add_column_if_missing('quotation_master', 'net_amount', '`net_amount` DECIMAL(12,2) DEFAULT 0 AFTER `tax_amount`');
CALL add_column_if_missing('quotation_master', 'quotation_status', '`quotation_status` ENUM(''DRAFT'',''SUBMITTED'',''APPROVED'',''REJECTED'',''EXPIRED'',''CONVERTED'') DEFAULT ''DRAFT'' AFTER `net_amount`');
CALL add_column_if_missing('quotation_master', 'approval_request_id', '`approval_request_id` INT AFTER `quotation_status`');
CALL add_column_if_missing('quotation_master', 'revised_from_quotation_id', '`revised_from_quotation_id` INT AFTER `approval_request_id`');
CALL add_column_if_missing('quotation_master', 'revision_no', '`revision_no` INT DEFAULT 0 AFTER `revised_from_quotation_id`');
CALL add_column_if_missing('quotation_master', 'approved_date', '`approved_date` DATE AFTER `revision_no`');
CALL add_column_if_missing('quotation_master', 'remarks', '`remarks` TEXT AFTER `approved_date`');
CALL add_column_if_missing('quotation_master', 'created_at', '`created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP');
CALL add_column_if_missing('quotation_master', 'updated_at', '`updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP');

-- Create quotation_items if it is missing.
CREATE TABLE IF NOT EXISTS quotation_items (
    quotation_item_id INT AUTO_INCREMENT PRIMARY KEY,
    quotation_id INT NOT NULL,
    product_id INT,
    item_name VARCHAR(200),
    description TEXT,
    qty DECIMAL(10,2) NOT NULL DEFAULT 1,
    selling_price DECIMAL(12,2) NOT NULL DEFAULT 0,
    discount_amount DECIMAL(12,2) DEFAULT 0,
    tax_percent DECIMAL(5,2) DEFAULT 0,
    tax_amount DECIMAL(12,2) DEFAULT 0,
    amount DECIMAL(12,2) NOT NULL DEFAULT 0
);

-- If quotation_items already exists but was incomplete, align it with the new module.
CALL add_column_if_missing('quotation_items', 'quotation_id', '`quotation_id` INT NOT NULL AFTER `quotation_item_id`');
CALL add_column_if_missing('quotation_items', 'product_id', '`product_id` INT AFTER `quotation_id`');
CALL add_column_if_missing('quotation_items', 'item_name', '`item_name` VARCHAR(200) AFTER `product_id`');
CALL add_column_if_missing('quotation_items', 'description', '`description` TEXT AFTER `item_name`');
CALL add_column_if_missing('quotation_items', 'qty', '`qty` DECIMAL(10,2) NOT NULL DEFAULT 1 AFTER `description`');
CALL add_column_if_missing('quotation_items', 'selling_price', '`selling_price` DECIMAL(12,2) NOT NULL DEFAULT 0 AFTER `qty`');
CALL add_column_if_missing('quotation_items', 'discount_amount', '`discount_amount` DECIMAL(12,2) DEFAULT 0 AFTER `selling_price`');
CALL add_column_if_missing('quotation_items', 'tax_percent', '`tax_percent` DECIMAL(5,2) DEFAULT 0 AFTER `discount_amount`');
CALL add_column_if_missing('quotation_items', 'tax_amount', '`tax_amount` DECIMAL(12,2) DEFAULT 0 AFTER `tax_percent`');
CALL add_column_if_missing('quotation_items', 'amount', '`amount` DECIMAL(12,2) NOT NULL DEFAULT 0 AFTER `tax_amount`');

-- Helpful indexes for quotation list/detail and item lookup.
CALL add_index_if_missing('quotation_master', 'idx_quotation_customer', '(`customer_id`)');
CALL add_index_if_missing('quotation_master', 'idx_quotation_status', '(`quotation_status`)');
CALL add_index_if_missing('quotation_master', 'idx_quotation_revision', '(`revised_from_quotation_id`, `revision_no`)');
CALL add_index_if_missing('quotation_items', 'idx_quotation_items_quotation', '(`quotation_id`)');
CALL add_index_if_missing('quotation_items', 'idx_quotation_items_product', '(`product_id`)');

-- Add foreign keys only if your existing data is clean.
-- If old rows contain invalid customer_id/product_id values, clean data first, then run these manually.
-- ALTER TABLE quotation_master
--     ADD CONSTRAINT fk_quotation_customer
--     FOREIGN KEY (customer_id) REFERENCES customers(customer_id);
-- ALTER TABLE quotation_items
--     ADD CONSTRAINT fk_quotation_items_quotation
--     FOREIGN KEY (quotation_id) REFERENCES quotation_master(quotation_id)
--     ON DELETE CASCADE;
-- ALTER TABLE quotation_items
--     ADD CONSTRAINT fk_quotation_items_product
--     FOREIGN KEY (product_id) REFERENCES products(product_id);

-- Ensure quotation document number series exists.
INSERT INTO number_series (module_code, prefix, financial_year, next_number, padding_length, status)
SELECT 'QUOTATION', 'QUO', NULL, 1, 5, 1
WHERE NOT EXISTS (
    SELECT 1
    FROM number_series
    WHERE module_code = 'QUOTATION'
      AND financial_year IS NULL
);

DROP PROCEDURE IF EXISTS add_column_if_missing;
DROP PROCEDURE IF EXISTS add_index_if_missing;
