const { internetCustomerNumberSql } = require('./internetCustomerNumber');
const connection = require('../connection');

const allowedStatuses = new Set(['OPEN', 'COMPLETED']);
const allowedComplainantTypes = new Set(['CATV', 'NET', 'CCTV', 'ANONYMOUS']);
const numberOrNull = value => Number.isFinite(Number(value)) && Number(value) > 0 ? Number(value) : null;
const textOrNull = value => String(value ?? '').trim() || null;
const userId = req => numberOrNull(req.res?.locals?.userId || req.res?.locals?.user_id || req.res?.locals?.id);

const ensureComplaintTables = async db => {
  await db.query(`
    CREATE TABLE IF NOT EXISTS cable_tv_complaints (
      complaint_id BIGINT AUTO_INCREMENT PRIMARY KEY,
      complaint_no VARCHAR(30) NOT NULL,
      complainant_type ENUM('CATV','NET','CCTV','ANONYMOUS') NOT NULL DEFAULT 'CATV',
      cable_customer_id BIGINT NULL,
      internet_customer_id BIGINT NULL,
      service_customer_id INT NULL,
      anonymous_name VARCHAR(150) NULL,
      anonymous_mobile VARCHAR(20) NULL,
      reported_mobile VARCHAR(20) NULL,
      anonymous_address VARCHAR(500) NULL,
      complaint_subject VARCHAR(250) NULL,
      nature_of_complaint VARCHAR(250) NOT NULL,
      complaint_description TEXT NULL,
      status ENUM('OPEN','IN_PROGRESS','HOLD','PENDING','COMPLETED') NOT NULL DEFAULT 'OPEN',
      assigned_employee_id INT NULL,
      registered_by_user_id INT NULL,
      registered_by_employee_id INT NULL,
      registered_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      completed_at DATETIME NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      UNIQUE KEY uk_cable_tv_complaint_no (complaint_no),
      INDEX idx_cable_tv_complaint_customer (cable_customer_id),
      INDEX idx_cable_tv_complaint_internet_customer (internet_customer_id),
      INDEX idx_cable_tv_complaint_service_customer (service_customer_id),
      INDEX idx_cable_tv_complaint_status (status),
      INDEX idx_cable_tv_complaint_assigned (assigned_employee_id),
      CONSTRAINT fk_cable_tv_complaint_customer FOREIGN KEY (cable_customer_id) REFERENCES cable_tv_customers(cable_customer_id),
      CONSTRAINT fk_cable_tv_complaint_service_customer FOREIGN KEY (service_customer_id) REFERENCES customers(customer_id),
      CONSTRAINT fk_cable_tv_complaint_assigned FOREIGN KEY (assigned_employee_id) REFERENCES employees(employee_id)
    )
  `);
  const [complaintTypeColumns] = await db.query(
    `SELECT COLUMN_NAME FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'cable_tv_complaints'
       AND COLUMN_NAME IN ('complainant_type', 'internet_customer_id', 'service_customer_id')`
  );
  const complaintTypeColumnNames = new Set(complaintTypeColumns.map(column => column.COLUMN_NAME));
  if (!complaintTypeColumnNames.has('complainant_type')) {
    await db.query(`ALTER TABLE cable_tv_complaints
      ADD COLUMN complainant_type ENUM('CATV','NET','CCTV','ANONYMOUS') NOT NULL DEFAULT 'CATV' AFTER complaint_no`);
    await db.query(`UPDATE cable_tv_complaints
      SET complainant_type = CASE WHEN cable_customer_id IS NULL THEN 'ANONYMOUS' ELSE 'CATV' END`);
  }
  if (!complaintTypeColumnNames.has('service_customer_id')) {
    await db.query('ALTER TABLE cable_tv_complaints ADD COLUMN service_customer_id INT NULL AFTER cable_customer_id');
    await db.query('ALTER TABLE cable_tv_complaints ADD INDEX idx_cable_tv_complaint_service_customer (service_customer_id)');
  }
  if (!complaintTypeColumnNames.has('internet_customer_id')) {
    await db.query('ALTER TABLE cable_tv_complaints ADD COLUMN internet_customer_id BIGINT NULL AFTER cable_customer_id');
    await db.query('ALTER TABLE cable_tv_complaints ADD INDEX idx_cable_tv_complaint_internet_customer (internet_customer_id)');
  }
  const [[reportedMobileColumn]] = await db.query(
    `SELECT 1 FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'cable_tv_complaints'
       AND COLUMN_NAME = 'reported_mobile' LIMIT 1`
  );
  if (!reportedMobileColumn) {
    await db.query('ALTER TABLE cable_tv_complaints ADD COLUMN reported_mobile VARCHAR(20) NULL AFTER anonymous_mobile');
  }
  const [[complaintSubjectColumn]] = await db.query(
    `SELECT 1 FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'cable_tv_complaints'
       AND COLUMN_NAME = 'complaint_subject' LIMIT 1`
  );
  if (!complaintSubjectColumn) {
    await db.query('ALTER TABLE cable_tv_complaints ADD COLUMN complaint_subject VARCHAR(250) NULL AFTER anonymous_address');
  }
  await db.query(`
    CREATE TABLE IF NOT EXISTS cable_tv_complaint_attempts (
      complaint_attempt_id BIGINT AUTO_INCREMENT PRIMARY KEY,
      complaint_id BIGINT NOT NULL,
      attempt_no INT NOT NULL,
      status ENUM('OPEN','IN_PROGRESS','HOLD','PENDING','COMPLETED') NOT NULL,
      assigned_employee_id INT NULL,
      start_time DATETIME NULL,
      end_time DATETIME NULL,
      reason TEXT NULL,
      remedy TEXT NULL,
      notes TEXT NULL,
      entered_by_user_id INT NULL,
      entered_by_employee_id INT NULL,
      entered_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_cable_tv_attempt_complaint (complaint_id),
      CONSTRAINT fk_cable_tv_attempt_complaint FOREIGN KEY (complaint_id) REFERENCES cable_tv_complaints(complaint_id),
      CONSTRAINT fk_cable_tv_attempt_employee FOREIGN KEY (assigned_employee_id) REFERENCES employees(employee_id)
    )
  `);
};

const resolveEmployeeId = async (db, req, requestedId) => {
  if (numberOrNull(requestedId)) return numberOrNull(requestedId);
  const tokenEmployeeId = numberOrNull(req.res?.locals?.employee_id);
  if (tokenEmployeeId) return tokenEmployeeId;
  const username = req.res?.locals?.username || req.res?.locals?.userName;
  if (!username) return null;
  const [[employee]] = await db.query(
    `SELECT employee_id FROM employees
     WHERE employee_code = ? OR email = ? OR CONCAT_WS(' ', first_name, last_name) = ?
     LIMIT 1`,
    [username, username, username]
  );
  return employee?.employee_id || null;
};

const complaintSelect = `
  SELECT c.*,
         GREATEST(0, DATEDIFF(COALESCE(c.completed_at, NOW()), c.registered_at)) AS age_days,
         COALESCE(CAST(customer.customer_code AS CHAR), ${internetCustomerNumberSql('internet_customer')}, CAST(service_customer.customer_id AS CHAR)) AS customer_code,
         COALESCE(customer.full_name, internet_customer.full_name,
           NULLIF(TRIM(CONCAT_WS(' ', service_customer.salutation, service_customer.customer_name)), '')) AS customer_name,
         COALESCE(customer.mobile_no, internet_customer.mobile_no, service_customer.phone) AS customer_mobile,
         COALESCE(customer.alternate_mobile_no, internet_customer.alternate_mobile_no, service_customer.alternate_phone) AS customer_alternate_mobile,
         CASE WHEN c.cable_customer_id IS NOT NULL
           THEN CONCAT_WS(', ', customer.door_no, street.street_name, area.area_name, location.location_name, customer.city, customer.pincode)
           WHEN c.internet_customer_id IS NOT NULL
           THEN CONCAT_WS(', ', internet_customer.door_no, internet_street.street_name, internet_area.area_name, internet_location.location_name, internet_customer.city, internet_customer.pincode)
           ELSE CONCAT_WS(', ', service_customer.address, service_customer.city_district, service_customer.state, service_customer.pincode)
         END AS customer_address,
         COALESCE(NULLIF(TRIM(CONCAT_WS(' ', assigned.first_name, assigned.last_name)), ''), assigned.employee_code) AS assigned_employee_name,
         COALESCE(NULLIF(TRIM(CONCAT_WS(' ', registered.first_name, registered.last_name)), ''), registered.employee_code, registered_user.username) AS registered_by_name
  FROM cable_tv_complaints c
  LEFT JOIN cable_tv_customers customer ON customer.cable_customer_id = c.cable_customer_id
  LEFT JOIN cable_streets street ON street.street_id = customer.street_id
  LEFT JOIN cable_areas area ON area.area_id = customer.area_id
  LEFT JOIN cable_locations location ON location.location_id = customer.location_id
  LEFT JOIN internet_customers internet_customer ON internet_customer.internet_customer_id = c.internet_customer_id
  LEFT JOIN cable_streets internet_street ON internet_street.street_id = internet_customer.street_id
  LEFT JOIN cable_areas internet_area ON internet_area.area_id = internet_customer.area_id
  LEFT JOIN cable_locations internet_location ON internet_location.location_id = internet_customer.location_id
  LEFT JOIN customers service_customer ON service_customer.customer_id = c.service_customer_id
  LEFT JOIN employees assigned ON assigned.employee_id = c.assigned_employee_id
  LEFT JOIN employees registered ON registered.employee_id = c.registered_by_employee_id
  LEFT JOIN users registered_user ON registered_user.user_id = c.registered_by_user_id`;

const getComplaints = async (req, res) => {
  try {
    const db = connection.promise();
    await ensureComplaintTables(db);
    const filters = [];
    const values = [];
    const status = String(req.query.status || '').toUpperCase();
    if (status === 'ACTIVE') filters.push("c.status IN ('OPEN', 'IN_PROGRESS')");
    if (status === 'OPEN') filters.push("c.status <> 'COMPLETED'");
    else if (allowedStatuses.has(status)) { filters.push('c.status = ?'); values.push(status); }
    if (numberOrNull(req.query.assigned_employee_id)) {
      filters.push('c.assigned_employee_id = ?');
      values.push(numberOrNull(req.query.assigned_employee_id));
    }
    if (textOrNull(req.query.search)) {
      const search = `%${textOrNull(req.query.search)}%`;
      filters.push(`(c.complaint_no LIKE ? OR customer.customer_code LIKE ? OR customer.full_name LIKE ?
        OR ${internetCustomerNumberSql('internet_customer')} LIKE ? OR internet_customer.full_name LIKE ?
        OR service_customer.customer_name LIKE ? OR service_customer.phone LIKE ?
        OR c.anonymous_name LIKE ? OR c.anonymous_mobile LIKE ? OR c.nature_of_complaint LIKE ?)`);
      values.push(search, search, search, search, search, search, search, search, search, search);
    }
    const [rows] = await db.query(
      `${complaintSelect} ${filters.length ? `WHERE ${filters.join(' AND ')}` : ''}
       ORDER BY age_days DESC, c.registered_at ASC, c.complaint_id ASC`,
      values
    );
    return res.json(rows);
  } catch (error) {
    return res.status(500).json({ message: 'Complaint list could not be loaded', error: error.message });
  }
};

const getComplaintReport = async (req, res) => {
  try {
    const db = connection.promise();
    await ensureComplaintTables(db);
    const startDate = String(req.query.start_date || '').trim();
    const endDate = String(req.query.end_date || '').trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(startDate) || !/^\d{4}-\d{2}-\d{2}$/.test(endDate)) {
      return res.status(400).json({ message: 'Start date and end date are required' });
    }
    if (endDate < startDate) {
      return res.status(400).json({ message: 'End date cannot be before start date' });
    }

    const filters = ['c.registered_at >= ?', 'c.registered_at < DATE_ADD(?, INTERVAL 1 DAY)'];
    const values = [startDate, endDate];
    const status = String(req.query.status || '').toUpperCase();
    if (allowedStatuses.has(status)) {
      filters.push('c.status = ?');
      values.push(status);
    }
    const technicianId = numberOrNull(req.query.assigned_employee_id);
    if (technicianId) {
      filters.push('c.assigned_employee_id = ?');
      values.push(technicianId);
    }

    const [rows] = await db.query(
      `${complaintSelect} WHERE ${filters.join(' AND ')}
       ORDER BY c.registered_at DESC, c.complaint_id DESC`,
      values
    );
    return res.json({ rows, total_records: rows.length });
  } catch (error) {
    return res.status(500).json({ message: 'Complaint report could not be loaded', error: error.message });
  }
};

const getComplaintCustomers = async (req, res) => {
  try {
    const db = connection.promise();
    await ensureComplaintTables(db);
    const type = String(req.query.type || 'CATV').toUpperCase();
    const requestedCustomerId = numberOrNull(req.query.customer_id);
    const sendCustomers = rows => res.json(requestedCustomerId
      ? rows.filter(row => Number(row.customer_id) === requestedCustomerId)
      : rows);
    if (!['CATV', 'NET', 'CCTV'].includes(type)) {
      return res.status(400).json({ message: 'Customer type must be CATV, Net or CCTV' });
    }
    if (type === 'CATV') {
      const [rows] = await db.query(
        `SELECT c.cable_customer_id AS customer_id, c.customer_code,
                c.full_name AS customer_name, c.mobile_no AS phone,
                c.alternate_mobile_no AS alternate_phone,
                CONCAT_WS(', ', c.door_no, s.street_name, a.area_name, l.location_name, c.city, c.pincode) AS address
         FROM cable_tv_customers c
         LEFT JOIN cable_streets s ON s.street_id = c.street_id
         LEFT JOIN cable_areas a ON a.area_id = c.area_id
         LEFT JOIN cable_locations l ON l.location_id = c.location_id
         ORDER BY c.full_name`
      );
      return sendCustomers(rows);
    }
    if (type === 'NET') {
      const [rows] = await db.query(
        `SELECT c.internet_customer_id AS customer_id,
                ${internetCustomerNumberSql('c')} AS customer_code,
                c.full_name AS customer_name, c.mobile_no AS phone,
                c.alternate_mobile_no AS alternate_phone,
                CONCAT_WS(', ', c.door_no, s.street_name, a.area_name, l.location_name, c.city, c.pincode) AS address
         FROM internet_customers c
         LEFT JOIN cable_streets s ON s.street_id = c.street_id
         LEFT JOIN cable_areas a ON a.area_id = c.area_id
         LEFT JOIN cable_locations l ON l.location_id = c.location_id
         ORDER BY c.full_name`
      );
      return sendCustomers(rows);
    }
    const [rows] = await db.query(
      `SELECT customer_id, customer_id AS customer_code,
              NULLIF(TRIM(CONCAT_WS(' ', salutation, customer_name)), '') AS customer_name,
              phone, alternate_phone,
              CONCAT_WS(', ', address, city_district, state, pincode) AS address
       FROM customers WHERE is_active = 1 ORDER BY customer_name`
    );
    return sendCustomers(rows);
  } catch (error) {
    return res.status(500).json({ message: 'Complaint customers could not be loaded', error: error.message });
  }
};

const getComplaintById = async (req, res) => {
  try {
    const db = connection.promise();
    await ensureComplaintTables(db);
    const complaintId = numberOrNull(req.params.complaintId);
    const [[complaint]] = await db.query(`${complaintSelect} WHERE c.complaint_id = ?`, [complaintId]);
    if (!complaint) return res.status(404).json({ message: 'Complaint not found' });
    const [attempts] = await db.query(
      `SELECT a.*,
              COALESCE(NULLIF(TRIM(CONCAT_WS(' ', assigned.first_name, assigned.last_name)), ''), assigned.employee_code) AS assigned_employee_name,
              COALESCE(NULLIF(TRIM(CONCAT_WS(' ', entered.first_name, entered.last_name)), ''), entered.employee_code, entered_user.username) AS entered_by_name
       FROM cable_tv_complaint_attempts a
       LEFT JOIN employees assigned ON assigned.employee_id = a.assigned_employee_id
       LEFT JOIN employees entered ON entered.employee_id = a.entered_by_employee_id
       LEFT JOIN users entered_user ON entered_user.user_id = a.entered_by_user_id
       WHERE a.complaint_id = ?
       ORDER BY a.attempt_no DESC, a.complaint_attempt_id DESC`,
      [complaintId]
    );
    return res.json({ ...complaint, attempts });
  } catch (error) {
    return res.status(500).json({ message: 'Complaint details could not be loaded', error: error.message });
  }
};

const addComplaint = async (req, res) => {
  const db = connection.promise();
  let transactionStarted = false;
  try {
    await ensureComplaintTables(db);
    const payload = req.body || {};
    const complainantType = String(payload.complainant_type || (payload.cable_customer_id ? 'CATV' : 'ANONYMOUS')).toUpperCase();
    const customerId = complainantType === 'CATV' ? numberOrNull(payload.cable_customer_id) : null;
    const internetCustomerId = complainantType === 'NET' ? numberOrNull(payload.internet_customer_id) : null;
    const serviceCustomerId = complainantType === 'CCTV' ? numberOrNull(payload.service_customer_id) : null;
    const anonymousName = textOrNull(payload.anonymous_name);
    const anonymousMobile = textOrNull(payload.anonymous_mobile);
    const subject = textOrNull(payload.subject);
    const nature = textOrNull(payload.nature_of_complaint);
    if (!allowedComplainantTypes.has(complainantType)) {
      return res.status(400).json({ message: 'Complaint type is invalid' });
    }
    if (complainantType === 'ANONYMOUS' && !anonymousName && !anonymousMobile) {
      return res.status(400).json({ message: 'Select a customer or enter anonymous caller details' });
    }
    if (complainantType === 'CATV' && !customerId) return res.status(400).json({ message: 'Select a CATV customer' });
    if (complainantType === 'NET' && !internetCustomerId) return res.status(400).json({ message: 'Select a Net customer' });
    if (complainantType === 'CCTV' && !serviceCustomerId) return res.status(400).json({ message: 'Select a CCTV customer' });
    if (!subject) return res.status(400).json({ message: 'Subject is required' });
    if (!nature) return res.status(400).json({ message: 'Nature of complaint is required' });
    if (customerId) {
      const [[customer]] = await db.query(
        'SELECT cable_customer_id FROM cable_tv_customers WHERE cable_customer_id = ? LIMIT 1',
        [customerId]
      );
      if (!customer) return res.status(400).json({ message: 'Selected customer was not found' });
    }
    if (serviceCustomerId) {
      const [[serviceCustomer]] = await db.query(
        'SELECT customer_id FROM customers WHERE customer_id = ? AND is_active = 1 LIMIT 1',
        [serviceCustomerId]
      );
      if (!serviceCustomer) return res.status(400).json({ message: 'Selected customer was not found' });
    }
    if (internetCustomerId) {
      const [[internetCustomer]] = await db.query(
        'SELECT internet_customer_id FROM internet_customers WHERE internet_customer_id = ? LIMIT 1',
        [internetCustomerId]
      );
      if (!internetCustomer) return res.status(400).json({ message: 'Selected Internet customer was not found' });
    }
    const registeredEmployeeId = await resolveEmployeeId(db, req);
    await db.beginTransaction();
    transactionStarted = true;
    const [[next]] = await db.query(
      `SELECT COALESCE(MAX(CAST(SUBSTRING_INDEX(complaint_no, '-', -1) AS UNSIGNED)), 0) + 1 AS next_no
       FROM cable_tv_complaints FOR UPDATE`
    );
    // Check inside the registration transaction, after the existing numbering lock.
    const customerColumn = customerId ? 'cable_customer_id'
      : internetCustomerId ? 'internet_customer_id' : serviceCustomerId ? 'service_customer_id' : null;
    if (customerColumn) {
      const [[pending]] = await db.query(
        `SELECT complaint_id, complaint_no, status FROM cable_tv_complaints
         WHERE ${customerColumn} = ? AND status <> 'COMPLETED'
         ORDER BY registered_at DESC, complaint_id DESC LIMIT 1 FOR UPDATE`,
        [customerId || internetCustomerId || serviceCustomerId]
      );
      if (pending) {
        await db.rollback();
        transactionStarted = false;
        return res.status(409).json({
          message: `This customer already has a pending complaint (${pending.complaint_no}, ${pending.status.replaceAll('_', ' ')}). Complete it before registering another complaint.`,
          code: 'CUSTOMER_COMPLAINT_PENDING', complaint_id: pending.complaint_id
        });
      }
    }
    const complaintNo = `CMP-${String(next.next_no).padStart(6, '0')}`;
    const [result] = await db.query(
      `INSERT INTO cable_tv_complaints
       (complaint_no, complainant_type, cable_customer_id, internet_customer_id, service_customer_id,
        anonymous_name, anonymous_mobile, reported_mobile, anonymous_address,
        complaint_subject, nature_of_complaint, complaint_description, status, registered_by_user_id, registered_by_employee_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'OPEN', ?, ?)`,
      [
        complaintNo, complainantType, customerId, internetCustomerId, serviceCustomerId,
        anonymousName, anonymousMobile, textOrNull(payload.reported_mobile), textOrNull(payload.anonymous_address),
        subject, nature, null, userId(req), registeredEmployeeId
      ]
    );
    await db.query(
      `INSERT INTO cable_tv_complaint_attempts
       (complaint_id, attempt_no, status, notes, entered_by_user_id, entered_by_employee_id)
       VALUES (?, 1, 'OPEN', ?, ?, ?)`,
      [result.insertId, textOrNull(payload.complaint_description) || 'Complaint registered', userId(req), registeredEmployeeId]
    );
    await db.commit();
    return res.status(201).json({ message: 'Complaint registered successfully', complaint_id: result.insertId, complaint_no: complaintNo });
  } catch (error) {
    if (transactionStarted) await db.rollback();
    return res.status(500).json({ message: 'Complaint registration failed', error: error.message });
  }
};

const addComplaintAttempt = async (req, res) => {
  const db = connection.promise();
  let transactionStarted = false;
  try {
    await ensureComplaintTables(db);
    const complaintId = numberOrNull(req.params.complaintId);
    const payload = req.body || {};
    const status = String(payload.status || '').toUpperCase();
    if (!complaintId || !allowedStatuses.has(status) || status === 'OPEN') {
      return res.status(400).json({ message: 'A valid complaint status is required' });
    }
    await db.beginTransaction();
    transactionStarted = true;
    const [[complaint]] = await db.query(
      'SELECT * FROM cable_tv_complaints WHERE complaint_id = ? FOR UPDATE',
      [complaintId]
    );
    if (!complaint) {
      await db.rollback(); transactionStarted = false;
      return res.status(404).json({ message: 'Complaint not found' });
    }
    if (complaint.status === 'COMPLETED') {
      await db.rollback(); transactionStarted = false;
      return res.status(409).json({ message: 'Completed complaints cannot be updated' });
    }
    const mappingType = String(payload.mapping_type || complaint.complainant_type || 'ANONYMOUS').toUpperCase();
    const customerId = mappingType === 'CATV'
      ? numberOrNull(payload.cable_customer_id) || complaint.cable_customer_id
      : complaint.cable_customer_id;
    const serviceCustomerId = ['NET', 'CCTV'].includes(mappingType)
      ? (mappingType === 'CCTV' ? numberOrNull(payload.service_customer_id) : null) || complaint.service_customer_id
      : complaint.service_customer_id;
    const internetCustomerId = mappingType === 'NET'
      ? numberOrNull(payload.internet_customer_id) || complaint.internet_customer_id
      : complaint.internet_customer_id;
    const assignedEmployeeId = await resolveEmployeeId(db, req, payload.assigned_employee_id || complaint.assigned_employee_id);
    const startTime = textOrNull(payload.start_time);
    const endTime = textOrNull(payload.end_time);
    if (!assignedEmployeeId) {
      await db.rollback(); transactionStarted = false;
      return res.status(400).json({ message: 'Assigned technician is required' });
    }
    if ((customerId || internetCustomerId || serviceCustomerId) && (!startTime || !endTime)) {
      await db.rollback(); transactionStarted = false;
      return res.status(400).json({ message: 'Start time and end time are required for customer complaints' });
    }
    if (startTime && endTime && new Date(endTime) < new Date(startTime)) {
      await db.rollback(); transactionStarted = false;
      return res.status(400).json({ message: 'End time cannot be before start time' });
    }
    const [[nextAttempt]] = await db.query(
      'SELECT COALESCE(MAX(attempt_no), 0) + 1 AS attempt_no FROM cable_tv_complaint_attempts WHERE complaint_id = ?',
      [complaintId]
    );
    const enteredEmployeeId = await resolveEmployeeId(db, req);
    await db.query(
      `INSERT INTO cable_tv_complaint_attempts
       (complaint_id, attempt_no, status, assigned_employee_id, start_time, end_time,
        reason, remedy, notes, entered_by_user_id, entered_by_employee_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        complaintId, nextAttempt.attempt_no, status, assignedEmployeeId, startTime, endTime,
        null, null, textOrNull(payload.description) || textOrNull(payload.notes),
        userId(req), enteredEmployeeId
      ]
    );
    await db.query(
      `UPDATE cable_tv_complaints
       SET complainant_type = ?, cable_customer_id = ?, internet_customer_id = ?, service_customer_id = ?,
           assigned_employee_id = ?, status = ?,
           completed_at = CASE WHEN ? = 'COMPLETED' THEN NOW() ELSE NULL END
       WHERE complaint_id = ?`,
      [mappingType, customerId, internetCustomerId, serviceCustomerId, assignedEmployeeId, status, status, complaintId]
    );
    await db.commit();
    return res.json({ message: status === 'COMPLETED' ? 'Complaint completed successfully' : 'Complaint attempt saved successfully' });
  } catch (error) {
    if (transactionStarted) await db.rollback();
    return res.status(500).json({ message: 'Complaint update failed', error: error.message });
  }
};

const completeComplaint = async (req, res) => {
  const id = Number(req.params.complaintId);
  if (!Number.isSafeInteger(id) || id <= 0) return res.status(400).json({ message: 'Invalid complaint ID' });
  const db = connection.promise();
  let started = false;
  try {
    await db.beginTransaction(); started = true;
    const [[complaint]] = await db.query('SELECT * FROM cable_tv_complaints WHERE complaint_id = ? FOR UPDATE', [id]);
    if (!complaint || complaint.status === 'COMPLETED') {
      await db.rollback(); started = false;
      return res.status(complaint ? 409 : 404).json({ message: complaint ? 'Complaint is already completed' : 'Complaint not found' });
    }
    const employeeId = await resolveEmployeeId(db, req);
    const [[next]] = await db.query('SELECT COALESCE(MAX(attempt_no), 0) + 1 AS attempt_no FROM cable_tv_complaint_attempts WHERE complaint_id = ?', [id]);
    await db.query(`INSERT INTO cable_tv_complaint_attempts
      (complaint_id, attempt_no, status, assigned_employee_id, notes, entered_by_user_id, entered_by_employee_id)
      VALUES (?, ?, 'COMPLETED', ?, 'Marked complete using Done', ?, ?)`,
      [id, next.attempt_no, complaint.assigned_employee_id, userId(req), employeeId]);
    await db.query("UPDATE cable_tv_complaints SET status = 'COMPLETED', completed_at = NOW() WHERE complaint_id = ?", [id]);
    await db.commit(); started = false;
    return res.json({ message: 'Complaint completed successfully' });
  } catch {
    if (started) await db.rollback();
    return res.status(500).json({ message: 'Complaint completion failed' });
  }
};

const deleteComplaint = async (req, res) => {
  const complaintId = Number(req.params.complaintId);
  if (!Number.isSafeInteger(complaintId) || complaintId <= 0) {
    return res.status(400).json({ message: 'Invalid complaint ID' });
  }
  const db = connection.promise();
  let transactionStarted = false;
  try {
    await db.beginTransaction();
    transactionStarted = true;
    const [rows] = await db.query('SELECT complaint_id FROM cable_tv_complaints WHERE complaint_id = ? FOR UPDATE', [complaintId]);
    if (!rows.length) {
      await db.rollback();
      transactionStarted = false;
      return res.status(404).json({ message: 'Complaint not found' });
    }
    await db.query('DELETE FROM cable_tv_complaint_attempts WHERE complaint_id = ?', [complaintId]);
    await db.query('DELETE FROM cable_tv_complaints WHERE complaint_id = ?', [complaintId]);
    await db.commit();
    transactionStarted = false;
    return res.json({ message: 'Complaint deleted successfully' });
  } catch (error) {
    if (transactionStarted) await db.rollback();
    return res.status(500).json({ message: 'Complaint deletion failed' });
  }
};

module.exports = {
  ensureComplaintTables, getComplaintCustomers, getComplaints,
  getComplaintReport, getComplaintById, addComplaint, addComplaintAttempt, completeComplaint, deleteComplaint
};
