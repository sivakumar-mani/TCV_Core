var $=(e,l=45)=>String(e??"-").replace(/[^\x20-\x7E]/g,"?").replace(/([\\()])/g,"\\$1").slice(0,l),j=e=>new TextEncoder().encode(e).length,k=(e,l)=>{let m=String(e??"-").trim().split(/\s+/).filter(Boolean),a=[],n="";return m.forEach(i=>{let d=n?`${n} ${i}`:i;d.length<=l?n=d:(n&&a.push(n),n=i)}),n&&a.push(n),a.length?a:["-"]};function C(e){let l=[],m=(o,t,r,s,c)=>{let g=$(s,70),w=c===void 0?o:c-g.length*r*.52;l.push(`BT /F1 ${r} Tf ${w.toFixed(2)} ${t} Td (${g}) Tj ET`)},a=(o,t,r,s)=>l.push(`${o} ${t} m ${r} ${s} l S`);m(40,800,18,e.title);let n=775;e.details.forEach(([o,t],r)=>{let s=r%2===0?40:310;r>0&&r%2===0&&(n-=18),m(s,n,9,`${o}: ${t??"-"}`)}),n-=30;let d=515/Math.max(e.columns.length,1),h=(e.columnWidths?.length===e.columns.length?e.columnWidths:null)||e.columns.map(()=>d),f=h.map((o,t)=>40+h.slice(0,t).reduce((r,s)=>r+s,0)),S=new Set(e.rightAlignedColumns||[]),y=new Set(e.wrappedColumns||[]);a(40,n+8,555,n+8),e.columns.forEach((o,t)=>m(f[t]+4,n-5,8,$(o,18),S.has(t)?f[t]+h[t]-4:void 0)),a(40,n-12,555,n-12),n-=28;for(let o of e.rows.slice(0,32)){let t=o.map((s,c)=>y.has(c)?k(s,Math.max(Math.floor((h[c]-8)/4.16),1)):[$(s,Math.max(Math.floor((h[c]-8)/4.16),1))]),r=Math.max(18,Math.max(...t.map(s=>s.length))*10+6);if(n-r<45)break;t.forEach((s,c)=>s.forEach((g,w)=>m(f[c]+4,n-w*10,8,g,S.has(c)?f[c]+h[c]-4:void 0))),n-=r,a(40,n+7,555,n+7)}let E=l.join(`
`)+`
`,p=["1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj","2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj","3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >> endobj","4 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj",`5 0 obj << /Length ${j(E)} >> stream
${E}endstream endobj`],u=`%PDF-1.4
`,R=[];p.forEach(o=>{R.push(j(u)),u+=`${o}
`});let W=j(u);u+=`xref
0 ${p.length+1}
0000000000 65535 f 
`,R.forEach(o=>u+=`${String(o).padStart(10,"0")} 00000 n 
`),u+=`trailer << /Size ${p.length+1} /Root 1 0 R >>
startxref
${W}
%%EOF`;let T=URL.createObjectURL(new Blob([u],{type:"application/pdf"})),b=document.createElement("a");b.href=T,b.download=e.filename.replace(/\s+/g,"-"),b.click(),URL.revokeObjectURL(T)}export{C as a};
