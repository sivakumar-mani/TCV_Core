import{a as p}from"./chunk-6LEBJHPE.js";function s(i,l,o){if(!l.length)return;let e=[i,...l].map(r=>r.map(d=>{let a=String(d??"");return/^\s*[=+@-]/.test(a)&&a!=="-"&&(a="'"+a),'"'+a.replace(/"/g,'""')+'"'}).join(",")).join(`\r
`),n=URL.createObjectURL(new Blob(["\uFEFF",e],{type:"text/csv;charset=utf-8"})),t=document.createElement("a");t.href=n,t.download=o,t.click(),URL.revokeObjectURL(n)}function h(i,l,o){if(!o.length)return!0;let e=window.open("","_blank","width=1200,height=800");if(!e)return!1;let n=t=>String(t??"").replace(/[&<>"']/g,r=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[r]);return p(e,`<!doctype html><html><head><title>${n(i)}</title><style>
    body{font-family:Arial,sans-serif;color:#111827;margin:24px}h1{font-size:22px}
    table{border-collapse:collapse;width:100%}th,td{border:1px solid #9ca3af;padding:8px;text-align:left;font-size:12px;overflow-wrap:anywhere}
    th{background:#e5e7eb}thead{display:table-header-group}tr{break-inside:avoid}
    @page{size:landscape;margin:12mm}
  </style></head><body><h1>${n(i)}</h1><p>Total Customers: ${o.length}</p>
    <table><thead><tr>${l.map(t=>`<th>${n(t)}</th>`).join("")}</tr></thead>
    <tbody>${o.map(t=>`<tr>${t.map(r=>`<td>${n(r)}</td>`).join("")}</tr>`).join("")}</tbody></table>
  </body></html>`),e.document.close(),e.focus(),e.print(),!0}export{s as a,h as b};
