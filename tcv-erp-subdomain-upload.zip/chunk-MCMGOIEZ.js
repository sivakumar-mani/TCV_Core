import{a as ce,b as me,c as fe,d as F,e as we,f as Nt,g as N,h as qe,i as nt,j as ot,k as rt,l as Rt,m as Ot,n as Ht,o as At,p as We,q as at,r as Kt}from"./chunk-XIDXAAQS.js";import{A as Bt,B as tt,E as Pt,F as X,K as Lt,L as Vt,M as it,O as Ve,Q as zt,a as Pe,aa as he,ba as Ft,d as et,da as ne,e as J,ea as Y,f as Le,g as Mt,o as Dt,p as Ge,q as je,r as $e}from"./chunk-ARMTD54Z.js";import{B as Ue,a as Ke,f as Qe,g as kt,k as Et}from"./chunk-H7QM6KD5.js";import{$ as ye,Ab as B,Ec as Oe,Fb as a,Gb as _,Hb as w,Hc as ie,Ib as P,Jb as W,Kb as Z,Lb as L,Mb as U,Mc as T,Nb as G,Nc as $,Ob as V,Pb as K,Qb as ae,Rb as O,Tb as p,Vc as Te,Wb as v,Wc as He,Xb as Q,Xc as le,Yb as m,Yc as Be,Z as Fe,Za as c,Zb as g,Zc as se,_ as oe,a as _e,b as ze,ba as pe,bc as Ye,cb as D,cc as de,cd as ue,da as R,db as Ne,ec as Me,fc as h,gc as ke,gd as Ae,hc as De,ia as y,ib as Ce,ic as xt,j as Se,ja as C,ka as x,ma as yt,mc as wt,nc as Tt,ob as S,oc as vt,pb as xe,qc as te,rb as k,rc as It,sb as re,sc as j,ta as Ct,tb as d,tc as ge,vc as St,ya as I,zc as Re}from"./chunk-XME5NHYV.js";var Qt=`
    .p-badge {
        display: inline-flex;
        border-radius: dt('badge.border.radius');
        align-items: center;
        justify-content: center;
        padding: dt('badge.padding');
        background: dt('badge.primary.background');
        color: dt('badge.primary.color');
        font-size: dt('badge.font.size');
        font-weight: dt('badge.font.weight');
        min-width: dt('badge.min.width');
        height: dt('badge.height');
    }

    .p-badge-dot {
        width: dt('badge.dot.size');
        min-width: dt('badge.dot.size');
        height: dt('badge.dot.size');
        border-radius: 50%;
        padding: 0;
    }

    .p-badge-circle {
        padding: 0;
        border-radius: 50%;
    }

    .p-badge-secondary {
        background: dt('badge.secondary.background');
        color: dt('badge.secondary.color');
    }

    .p-badge-success {
        background: dt('badge.success.background');
        color: dt('badge.success.color');
    }

    .p-badge-info {
        background: dt('badge.info.background');
        color: dt('badge.info.color');
    }

    .p-badge-warn {
        background: dt('badge.warn.background');
        color: dt('badge.warn.color');
    }

    .p-badge-danger {
        background: dt('badge.danger.background');
        color: dt('badge.danger.color');
    }

    .p-badge-contrast {
        background: dt('badge.contrast.background');
        color: dt('badge.contrast.color');
    }

    .p-badge-sm {
        font-size: dt('badge.sm.font.size');
        min-width: dt('badge.sm.min.width');
        height: dt('badge.sm.height');
    }

    .p-badge-lg {
        font-size: dt('badge.lg.font.size');
        min-width: dt('badge.lg.min.width');
        height: dt('badge.lg.height');
    }

    .p-badge-xl {
        font-size: dt('badge.xl.font.size');
        min-width: dt('badge.xl.min.width');
        height: dt('badge.xl.height');
    }
`;var bi=`
    ${Qt}

    /* For PrimeNG (directive)*/
    .p-overlay-badge {
        position: relative;
    }

    .p-overlay-badge > .p-badge {
        position: absolute;
        top: 0;
        inset-inline-end: 0;
        transform: translate(50%, -50%);
        transform-origin: 100% 0;
        margin: 0;
    }
`,_i={root:({instance:t})=>{let l=typeof t.value=="function"?t.value():t.value,e=typeof t.size=="function"?t.size():t.size,n=typeof t.badgeSize=="function"?t.badgeSize():t.badgeSize,i=typeof t.severity=="function"?t.severity():t.severity;return["p-badge p-component",{"p-badge-circle":et(l)&&String(l).length===1,"p-badge-dot":Pe(l),"p-badge-sm":e==="small"||n==="small","p-badge-lg":e==="large"||n==="large","p-badge-xl":e==="xlarge"||n==="xlarge","p-badge-info":i==="info","p-badge-success":i==="success","p-badge-warn":i==="warn","p-badge-danger":i==="danger","p-badge-secondary":i==="secondary","p-badge-contrast":i==="contrast"}]}},Ut=(()=>{class t extends he{name="badge";style=bi;classes=_i;static \u0275fac=(()=>{let e;return function(i){return(e||(e=I(t)))(i||t)}})();static \u0275prov=oe({token:t,factory:t.\u0275fac})}return t})();var Gt=new pe("BADGE_INSTANCE");var yi=(()=>{class t extends fe{$pcBadge=R(Gt,{optional:!0,skipSelf:!0})??void 0;bindDirectiveInstance=R(F,{self:!0});onAfterViewChecked(){this.bindDirectiveInstance.setAttrs(this.ptms(["host","root"]))}styleClass=ie();badgeSize=ie();size=ie();severity=ie();value=ie();badgeDisabled=ie(!1,{transform:T});_componentStyle=R(Ut);static \u0275fac=(()=>{let e;return function(i){return(e||(e=I(t)))(i||t)}})();static \u0275cmp=S({type:t,selectors:[["p-badge"]],hostVars:4,hostBindings:function(n,i){n&2&&(h(i.cn(i.cx("root"),i.styleClass())),de("display",i.badgeDisabled()?"none":null))},inputs:{styleClass:[1,"styleClass"],badgeSize:[1,"badgeSize"],size:[1,"size"],severity:[1,"severity"],value:[1,"value"],badgeDisabled:[1,"badgeDisabled"]},features:[te([Ut,{provide:Gt,useExisting:t},{provide:me,useExisting:t}]),re([F]),k],decls:1,vars:1,template:function(n,i){n&1&&ke(0),n&2&&De(i.value())},dependencies:[ue,Y,we],encapsulation:2,changeDetection:0})}return t})(),jt=(()=>{class t{static \u0275fac=function(n){return new(n||t)};static \u0275mod=xe({type:t});static \u0275inj=ye({imports:[yi,Y,Y]})}return t})();var Ci=["data-p-icon","minus"],$t=(()=>{class t extends N{static \u0275fac=(()=>{let e;return function(i){return(e||(e=I(t)))(i||t)}})();static \u0275cmp=S({type:t,selectors:[["","data-p-icon","minus"]],features:[k],attrs:Ci,decls:1,vars:0,consts:[["d","M13.2222 7.77778H0.777778C0.571498 7.77778 0.373667 7.69584 0.227806 7.54998C0.0819442 7.40412 0 7.20629 0 7.00001C0 6.79373 0.0819442 6.5959 0.227806 6.45003C0.373667 6.30417 0.571498 6.22223 0.777778 6.22223H13.2222C13.4285 6.22223 13.6263 6.30417 13.7722 6.45003C13.9181 6.5959 14 6.79373 14 7.00001C14 7.20629 13.9181 7.40412 13.7722 7.54998C13.6263 7.69584 13.4285 7.77778 13.2222 7.77778Z","fill","currentColor"]],template:function(n,i){n&1&&(x(),L(0,"path",0))},encapsulation:2})}return t})();var qt=`
    .p-checkbox {
        position: relative;
        display: inline-flex;
        user-select: none;
        vertical-align: bottom;
        width: dt('checkbox.width');
        height: dt('checkbox.height');
    }

    .p-checkbox-input {
        cursor: pointer;
        appearance: none;
        position: absolute;
        inset-block-start: 0;
        inset-inline-start: 0;
        width: 100%;
        height: 100%;
        padding: 0;
        margin: 0;
        opacity: 0;
        z-index: 1;
        outline: 0 none;
        border: 1px solid transparent;
        border-radius: dt('checkbox.border.radius');
    }

    .p-checkbox-box {
        display: flex;
        justify-content: center;
        align-items: center;
        border-radius: dt('checkbox.border.radius');
        border: 1px solid dt('checkbox.border.color');
        background: dt('checkbox.background');
        width: dt('checkbox.width');
        height: dt('checkbox.height');
        transition:
            background dt('checkbox.transition.duration'),
            color dt('checkbox.transition.duration'),
            border-color dt('checkbox.transition.duration'),
            box-shadow dt('checkbox.transition.duration'),
            outline-color dt('checkbox.transition.duration');
        outline-color: transparent;
        box-shadow: dt('checkbox.shadow');
    }

    .p-checkbox-icon {
        transition-duration: dt('checkbox.transition.duration');
        color: dt('checkbox.icon.color');
        font-size: dt('checkbox.icon.size');
        width: dt('checkbox.icon.size');
        height: dt('checkbox.icon.size');
    }

    .p-checkbox:not(.p-disabled):has(.p-checkbox-input:hover) .p-checkbox-box {
        border-color: dt('checkbox.hover.border.color');
    }

    .p-checkbox-checked .p-checkbox-box {
        border-color: dt('checkbox.checked.border.color');
        background: dt('checkbox.checked.background');
    }

    .p-checkbox-checked .p-checkbox-icon {
        color: dt('checkbox.icon.checked.color');
    }

    .p-checkbox-checked:not(.p-disabled):has(.p-checkbox-input:hover) .p-checkbox-box {
        background: dt('checkbox.checked.hover.background');
        border-color: dt('checkbox.checked.hover.border.color');
    }

    .p-checkbox-checked:not(.p-disabled):has(.p-checkbox-input:hover) .p-checkbox-icon {
        color: dt('checkbox.icon.checked.hover.color');
    }

    .p-checkbox:not(.p-disabled):has(.p-checkbox-input:focus-visible) .p-checkbox-box {
        border-color: dt('checkbox.focus.border.color');
        box-shadow: dt('checkbox.focus.ring.shadow');
        outline: dt('checkbox.focus.ring.width') dt('checkbox.focus.ring.style') dt('checkbox.focus.ring.color');
        outline-offset: dt('checkbox.focus.ring.offset');
    }

    .p-checkbox-checked:not(.p-disabled):has(.p-checkbox-input:focus-visible) .p-checkbox-box {
        border-color: dt('checkbox.checked.focus.border.color');
    }

    .p-checkbox.p-invalid > .p-checkbox-box {
        border-color: dt('checkbox.invalid.border.color');
    }

    .p-checkbox.p-variant-filled .p-checkbox-box {
        background: dt('checkbox.filled.background');
    }

    .p-checkbox-checked.p-variant-filled .p-checkbox-box {
        background: dt('checkbox.checked.background');
    }

    .p-checkbox-checked.p-variant-filled:not(.p-disabled):has(.p-checkbox-input:hover) .p-checkbox-box {
        background: dt('checkbox.checked.hover.background');
    }

    .p-checkbox.p-disabled {
        opacity: 1;
    }

    .p-checkbox.p-disabled .p-checkbox-box {
        background: dt('checkbox.disabled.background');
        border-color: dt('checkbox.checked.disabled.border.color');
    }

    .p-checkbox.p-disabled .p-checkbox-box .p-checkbox-icon {
        color: dt('checkbox.icon.disabled.color');
    }

    .p-checkbox-sm,
    .p-checkbox-sm .p-checkbox-box {
        width: dt('checkbox.sm.width');
        height: dt('checkbox.sm.height');
    }

    .p-checkbox-sm .p-checkbox-icon {
        font-size: dt('checkbox.icon.sm.size');
        width: dt('checkbox.icon.sm.size');
        height: dt('checkbox.icon.sm.size');
    }

    .p-checkbox-lg,
    .p-checkbox-lg .p-checkbox-box {
        width: dt('checkbox.lg.width');
        height: dt('checkbox.lg.height');
    }

    .p-checkbox-lg .p-checkbox-icon {
        font-size: dt('checkbox.icon.lg.size');
        width: dt('checkbox.icon.lg.size');
        height: dt('checkbox.icon.lg.size');
    }
`;var xi=["icon"],wi=["input"],Ti=(t,l)=>({checked:t,class:l});function vi(t,l){if(t&1&&P(0,"span",8),t&2){let e=p(3);h(e.cx("icon")),a("ngClass",e.checkboxIcon)("pBind",e.ptm("icon"))}}function Ii(t,l){if(t&1&&(x(),P(0,"svg",9)),t&2){let e=p(3);h(e.cx("icon")),a("pBind",e.ptm("icon"))}}function Si(t,l){if(t&1&&(U(0),d(1,vi,1,4,"span",6)(2,Ii,1,3,"svg",7),G()),t&2){let e=p(2);c(),a("ngIf",e.checkboxIcon),c(),a("ngIf",!e.checkboxIcon)}}function ki(t,l){if(t&1&&(x(),P(0,"svg",10)),t&2){let e=p(2);h(e.cx("icon")),a("pBind",e.ptm("icon"))}}function Ei(t,l){if(t&1&&(U(0),d(1,Si,3,2,"ng-container",3)(2,ki,1,3,"svg",5),G()),t&2){let e=p();c(),a("ngIf",e.checked),c(),a("ngIf",e._indeterminate())}}function Mi(t,l){}function Di(t,l){t&1&&d(0,Mi,0,0,"ng-template")}var Bi=`
    ${qt}

    /* For PrimeNG */
    p-checkBox.ng-invalid.ng-dirty .p-checkbox-box,
    p-check-box.ng-invalid.ng-dirty .p-checkbox-box,
    p-checkbox.ng-invalid.ng-dirty .p-checkbox-box {
        border-color: dt('checkbox.invalid.border.color');
    }
`,Pi={root:({instance:t})=>["p-checkbox p-component",{"p-checkbox-checked p-highlight":t.checked,"p-disabled":t.$disabled(),"p-invalid":t.invalid(),"p-variant-filled":t.$variant()==="filled","p-checkbox-sm p-inputfield-sm":t.size()==="small","p-checkbox-lg p-inputfield-lg":t.size()==="large"}],box:"p-checkbox-box",input:"p-checkbox-input",icon:"p-checkbox-icon"},Wt=(()=>{class t extends he{name="checkbox";style=Bi;classes=Pi;static \u0275fac=(()=>{let e;return function(i){return(e||(e=I(t)))(i||t)}})();static \u0275prov=oe({token:t,factory:t.\u0275fac})}return t})();var Zt=new pe("CHECKBOX_INSTANCE"),Li={provide:Ke,useExisting:Fe(()=>st),multi:!0},st=(()=>{class t extends Nt{hostName="";value;binary;ariaLabelledBy;ariaLabel;tabindex;inputId;inputStyle;styleClass;inputClass;indeterminate=!1;formControl;checkboxIcon;readonly;autofocus;trueValue=!0;falseValue=!1;variant=ie();size=ie();onChange=new D;onFocus=new D;onBlur=new D;inputViewChild;get checked(){return this._indeterminate()?!1:this.binary?this.modelValue()===this.trueValue:Mt(this.value,this.modelValue())}_indeterminate=Ct(void 0);checkboxIconTemplate;templates;_checkboxIconTemplate;focused=!1;_componentStyle=R(Wt);bindDirectiveInstance=R(F,{self:!0});$pcCheckbox=R(Zt,{optional:!0,skipSelf:!0})??void 0;$variant=Oe(()=>this.variant()||this.config.inputStyle()||this.config.inputVariant());onAfterContentInit(){this.templates?.forEach(e=>{switch(e.getType()){case"icon":this._checkboxIconTemplate=e.template;break;case"checkboxicon":this._checkboxIconTemplate=e.template;break}})}onChanges(e){e.indeterminate&&this._indeterminate.set(e.indeterminate.currentValue)}onAfterViewChecked(){this.bindDirectiveInstance.setAttrs(this.ptms(["host","root"]))}updateModel(e){let n,i=this.injector.get(Qe,null,{optional:!0,self:!0}),o=i&&!this.formControl?i.value:this.modelValue();this.binary?(n=this._indeterminate()?this.trueValue:this.checked?this.falseValue:this.trueValue,this.writeModelValue(n),this.onModelChange(n)):(this.checked||this._indeterminate()?n=o.filter(r=>!Le(r,this.value)):n=o?[...o,this.value]:[this.value],this.onModelChange(n),this.writeModelValue(n),this.formControl&&this.formControl.setValue(n)),this._indeterminate()&&this._indeterminate.set(!1),this.onChange.emit({checked:n,originalEvent:e})}handleChange(e){this.readonly||this.updateModel(e)}onInputFocus(e){this.focused=!0,this.onFocus.emit(e)}onInputBlur(e){this.focused=!1,this.onBlur.emit(e),this.onModelTouched()}focus(){this.inputViewChild?.nativeElement.focus()}writeControlValue(e,n){n(e),this.cd.markForCheck()}static \u0275fac=(()=>{let e;return function(i){return(e||(e=I(t)))(i||t)}})();static \u0275cmp=S({type:t,selectors:[["p-checkbox"],["p-checkBox"],["p-check-box"]],contentQueries:function(n,i,o){if(n&1&&(v(o,xi,4),v(o,ne,4)),n&2){let r;m(r=g())&&(i.checkboxIconTemplate=r.first),m(r=g())&&(i.templates=r)}},viewQuery:function(n,i){if(n&1&&Q(wi,5),n&2){let o;m(o=g())&&(i.inputViewChild=o.first)}},hostVars:5,hostBindings:function(n,i){n&2&&(B("data-p-highlight",i.checked)("data-p-checked",i.checked)("data-p-disabled",i.$disabled()),h(i.cn(i.cx("root"),i.styleClass)))},inputs:{hostName:"hostName",value:"value",binary:[2,"binary","binary",T],ariaLabelledBy:"ariaLabelledBy",ariaLabel:"ariaLabel",tabindex:[2,"tabindex","tabindex",$],inputId:"inputId",inputStyle:"inputStyle",styleClass:"styleClass",inputClass:"inputClass",indeterminate:[2,"indeterminate","indeterminate",T],formControl:"formControl",checkboxIcon:"checkboxIcon",readonly:[2,"readonly","readonly",T],autofocus:[2,"autofocus","autofocus",T],trueValue:"trueValue",falseValue:"falseValue",variant:[1,"variant"],size:[1,"size"]},outputs:{onChange:"onChange",onFocus:"onFocus",onBlur:"onBlur"},features:[te([Li,Wt,{provide:Zt,useExisting:t},{provide:me,useExisting:t}]),re([F]),k],decls:5,vars:24,consts:[["input",""],["type","checkbox",3,"focus","blur","change","checked","pBind"],[3,"pBind"],[4,"ngIf"],[4,"ngTemplateOutlet","ngTemplateOutletContext"],["data-p-icon","minus",3,"class","pBind",4,"ngIf"],[3,"class","ngClass","pBind",4,"ngIf"],["data-p-icon","check",3,"class","pBind",4,"ngIf"],[3,"ngClass","pBind"],["data-p-icon","check",3,"pBind"],["data-p-icon","minus",3,"pBind"]],template:function(n,i){if(n&1){let o=K();_(0,"input",1,0),O("focus",function(s){return y(o),C(i.onInputFocus(s))})("blur",function(s){return y(o),C(i.onInputBlur(s))})("change",function(s){return y(o),C(i.handleChange(s))}),w(),_(2,"div",2),d(3,Ei,3,2,"ng-container",3)(4,Di,1,0,null,4),w()}n&2&&(Me(i.inputStyle),h(i.cn(i.cx("input"),i.inputClass)),a("checked",i.checked)("pBind",i.ptm("input")),B("id",i.inputId)("value",i.value)("name",i.name())("tabindex",i.tabindex)("required",i.required()?"":void 0)("readonly",i.readonly?"":void 0)("disabled",i.$disabled()?"":void 0)("aria-labelledby",i.ariaLabelledBy)("aria-label",i.ariaLabel),c(2),h(i.cx("box")),a("pBind",i.ptm("box")),c(),a("ngIf",!i.checkboxIconTemplate&&!i._checkboxIconTemplate),c(),a("ngTemplateOutlet",i.checkboxIconTemplate||i._checkboxIconTemplate)("ngTemplateOutletContext",ge(21,Ti,i.checked,i.cx("icon"))))},dependencies:[ue,Te,le,se,Y,qe,$t,we,F],encapsulation:2,changeDetection:0})}return t})();var Vi=["data-p-icon","angle-double-left"],Jt=(()=>{class t extends N{static \u0275fac=(()=>{let e;return function(i){return(e||(e=I(t)))(i||t)}})();static \u0275cmp=S({type:t,selectors:[["","data-p-icon","angle-double-left"]],features:[k],attrs:Vi,decls:1,vars:0,consts:[["fill-rule","evenodd","clip-rule","evenodd","d","M5.71602 11.164C5.80782 11.2021 5.9063 11.2215 6.00569 11.221C6.20216 11.2301 6.39427 11.1612 6.54025 11.0294C6.68191 10.8875 6.76148 10.6953 6.76148 10.4948C6.76148 10.2943 6.68191 10.1021 6.54025 9.96024L3.51441 6.9344L6.54025 3.90855C6.624 3.76126 6.65587 3.59011 6.63076 3.42254C6.60564 3.25498 6.525 3.10069 6.40175 2.98442C6.2785 2.86815 6.11978 2.79662 5.95104 2.7813C5.78229 2.76598 5.61329 2.80776 5.47112 2.89994L1.97123 6.39983C1.82957 6.54167 1.75 6.73393 1.75 6.9344C1.75 7.13486 1.82957 7.32712 1.97123 7.46896L5.47112 10.9991C5.54096 11.0698 5.62422 11.1259 5.71602 11.164ZM11.0488 10.9689C11.1775 11.1156 11.3585 11.2061 11.5531 11.221C11.7477 11.2061 11.9288 11.1156 12.0574 10.9689C12.1815 10.8302 12.25 10.6506 12.25 10.4645C12.25 10.2785 12.1815 10.0989 12.0574 9.96024L9.03158 6.93439L12.0574 3.90855C12.1248 3.76739 12.1468 3.60881 12.1204 3.45463C12.0939 3.30045 12.0203 3.15826 11.9097 3.04765C11.7991 2.93703 11.6569 2.86343 11.5027 2.83698C11.3486 2.81053 11.19 2.83252 11.0488 2.89994L7.51865 6.36957C7.37699 6.51141 7.29742 6.70367 7.29742 6.90414C7.29742 7.1046 7.37699 7.29686 7.51865 7.4387L11.0488 10.9689Z","fill","currentColor"]],template:function(n,i){n&1&&(x(),L(0,"path",0))},encapsulation:2})}return t})();var zi=["data-p-icon","angle-double-right"],Xt=(()=>{class t extends N{static \u0275fac=(()=>{let e;return function(i){return(e||(e=I(t)))(i||t)}})();static \u0275cmp=S({type:t,selectors:[["","data-p-icon","angle-double-right"]],features:[k],attrs:zi,decls:1,vars:0,consts:[["fill-rule","evenodd","clip-rule","evenodd","d","M7.68757 11.1451C7.7791 11.1831 7.8773 11.2024 7.9764 11.2019C8.07769 11.1985 8.17721 11.1745 8.26886 11.1312C8.36052 11.088 8.44238 11.0265 8.50943 10.9505L12.0294 7.49085C12.1707 7.34942 12.25 7.15771 12.25 6.95782C12.25 6.75794 12.1707 6.56622 12.0294 6.42479L8.50943 2.90479C8.37014 2.82159 8.20774 2.78551 8.04633 2.80192C7.88491 2.81833 7.73309 2.88635 7.6134 2.99588C7.4937 3.10541 7.41252 3.25061 7.38189 3.40994C7.35126 3.56927 7.37282 3.73423 7.44337 3.88033L10.4605 6.89748L7.44337 9.91463C7.30212 10.0561 7.22278 10.2478 7.22278 10.4477C7.22278 10.6475 7.30212 10.8393 7.44337 10.9807C7.51301 11.0512 7.59603 11.1071 7.68757 11.1451ZM1.94207 10.9505C2.07037 11.0968 2.25089 11.1871 2.44493 11.2019C2.63898 11.1871 2.81949 11.0968 2.94779 10.9505L6.46779 7.49085C6.60905 7.34942 6.68839 7.15771 6.68839 6.95782C6.68839 6.75793 6.60905 6.56622 6.46779 6.42479L2.94779 2.90479C2.80704 2.83757 2.6489 2.81563 2.49517 2.84201C2.34143 2.86839 2.19965 2.94178 2.08936 3.05207C1.97906 3.16237 1.90567 3.30415 1.8793 3.45788C1.85292 3.61162 1.87485 3.76975 1.94207 3.9105L4.95922 6.92765L1.94207 9.9448C1.81838 10.0831 1.75 10.2621 1.75 10.4477C1.75 10.6332 1.81838 10.8122 1.94207 10.9505Z","fill","currentColor"]],template:function(n,i){n&1&&(x(),L(0,"path",0))},encapsulation:2})}return t})();var Fi=["data-p-icon","angle-down"],Yt=(()=>{class t extends N{static \u0275fac=(()=>{let e;return function(i){return(e||(e=I(t)))(i||t)}})();static \u0275cmp=S({type:t,selectors:[["","data-p-icon","angle-down"]],features:[k],attrs:Fi,decls:1,vars:0,consts:[["d","M3.58659 4.5007C3.68513 4.50023 3.78277 4.51945 3.87379 4.55723C3.9648 4.59501 4.04735 4.65058 4.11659 4.7207L7.11659 7.7207L10.1166 4.7207C10.2619 4.65055 10.4259 4.62911 10.5843 4.65956C10.7427 4.69002 10.8871 4.77074 10.996 4.88976C11.1049 5.00877 11.1726 5.15973 11.1889 5.32022C11.2052 5.48072 11.1693 5.6422 11.0866 5.7807L7.58659 9.2807C7.44597 9.42115 7.25534 9.50004 7.05659 9.50004C6.85784 9.50004 6.66722 9.42115 6.52659 9.2807L3.02659 5.7807C2.88614 5.64007 2.80725 5.44945 2.80725 5.2507C2.80725 5.05195 2.88614 4.86132 3.02659 4.7207C3.09932 4.64685 3.18675 4.58911 3.28322 4.55121C3.37969 4.51331 3.48305 4.4961 3.58659 4.5007Z","fill","currentColor"]],template:function(n,i){n&1&&(x(),L(0,"path",0))},encapsulation:2})}return t})();var Ni=["data-p-icon","angle-left"],ei=(()=>{class t extends N{static \u0275fac=(()=>{let e;return function(i){return(e||(e=I(t)))(i||t)}})();static \u0275cmp=S({type:t,selectors:[["","data-p-icon","angle-left"]],features:[k],attrs:Ni,decls:1,vars:0,consts:[["d","M8.75 11.185C8.65146 11.1854 8.55381 11.1662 8.4628 11.1284C8.37179 11.0906 8.28924 11.0351 8.22 10.965L4.72 7.46496C4.57955 7.32433 4.50066 7.13371 4.50066 6.93496C4.50066 6.73621 4.57955 6.54558 4.72 6.40496L8.22 2.93496C8.36095 2.84357 8.52851 2.80215 8.69582 2.81733C8.86312 2.83252 9.02048 2.90344 9.14268 3.01872C9.26487 3.134 9.34483 3.28696 9.36973 3.4531C9.39463 3.61924 9.36303 3.78892 9.28 3.93496L6.28 6.93496L9.28 9.93496C9.42045 10.0756 9.49934 10.2662 9.49934 10.465C9.49934 10.6637 9.42045 10.8543 9.28 10.995C9.13526 11.1257 8.9448 11.1939 8.75 11.185Z","fill","currentColor"]],template:function(n,i){n&1&&(x(),L(0,"path",0))},encapsulation:2})}return t})();var Ri=["data-p-icon","angle-right"],ti=(()=>{class t extends N{static \u0275fac=(()=>{let e;return function(i){return(e||(e=I(t)))(i||t)}})();static \u0275cmp=S({type:t,selectors:[["","data-p-icon","angle-right"]],features:[k],attrs:Ri,decls:1,vars:0,consts:[["d","M5.25 11.1728C5.14929 11.1694 5.05033 11.1455 4.9592 11.1025C4.86806 11.0595 4.78666 10.9984 4.72 10.9228C4.57955 10.7822 4.50066 10.5916 4.50066 10.3928C4.50066 10.1941 4.57955 10.0035 4.72 9.86283L7.72 6.86283L4.72 3.86283C4.66067 3.71882 4.64765 3.55991 4.68275 3.40816C4.71785 3.25642 4.79932 3.11936 4.91585 3.01602C5.03238 2.91268 5.17819 2.84819 5.33305 2.83149C5.4879 2.81479 5.64411 2.84671 5.78 2.92283L9.28 6.42283C9.42045 6.56346 9.49934 6.75408 9.49934 6.95283C9.49934 7.15158 9.42045 7.34221 9.28 7.48283L5.78 10.9228C5.71333 10.9984 5.63193 11.0595 5.5408 11.1025C5.44966 11.1455 5.35071 11.1694 5.25 11.1728Z","fill","currentColor"]],template:function(n,i){n&1&&(x(),L(0,"path",0))},encapsulation:2})}return t})();var Oi=["data-p-icon","angle-up"],ii=(()=>{class t extends N{static \u0275fac=(()=>{let e;return function(i){return(e||(e=I(t)))(i||t)}})();static \u0275cmp=S({type:t,selectors:[["","data-p-icon","angle-up"]],features:[k],attrs:Oi,decls:1,vars:0,consts:[["d","M10.4134 9.49931C10.3148 9.49977 10.2172 9.48055 10.1262 9.44278C10.0352 9.405 9.95263 9.34942 9.88338 9.27931L6.88338 6.27931L3.88338 9.27931C3.73811 9.34946 3.57409 9.3709 3.41567 9.34044C3.25724 9.30999 3.11286 9.22926 3.00395 9.11025C2.89504 8.99124 2.82741 8.84028 2.8111 8.67978C2.79478 8.51928 2.83065 8.35781 2.91338 8.21931L6.41338 4.71931C6.55401 4.57886 6.74463 4.49997 6.94338 4.49997C7.14213 4.49997 7.33276 4.57886 7.47338 4.71931L10.9734 8.21931C11.1138 8.35994 11.1927 8.55056 11.1927 8.74931C11.1927 8.94806 11.1138 9.13868 10.9734 9.27931C10.9007 9.35315 10.8132 9.41089 10.7168 9.44879C10.6203 9.48669 10.5169 9.5039 10.4134 9.49931Z","fill","currentColor"]],template:function(n,i){n&1&&(x(),L(0,"path",0))},encapsulation:2})}return t})();var Hi=["data-p-icon","arrow-down"],ct=(()=>{class t extends N{pathId;onInit(){this.pathId="url(#"+ce()+")"}static \u0275fac=(()=>{let e;return function(i){return(e||(e=I(t)))(i||t)}})();static \u0275cmp=S({type:t,selectors:[["","data-p-icon","arrow-down"]],features:[k],attrs:Hi,decls:5,vars:2,consts:[["fill-rule","evenodd","clip-rule","evenodd","d","M6.99994 14C6.91097 14.0004 6.82281 13.983 6.74064 13.9489C6.65843 13.9148 6.58387 13.8646 6.52133 13.8013L1.10198 8.38193C0.982318 8.25351 0.917175 8.08367 0.920272 7.90817C0.923368 7.73267 0.994462 7.56523 1.11858 7.44111C1.24269 7.317 1.41014 7.2459 1.58563 7.2428C1.76113 7.23971 1.93098 7.30485 2.0594 7.42451L6.32263 11.6877V0.677419C6.32263 0.497756 6.394 0.325452 6.52104 0.198411C6.64808 0.0713706 6.82039 0 7.00005 0C7.17971 0 7.35202 0.0713706 7.47906 0.198411C7.6061 0.325452 7.67747 0.497756 7.67747 0.677419V11.6877L11.9407 7.42451C12.0691 7.30485 12.2389 7.23971 12.4144 7.2428C12.5899 7.2459 12.7574 7.317 12.8815 7.44111C13.0056 7.56523 13.0767 7.73267 13.0798 7.90817C13.0829 8.08367 13.0178 8.25351 12.8981 8.38193L7.47875 13.8013C7.41621 13.8646 7.34164 13.9148 7.25944 13.9489C7.17727 13.983 7.08912 14.0004 7.00015 14C7.00012 14 7.00009 14 7.00005 14C7.00001 14 6.99998 14 6.99994 14Z","fill","currentColor"],[3,"id"],["width","14","height","14","fill","white"]],template:function(n,i){n&1&&(x(),W(0,"g"),L(1,"path",0),Z(),W(2,"defs")(3,"clipPath",1),L(4,"rect",2),Z()()),n&2&&(B("clip-path",i.pathId),c(3),ae("id",i.pathId))},encapsulation:2})}return t})();var Ai=["data-p-icon","arrow-up"],pt=(()=>{class t extends N{pathId;onInit(){this.pathId="url(#"+ce()+")"}static \u0275fac=(()=>{let e;return function(i){return(e||(e=I(t)))(i||t)}})();static \u0275cmp=S({type:t,selectors:[["","data-p-icon","arrow-up"]],features:[k],attrs:Ai,decls:5,vars:2,consts:[["fill-rule","evenodd","clip-rule","evenodd","d","M6.51551 13.799C6.64205 13.9255 6.813 13.9977 6.99193 14C7.17087 13.9977 7.34182 13.9255 7.46835 13.799C7.59489 13.6725 7.66701 13.5015 7.66935 13.3226V2.31233L11.9326 6.57554C11.9951 6.63887 12.0697 6.68907 12.1519 6.72319C12.2341 6.75731 12.3223 6.77467 12.4113 6.77425C12.5003 6.77467 12.5885 6.75731 12.6707 6.72319C12.7529 6.68907 12.8274 6.63887 12.89 6.57554C13.0168 6.44853 13.0881 6.27635 13.0881 6.09683C13.0881 5.91732 13.0168 5.74514 12.89 5.61812L7.48846 0.216594C7.48274 0.210436 7.4769 0.204374 7.47094 0.198411C7.3439 0.0713707 7.1716 0 6.99193 0C6.81227 0 6.63997 0.0713707 6.51293 0.198411C6.50704 0.204296 6.50128 0.210278 6.49563 0.216354L1.09386 5.61812C0.974201 5.74654 0.909057 5.91639 0.912154 6.09189C0.91525 6.26738 0.986345 6.43483 1.11046 6.55894C1.23457 6.68306 1.40202 6.75415 1.57752 6.75725C1.75302 6.76035 1.92286 6.6952 2.05128 6.57554L6.31451 2.31231V13.3226C6.31685 13.5015 6.38898 13.6725 6.51551 13.799Z","fill","currentColor"],[3,"id"],["width","14","height","14","fill","white"]],template:function(n,i){n&1&&(x(),W(0,"g"),L(1,"path",0),Z(),W(2,"defs")(3,"clipPath",1),L(4,"rect",2),Z()()),n&2&&(B("clip-path",i.pathId),c(3),ae("id",i.pathId))},encapsulation:2})}return t})();var Ki=["data-p-icon","chevron-right"],dt=(()=>{class t extends N{static \u0275fac=(()=>{let e;return function(i){return(e||(e=I(t)))(i||t)}})();static \u0275cmp=S({type:t,selectors:[["","data-p-icon","chevron-right"]],features:[k],attrs:Ki,decls:1,vars:0,consts:[["d","M4.38708 13C4.28408 13.0005 4.18203 12.9804 4.08691 12.9409C3.99178 12.9014 3.9055 12.8433 3.83313 12.7701C3.68634 12.6231 3.60388 12.4238 3.60388 12.2161C3.60388 12.0084 3.68634 11.8091 3.83313 11.6622L8.50507 6.99022L3.83313 2.31827C3.69467 2.16968 3.61928 1.97313 3.62287 1.77005C3.62645 1.56698 3.70872 1.37322 3.85234 1.22959C3.99596 1.08597 4.18972 1.00371 4.3928 1.00012C4.59588 0.996539 4.79242 1.07192 4.94102 1.21039L10.1669 6.43628C10.3137 6.58325 10.3962 6.78249 10.3962 6.99022C10.3962 7.19795 10.3137 7.39718 10.1669 7.54416L4.94102 12.7701C4.86865 12.8433 4.78237 12.9014 4.68724 12.9409C4.59212 12.9804 4.49007 13.0005 4.38708 13Z","fill","currentColor"]],template:function(n,i){n&1&&(x(),L(0,"path",0))},encapsulation:2})}return t})();var Qi=["data-p-icon","sort-alt"],ni=(()=>{class t extends N{pathId;onInit(){this.pathId="url(#"+ce()+")"}static \u0275fac=(()=>{let e;return function(i){return(e||(e=I(t)))(i||t)}})();static \u0275cmp=S({type:t,selectors:[["","data-p-icon","sort-alt"]],features:[k],attrs:Qi,decls:8,vars:2,consts:[["d","M5.64515 3.61291C5.47353 3.61291 5.30192 3.54968 5.16644 3.4142L3.38708 1.63484L1.60773 3.4142C1.34579 3.67613 0.912244 3.67613 0.650309 3.4142C0.388374 3.15226 0.388374 2.71871 0.650309 2.45678L2.90837 0.198712C3.17031 -0.0632236 3.60386 -0.0632236 3.86579 0.198712L6.12386 2.45678C6.38579 2.71871 6.38579 3.15226 6.12386 3.4142C5.98837 3.54968 5.81676 3.61291 5.64515 3.61291Z","fill","currentColor"],["d","M3.38714 14C3.01681 14 2.70972 13.6929 2.70972 13.3226V0.677419C2.70972 0.307097 3.01681 0 3.38714 0C3.75746 0 4.06456 0.307097 4.06456 0.677419V13.3226C4.06456 13.6929 3.75746 14 3.38714 14Z","fill","currentColor"],["d","M10.6129 14C10.4413 14 10.2697 13.9368 10.1342 13.8013L7.87611 11.5432C7.61418 11.2813 7.61418 10.8477 7.87611 10.5858C8.13805 10.3239 8.5716 10.3239 8.83353 10.5858L10.6129 12.3652L12.3922 10.5858C12.6542 10.3239 13.0877 10.3239 13.3497 10.5858C13.6116 10.8477 13.6116 11.2813 13.3497 11.5432L11.0916 13.8013C10.9561 13.9368 10.7845 14 10.6129 14Z","fill","currentColor"],["d","M10.6129 14C10.2426 14 9.93552 13.6929 9.93552 13.3226V0.677419C9.93552 0.307097 10.2426 0 10.6129 0C10.9833 0 11.2904 0.307097 11.2904 0.677419V13.3226C11.2904 13.6929 10.9832 14 10.6129 14Z","fill","currentColor"],[3,"id"],["width","14","height","14","fill","white"]],template:function(n,i){n&1&&(x(),W(0,"g"),L(1,"path",0)(2,"path",1)(3,"path",2)(4,"path",3),Z(),W(5,"defs")(6,"clipPath",4),L(7,"rect",5),Z()()),n&2&&(B("clip-path",i.pathId),c(6),ae("id",i.pathId))},encapsulation:2})}return t})();var Ui=["data-p-icon","sort-amount-down"],oi=(()=>{class t extends N{pathId;onInit(){this.pathId="url(#"+ce()+")"}static \u0275fac=(()=>{let e;return function(i){return(e||(e=I(t)))(i||t)}})();static \u0275cmp=S({type:t,selectors:[["","data-p-icon","sort-amount-down"]],features:[k],attrs:Ui,decls:5,vars:2,consts:[["d","M4.93953 10.5858L3.83759 11.6877V0.677419C3.83759 0.307097 3.53049 0 3.16017 0C2.78985 0 2.48275 0.307097 2.48275 0.677419V11.6877L1.38082 10.5858C1.11888 10.3239 0.685331 10.3239 0.423396 10.5858C0.16146 10.8477 0.16146 11.2813 0.423396 11.5432L2.68146 13.8013C2.74469 13.8645 2.81694 13.9097 2.89823 13.9458C2.97952 13.9819 3.06985 14 3.16017 14C3.25049 14 3.33178 13.9819 3.42211 13.9458C3.5034 13.9097 3.57565 13.8645 3.63888 13.8013L5.89694 11.5432C6.15888 11.2813 6.15888 10.8477 5.89694 10.5858C5.63501 10.3239 5.20146 10.3239 4.93953 10.5858ZM13.0957 0H7.22468C6.85436 0 6.54726 0.307097 6.54726 0.677419C6.54726 1.04774 6.85436 1.35484 7.22468 1.35484H13.0957C13.466 1.35484 13.7731 1.04774 13.7731 0.677419C13.7731 0.307097 13.466 0 13.0957 0ZM7.22468 5.41935H9.48275C9.85307 5.41935 10.1602 5.72645 10.1602 6.09677C10.1602 6.4671 9.85307 6.77419 9.48275 6.77419H7.22468C6.85436 6.77419 6.54726 6.4671 6.54726 6.09677C6.54726 5.72645 6.85436 5.41935 7.22468 5.41935ZM7.6763 8.12903H7.22468C6.85436 8.12903 6.54726 8.43613 6.54726 8.80645C6.54726 9.17677 6.85436 9.48387 7.22468 9.48387H7.6763C8.04662 9.48387 8.35372 9.17677 8.35372 8.80645C8.35372 8.43613 8.04662 8.12903 7.6763 8.12903ZM7.22468 2.70968H11.2892C11.6595 2.70968 11.9666 3.01677 11.9666 3.3871C11.9666 3.75742 11.6595 4.06452 11.2892 4.06452H7.22468C6.85436 4.06452 6.54726 3.75742 6.54726 3.3871C6.54726 3.01677 6.85436 2.70968 7.22468 2.70968Z","fill","currentColor"],[3,"id"],["width","14","height","14","fill","white"]],template:function(n,i){n&1&&(x(),W(0,"g"),L(1,"path",0),Z(),W(2,"defs")(3,"clipPath",1),L(4,"rect",2),Z()()),n&2&&(B("clip-path",i.pathId),c(3),ae("id",i.pathId))},encapsulation:2})}return t})();var Gi=["data-p-icon","sort-amount-up-alt"],ri=(()=>{class t extends N{pathId;onInit(){this.pathId="url(#"+ce()+")"}static \u0275fac=(()=>{let e;return function(i){return(e||(e=I(t)))(i||t)}})();static \u0275cmp=S({type:t,selectors:[["","data-p-icon","sort-amount-up-alt"]],features:[k],attrs:Gi,decls:5,vars:2,consts:[["d","M3.63435 0.19871C3.57113 0.135484 3.49887 0.0903226 3.41758 0.0541935C3.255 -0.0180645 3.06532 -0.0180645 2.90274 0.0541935C2.82145 0.0903226 2.74919 0.135484 2.68597 0.19871L0.427901 2.45677C0.165965 2.71871 0.165965 3.15226 0.427901 3.41419C0.689836 3.67613 1.12338 3.67613 1.38532 3.41419L2.48726 2.31226V13.3226C2.48726 13.6929 2.79435 14 3.16467 14C3.535 14 3.84209 13.6929 3.84209 13.3226V2.31226L4.94403 3.41419C5.07951 3.54968 5.25113 3.6129 5.42274 3.6129C5.59435 3.6129 5.76597 3.54968 5.90145 3.41419C6.16338 3.15226 6.16338 2.71871 5.90145 2.45677L3.64338 0.19871H3.63435ZM13.7685 13.3226C13.7685 12.9523 13.4615 12.6452 13.0911 12.6452H7.22016C6.84984 12.6452 6.54274 12.9523 6.54274 13.3226C6.54274 13.6929 6.84984 14 7.22016 14H13.0911C13.4615 14 13.7685 13.6929 13.7685 13.3226ZM7.22016 8.58064C6.84984 8.58064 6.54274 8.27355 6.54274 7.90323C6.54274 7.5329 6.84984 7.22581 7.22016 7.22581H9.47823C9.84855 7.22581 10.1556 7.5329 10.1556 7.90323C10.1556 8.27355 9.84855 8.58064 9.47823 8.58064H7.22016ZM7.22016 5.87097H7.67177C8.0421 5.87097 8.34919 5.56387 8.34919 5.19355C8.34919 4.82323 8.0421 4.51613 7.67177 4.51613H7.22016C6.84984 4.51613 6.54274 4.82323 6.54274 5.19355C6.54274 5.56387 6.84984 5.87097 7.22016 5.87097ZM11.2847 11.2903H7.22016C6.84984 11.2903 6.54274 10.9832 6.54274 10.6129C6.54274 10.2426 6.84984 9.93548 7.22016 9.93548H11.2847C11.655 9.93548 11.9621 10.2426 11.9621 10.6129C11.9621 10.9832 11.655 11.2903 11.2847 11.2903Z","fill","currentColor"],[3,"id"],["width","14","height","14","fill","white"]],template:function(n,i){n&1&&(x(),W(0,"g"),L(1,"path",0),Z(),W(2,"defs")(3,"clipPath",1),L(4,"rect",2),Z()()),n&2&&(B("clip-path",i.pathId),c(3),ae("id",i.pathId))},encapsulation:2})}return t})();var ai=`
    .p-inputnumber {
        display: inline-flex;
        position: relative;
    }

    .p-inputnumber-button {
        display: flex;
        align-items: center;
        justify-content: center;
        flex: 0 0 auto;
        cursor: pointer;
        background: dt('inputnumber.button.background');
        color: dt('inputnumber.button.color');
        width: dt('inputnumber.button.width');
        transition:
            background dt('inputnumber.transition.duration'),
            color dt('inputnumber.transition.duration'),
            border-color dt('inputnumber.transition.duration'),
            outline-color dt('inputnumber.transition.duration');
    }

    .p-inputnumber-button:disabled {
        cursor: auto;
    }

    .p-inputnumber-button:not(:disabled):hover {
        background: dt('inputnumber.button.hover.background');
        color: dt('inputnumber.button.hover.color');
    }

    .p-inputnumber-button:not(:disabled):active {
        background: dt('inputnumber.button.active.background');
        color: dt('inputnumber.button.active.color');
    }

    .p-inputnumber-stacked .p-inputnumber-button {
        position: relative;
        flex: 1 1 auto;
        border: 0 none;
    }

    .p-inputnumber-stacked .p-inputnumber-button-group {
        display: flex;
        flex-direction: column;
        position: absolute;
        inset-block-start: 1px;
        inset-inline-end: 1px;
        height: calc(100% - 2px);
        z-index: 1;
    }

    .p-inputnumber-stacked .p-inputnumber-increment-button {
        padding: 0;
        border-start-end-radius: calc(dt('inputnumber.button.border.radius') - 1px);
    }

    .p-inputnumber-stacked .p-inputnumber-decrement-button {
        padding: 0;
        border-end-end-radius: calc(dt('inputnumber.button.border.radius') - 1px);
    }

    .p-inputnumber-stacked .p-inputnumber-input {
        padding-inline-end: calc(dt('inputnumber.button.width') + dt('form.field.padding.x'));
    }

    .p-inputnumber-horizontal .p-inputnumber-button {
        border: 1px solid dt('inputnumber.button.border.color');
    }

    .p-inputnumber-horizontal .p-inputnumber-button:hover {
        border-color: dt('inputnumber.button.hover.border.color');
    }

    .p-inputnumber-horizontal .p-inputnumber-button:active {
        border-color: dt('inputnumber.button.active.border.color');
    }

    .p-inputnumber-horizontal .p-inputnumber-increment-button {
        order: 3;
        border-start-end-radius: dt('inputnumber.button.border.radius');
        border-end-end-radius: dt('inputnumber.button.border.radius');
        border-inline-start: 0 none;
    }

    .p-inputnumber-horizontal .p-inputnumber-input {
        order: 2;
        border-radius: 0;
    }

    .p-inputnumber-horizontal .p-inputnumber-decrement-button {
        order: 1;
        border-start-start-radius: dt('inputnumber.button.border.radius');
        border-end-start-radius: dt('inputnumber.button.border.radius');
        border-inline-end: 0 none;
    }

    .p-floatlabel:has(.p-inputnumber-horizontal) label {
        margin-inline-start: dt('inputnumber.button.width');
    }

    .p-inputnumber-vertical {
        flex-direction: column;
    }

    .p-inputnumber-vertical .p-inputnumber-button {
        border: 1px solid dt('inputnumber.button.border.color');
        padding: dt('inputnumber.button.vertical.padding');
    }

    .p-inputnumber-vertical .p-inputnumber-button:hover {
        border-color: dt('inputnumber.button.hover.border.color');
    }

    .p-inputnumber-vertical .p-inputnumber-button:active {
        border-color: dt('inputnumber.button.active.border.color');
    }

    .p-inputnumber-vertical .p-inputnumber-increment-button {
        order: 1;
        border-start-start-radius: dt('inputnumber.button.border.radius');
        border-start-end-radius: dt('inputnumber.button.border.radius');
        width: 100%;
        border-block-end: 0 none;
    }

    .p-inputnumber-vertical .p-inputnumber-input {
        order: 2;
        border-radius: 0;
        text-align: center;
    }

    .p-inputnumber-vertical .p-inputnumber-decrement-button {
        order: 3;
        border-end-start-radius: dt('inputnumber.button.border.radius');
        border-end-end-radius: dt('inputnumber.button.border.radius');
        width: 100%;
        border-block-start: 0 none;
    }

    .p-inputnumber-input {
        flex: 1 1 auto;
    }

    .p-inputnumber-fluid {
        width: 100%;
    }

    .p-inputnumber-fluid .p-inputnumber-input {
        width: 1%;
    }

    .p-inputnumber-fluid.p-inputnumber-vertical .p-inputnumber-input {
        width: 100%;
    }

    .p-inputnumber:has(.p-inputtext-sm) .p-inputnumber-button .p-icon {
        font-size: dt('form.field.sm.font.size');
        width: dt('form.field.sm.font.size');
        height: dt('form.field.sm.font.size');
    }

    .p-inputnumber:has(.p-inputtext-lg) .p-inputnumber-button .p-icon {
        font-size: dt('form.field.lg.font.size');
        width: dt('form.field.lg.font.size');
        height: dt('form.field.lg.font.size');
    }

    .p-inputnumber-clear-icon {
        position: absolute;
        top: 50%;
        margin-top: -0.5rem;
        cursor: pointer;
        inset-inline-end: dt('form.field.padding.x');
        color: dt('form.field.icon.color');
    }

    .p-inputnumber:has(.p-inputnumber-clear-icon) .p-inputnumber-input {
        padding-inline-end: calc((dt('form.field.padding.x') * 2) + dt('icon.size'));
    }

    .p-inputnumber-stacked .p-inputnumber-clear-icon {
        inset-inline-end: calc(dt('inputnumber.button.width') + dt('form.field.padding.x'));
    }

    .p-inputnumber-stacked:has(.p-inputnumber-clear-icon) .p-inputnumber-input {
        padding-inline-end: calc(dt('inputnumber.button.width') + (dt('form.field.padding.x') * 2) + dt('icon.size'));
    }

    .p-inputnumber-horizontal .p-inputnumber-clear-icon {
        inset-inline-end: calc(dt('inputnumber.button.width') + dt('form.field.padding.x'));
    }
`;var ji=["clearicon"],$i=["incrementbuttonicon"],qi=["decrementbuttonicon"],Wi=["input"];function Zi(t,l){if(t&1){let e=K();x(),_(0,"svg",7),O("click",function(){y(e);let i=p(2);return C(i.clear())}),w()}if(t&2){let e=p(2);h(e.cx("clearIcon")),a("pBind",e.ptm("clearIcon"))}}function Ji(t,l){}function Xi(t,l){t&1&&d(0,Ji,0,0,"ng-template")}function Yi(t,l){if(t&1){let e=K();_(0,"span",8),O("click",function(){y(e);let i=p(2);return C(i.clear())}),d(1,Xi,1,0,null,9),w()}if(t&2){let e=p(2);h(e.cx("clearIcon")),a("pBind",e.ptm("clearIcon")),c(),a("ngTemplateOutlet",e.clearIconTemplate||e._clearIconTemplate)}}function en(t,l){if(t&1&&(U(0),d(1,Zi,1,3,"svg",5)(2,Yi,2,4,"span",6),G()),t&2){let e=p();c(),a("ngIf",!e.clearIconTemplate&&!e._clearIconTemplate),c(),a("ngIf",e.clearIconTemplate||e._clearIconTemplate)}}function tn(t,l){if(t&1&&P(0,"span",13),t&2){let e=p(2);a("pBind",e.ptm("incrementButtonIcon"))("ngClass",e.incrementButtonIcon)}}function nn(t,l){if(t&1&&(x(),P(0,"svg",15)),t&2){let e=p(3);a("pBind",e.ptm("incrementButtonIcon"))}}function on(t,l){}function rn(t,l){t&1&&d(0,on,0,0,"ng-template")}function an(t,l){if(t&1&&(U(0),d(1,nn,1,1,"svg",14)(2,rn,1,0,null,9),G()),t&2){let e=p(2);c(),a("ngIf",!e.incrementButtonIconTemplate&&!e._incrementButtonIconTemplate),c(),a("ngTemplateOutlet",e.incrementButtonIconTemplate||e._incrementButtonIconTemplate)}}function ln(t,l){if(t&1&&P(0,"span",13),t&2){let e=p(2);a("pBind",e.ptm("decrementButtonIcon"))("ngClass",e.decrementButtonIcon)}}function sn(t,l){if(t&1&&(x(),P(0,"svg",17)),t&2){let e=p(3);a("pBind",e.ptm("decrementButtonIcon"))}}function cn(t,l){}function pn(t,l){t&1&&d(0,cn,0,0,"ng-template")}function dn(t,l){if(t&1&&(U(0),d(1,sn,1,1,"svg",16)(2,pn,1,0,null,9),G()),t&2){let e=p(2);c(),a("ngIf",!e.decrementButtonIconTemplate&&!e._decrementButtonIconTemplate),c(),a("ngTemplateOutlet",e.decrementButtonIconTemplate||e._decrementButtonIconTemplate)}}function un(t,l){if(t&1){let e=K();_(0,"span",10)(1,"button",11),O("mousedown",function(i){y(e);let o=p();return C(o.onUpButtonMouseDown(i))})("mouseup",function(){y(e);let i=p();return C(i.onUpButtonMouseUp())})("mouseleave",function(){y(e);let i=p();return C(i.onUpButtonMouseLeave())})("keydown",function(i){y(e);let o=p();return C(o.onUpButtonKeyDown(i))})("keyup",function(){y(e);let i=p();return C(i.onUpButtonKeyUp())}),d(2,tn,1,2,"span",12)(3,an,3,2,"ng-container",2),w(),_(4,"button",11),O("mousedown",function(i){y(e);let o=p();return C(o.onDownButtonMouseDown(i))})("mouseup",function(){y(e);let i=p();return C(i.onDownButtonMouseUp())})("mouseleave",function(){y(e);let i=p();return C(i.onDownButtonMouseLeave())})("keydown",function(i){y(e);let o=p();return C(o.onDownButtonKeyDown(i))})("keyup",function(){y(e);let i=p();return C(i.onDownButtonKeyUp())}),d(5,ln,1,2,"span",12)(6,dn,3,2,"ng-container",2),w()()}if(t&2){let e=p();h(e.cx("buttonGroup")),a("pBind",e.ptm("buttonGroup")),c(),h(e.cn(e.cx("incrementButton"),e.incrementButtonClass)),a("pBind",e.ptm("incrementButton")),B("disabled",e.$disabled()?"":void 0)("aria-hidden",!0),c(),a("ngIf",e.incrementButtonIcon),c(),a("ngIf",!e.incrementButtonIcon),c(),h(e.cn(e.cx("decrementButton"),e.decrementButtonClass)),a("pBind",e.ptm("decrementButton")),B("disabled",e.$disabled()?"":void 0)("aria-hidden",!0),c(),a("ngIf",e.decrementButtonIcon),c(),a("ngIf",!e.decrementButtonIcon)}}function hn(t,l){if(t&1&&P(0,"span",13),t&2){let e=p(2);a("pBind",e.ptm("incrementButtonIcon"))("ngClass",e.incrementButtonIcon)}}function mn(t,l){if(t&1&&(x(),P(0,"svg",15)),t&2){let e=p(3);a("pBind",e.ptm("incrementButtonIcon"))}}function gn(t,l){}function fn(t,l){t&1&&d(0,gn,0,0,"ng-template")}function bn(t,l){if(t&1&&(U(0),d(1,mn,1,1,"svg",14)(2,fn,1,0,null,9),G()),t&2){let e=p(2);c(),a("ngIf",!e.incrementButtonIconTemplate&&!e._incrementButtonIconTemplate),c(),a("ngTemplateOutlet",e.incrementButtonIconTemplate||e._incrementButtonIconTemplate)}}function _n(t,l){if(t&1){let e=K();_(0,"button",11),O("mousedown",function(i){y(e);let o=p();return C(o.onUpButtonMouseDown(i))})("mouseup",function(){y(e);let i=p();return C(i.onUpButtonMouseUp())})("mouseleave",function(){y(e);let i=p();return C(i.onUpButtonMouseLeave())})("keydown",function(i){y(e);let o=p();return C(o.onUpButtonKeyDown(i))})("keyup",function(){y(e);let i=p();return C(i.onUpButtonKeyUp())}),d(1,hn,1,2,"span",12)(2,bn,3,2,"ng-container",2),w()}if(t&2){let e=p();h(e.cn(e.cx("incrementButton"),e.incrementButtonClass)),a("pBind",e.ptm("incrementButton")),B("disabled",e.$disabled()?"":void 0)("aria-hidden",!0),c(),a("ngIf",e.incrementButtonIcon),c(),a("ngIf",!e.incrementButtonIcon)}}function yn(t,l){if(t&1&&P(0,"span",13),t&2){let e=p(2);a("pBind",e.ptm("decrementButtonIcon"))("ngClass",e.decrementButtonIcon)}}function Cn(t,l){if(t&1&&(x(),P(0,"svg",17)),t&2){let e=p(3);a("pBind",e.ptm("decrementButtonIcon"))}}function xn(t,l){}function wn(t,l){t&1&&d(0,xn,0,0,"ng-template")}function Tn(t,l){if(t&1&&(U(0),d(1,Cn,1,1,"svg",16)(2,wn,1,0,null,9),G()),t&2){let e=p(2);c(),a("ngIf",!e.decrementButtonIconTemplate&&!e._decrementButtonIconTemplate),c(),a("ngTemplateOutlet",e.decrementButtonIconTemplate||e._decrementButtonIconTemplate)}}function vn(t,l){if(t&1){let e=K();_(0,"button",11),O("mousedown",function(i){y(e);let o=p();return C(o.onDownButtonMouseDown(i))})("mouseup",function(){y(e);let i=p();return C(i.onDownButtonMouseUp())})("mouseleave",function(){y(e);let i=p();return C(i.onDownButtonMouseLeave())})("keydown",function(i){y(e);let o=p();return C(o.onDownButtonKeyDown(i))})("keyup",function(){y(e);let i=p();return C(i.onDownButtonKeyUp())}),d(1,yn,1,2,"span",12)(2,Tn,3,2,"ng-container",2),w()}if(t&2){let e=p();h(e.cn(e.cx("decrementButton"),e.decrementButtonClass)),a("pBind",e.ptm("decrementButton")),B("disabled",e.$disabled()?"":void 0)("aria-hidden",!0),c(),a("ngIf",e.decrementButtonIcon),c(),a("ngIf",!e.decrementButtonIcon)}}var In=`
    ${ai}

    /* For PrimeNG */
    p-inputNumber.ng-invalid.ng-dirty > .p-inputtext,
    p-input-number.ng-invalid.ng-dirty > .p-inputtext,
    p-inputnumber.ng-invalid.ng-dirty > .p-inputtext {
        border-color: dt('inputtext.invalid.border.color');
    }

    p-inputNumber.ng-invalid.ng-dirty > .p-inputtext:enabled:focus,
    p-input-number.ng-invalid.ng-dirty > .p-inputtext:enabled:focus,
    p-inputnumber.ng-invalid.ng-dirty > .p-inputtext:enabled:focus {
        border-color: dt('inputtext.focus.border.color');
    }

    p-inputNumber.ng-invalid.ng-dirty > .p-inputtext::placeholder,
    p-input-number.ng-invalid.ng-dirty > .p-inputtext::placeholder,
    p-inputnumber.ng-invalid.ng-dirty > .p-inputtext::placeholder {
        color: dt('inputtext.invalid.placeholder.color');
    }
`,Sn={root:({instance:t})=>["p-inputnumber p-component p-inputwrapper",{"p-inputwrapper-filled":t.$filled()||t.allowEmpty===!1,"p-inputwrapper-focus":t.focused,"p-inputnumber-stacked":t.showButtons&&t.buttonLayout==="stacked","p-inputnumber-horizontal":t.showButtons&&t.buttonLayout==="horizontal","p-inputnumber-vertical":t.showButtons&&t.buttonLayout==="vertical","p-inputnumber-fluid":t.hasFluid,"p-invalid":t.invalid()}],pcInputText:"p-inputnumber-input",buttonGroup:"p-inputnumber-button-group",incrementButton:({instance:t})=>["p-inputnumber-button p-inputnumber-increment-button",{"p-disabled":t.showButtons&&t.max()!=null&&t.maxlength()}],decrementButton:({instance:t})=>["p-inputnumber-button p-inputnumber-decrement-button",{"p-disabled":t.showButtons&&t.min()!=null&&t.minlength()}],clearIcon:"p-inputnumber-clear-icon"},li=(()=>{class t extends he{name="inputnumber";style=In;classes=Sn;static \u0275fac=(()=>{let e;return function(i){return(e||(e=I(t)))(i||t)}})();static \u0275prov=oe({token:t,factory:t.\u0275fac})}return t})();var si=new pe("INPUTNUMBER_INSTANCE"),kn={provide:Ke,useExisting:Fe(()=>ut),multi:!0},ut=(()=>{class t extends Ht{injector;$pcInputNumber=R(si,{optional:!0,skipSelf:!0})??void 0;_componentStyle=R(li);bindDirectiveInstance=R(F,{self:!0});onAfterViewChecked(){this.bindDirectiveInstance.setAttrs(this.ptms(["host","root"]))}showButtons=!1;format=!0;buttonLayout="stacked";inputId;styleClass;placeholder;tabindex;title;ariaLabelledBy;ariaDescribedBy;ariaLabel;ariaRequired;autocomplete;incrementButtonClass;decrementButtonClass;incrementButtonIcon;decrementButtonIcon;readonly;allowEmpty=!0;locale;localeMatcher;mode="decimal";currency;currencyDisplay;useGrouping=!0;minFractionDigits;maxFractionDigits;prefix;suffix;inputStyle;inputStyleClass;showClear=!1;autofocus;onInput=new D;onFocus=new D;onBlur=new D;onKeyDown=new D;onClear=new D;clearIconTemplate;incrementButtonIconTemplate;decrementButtonIconTemplate;templates;input;_clearIconTemplate;_incrementButtonIconTemplate;_decrementButtonIconTemplate;value;focused;initialized;groupChar="";prefixChar="";suffixChar="";isSpecialChar;timer;lastValue;_numeral;numberFormat;_decimal;_decimalChar="";_group;_minusSign;_currency;_prefix;_suffix;_index;ngControl=null;constructor(e){super(),this.injector=e}onChanges(e){["locale","localeMatcher","mode","currency","currencyDisplay","useGrouping","minFractionDigits","maxFractionDigits","prefix","suffix"].some(i=>!!e[i])&&this.updateConstructParser()}onInit(){this.ngControl=this.injector.get(Qe,null,{optional:!0}),this.constructParser(),this.initialized=!0}onAfterContentInit(){this.templates.forEach(e=>{switch(e.getType()){case"clearicon":this._clearIconTemplate=e.template;break;case"incrementbuttonicon":this._incrementButtonIconTemplate=e.template;break;case"decrementbuttonicon":this._decrementButtonIconTemplate=e.template;break}})}getOptions(){let e=(r,s,u)=>{if(!(r==null||isNaN(r)||!isFinite(r)))return Math.max(s,Math.min(u,Math.floor(r)))},n=e(this.minFractionDigits,0,20),i=e(this.maxFractionDigits,0,100),o=n!=null&&i!=null&&n>i?i:n;return{localeMatcher:this.localeMatcher,style:this.mode,currency:this.currency,currencyDisplay:this.currencyDisplay,useGrouping:this.useGrouping,minimumFractionDigits:o,maximumFractionDigits:i}}constructParser(){let e=this.getOptions(),n=Object.fromEntries(Object.entries(e).filter(([r,s])=>s!==void 0));this.numberFormat=new Intl.NumberFormat(this.locale,n);let i=[...new Intl.NumberFormat(this.locale,{useGrouping:!1}).format(9876543210)].reverse(),o=new Map(i.map((r,s)=>[r,s]));this._numeral=new RegExp(`[${i.join("")}]`,"g"),this._group=this.getGroupingExpression(),this._minusSign=this.getMinusSignExpression(),this._currency=this.getCurrencyExpression(),this._decimal=this.getDecimalExpression(),this._decimalChar=this.getDecimalChar(),this._suffix=this.getSuffixExpression(),this._prefix=this.getPrefixExpression(),this._index=r=>o.get(r)}updateConstructParser(){this.initialized&&this.constructParser()}escapeRegExp(e){return e.replace(/[-[\]{}()*+?.,\\^$|#\s]/g,"\\$&")}getDecimalExpression(){let e=this.getDecimalChar();return new RegExp(`[${e}]`,"g")}getDecimalChar(){return new Intl.NumberFormat(this.locale,ze(_e({},this.getOptions()),{useGrouping:!1})).format(1.1).replace(this._currency,"").trim().replace(this._numeral,"")}getGroupingExpression(){let e=new Intl.NumberFormat(this.locale,{useGrouping:!0});return this.groupChar=e.format(1e6).trim().replace(this._numeral,"").charAt(0),new RegExp(`[${this.groupChar}]`,"g")}getMinusSignExpression(){let e=new Intl.NumberFormat(this.locale,{useGrouping:!1});return new RegExp(`[${e.format(-1).trim().replace(this._numeral,"")}]`,"g")}getCurrencyExpression(){if(this.currency){let e=new Intl.NumberFormat(this.locale,{style:"currency",currency:this.currency,currencyDisplay:this.currencyDisplay,minimumFractionDigits:0,maximumFractionDigits:0});return new RegExp(`[${e.format(1).replace(/\s/g,"").replace(this._numeral,"").replace(this._group,"")}]`,"g")}return new RegExp("[]","g")}getPrefixExpression(){if(this.prefix)this.prefixChar=this.prefix;else{let e=new Intl.NumberFormat(this.locale,{style:this.mode,currency:this.currency,currencyDisplay:this.currencyDisplay});this.prefixChar=e.format(1).split("1")[0]}return new RegExp(`${this.escapeRegExp(this.prefixChar||"")}`,"g")}getSuffixExpression(){if(this.suffix)this.suffixChar=this.suffix;else{let e=new Intl.NumberFormat(this.locale,{style:this.mode,currency:this.currency,currencyDisplay:this.currencyDisplay,minimumFractionDigits:0,maximumFractionDigits:0});this.suffixChar=e.format(1).split("1")[1]}return new RegExp(`${this.escapeRegExp(this.suffixChar||"")}`,"g")}formatValue(e){if(e!=null){if(e==="-")return e;if(this.format){let i=new Intl.NumberFormat(this.locale,this.getOptions()).format(e);return this.prefix&&e!=this.prefix&&(i=this.prefix+i),this.suffix&&e!=this.suffix&&(i=i+this.suffix),i}return e.toString()}return""}parseValue(e){let n=this._suffix?new RegExp(this._suffix,""):/(?:)/,i=this._prefix?new RegExp(this._prefix,""):/(?:)/,o=this._currency?new RegExp(this._currency,""):/(?:)/,r=e.replace(n,"").replace(i,"").trim().replace(/\s/g,"").replace(o,"").replace(this._group,"").replace(this._minusSign,"-").replace(this._decimal,".").replace(this._numeral,this._index);if(r){if(r==="-")return r;let s=+r;return isNaN(s)?null:s}return null}repeat(e,n,i){if(this.readonly)return;let o=n||500;this.clearTimer(),this.timer=setTimeout(()=>{this.repeat(e,40,i)},o),this.spin(e,i)}spin(e,n){let i=(this.step()??1)*n,o=this.parseValue(this.input?.nativeElement.value)||0,r=this.validateValue(o+i),s=this.maxlength();s&&s<this.formatValue(r).length||(this.updateInput(r,null,"spin",null),this.updateModel(e,r),this.handleOnInput(e,o,r))}clear(){this.value=null,this.onModelChange(this.value),this.onClear.emit()}onUpButtonMouseDown(e){if(e.button===2){this.clearTimer();return}this.$disabled()||(this.input?.nativeElement.focus(),this.repeat(e,null,1),e.preventDefault())}onUpButtonMouseUp(){this.$disabled()||this.clearTimer()}onUpButtonMouseLeave(){this.$disabled()||this.clearTimer()}onUpButtonKeyDown(e){(e.keyCode===32||e.keyCode===13)&&this.repeat(e,null,1)}onUpButtonKeyUp(){this.$disabled()||this.clearTimer()}onDownButtonMouseDown(e){if(e.button===2){this.clearTimer();return}this.$disabled()||(this.input?.nativeElement.focus(),this.repeat(e,null,-1),e.preventDefault())}onDownButtonMouseUp(){this.$disabled()||this.clearTimer()}onDownButtonMouseLeave(){this.$disabled()||this.clearTimer()}onDownButtonKeyUp(){this.$disabled()||this.clearTimer()}onDownButtonKeyDown(e){(e.keyCode===32||e.keyCode===13)&&this.repeat(e,null,-1)}onUserInput(e){this.readonly||(this.isSpecialChar&&(e.target.value=this.lastValue),this.isSpecialChar=!1)}onInputKeyDown(e){if(this.readonly)return;if(this.lastValue=e.target.value,e.shiftKey||e.altKey){this.isSpecialChar=!0;return}let n=e.target.selectionStart,i=e.target.selectionEnd,o=e.target.value,r=null;switch(e.altKey&&e.preventDefault(),e.key){case"ArrowUp":this.spin(e,1),e.preventDefault();break;case"ArrowDown":this.spin(e,-1),e.preventDefault();break;case"ArrowLeft":for(let s=n;s<=o.length;s++){let u=s===0?0:s-1;if(this.isNumeralChar(o.charAt(u))){this.input.nativeElement.setSelectionRange(s,s);break}}break;case"ArrowRight":for(let s=i;s>=0;s--)if(this.isNumeralChar(o.charAt(s))){this.input.nativeElement.setSelectionRange(s,s);break}break;case"Tab":case"Enter":r=this.validateValue(this.parseValue(this.input.nativeElement.value)),this.input.nativeElement.value=this.formatValue(r),this.input.nativeElement.setAttribute("aria-valuenow",r),this.updateModel(e,r);break;case"Backspace":{if(e.preventDefault(),n===i){if(n==1&&this.prefix||n==o.length&&this.suffix)break;let s=o.charAt(n-1),{decimalCharIndex:u,decimalCharIndexWithoutPrefix:b}=this.getDecimalCharIndexes(o);if(this.isNumeralChar(s)){let f=this.getDecimalLength(o);if(this._group.test(s))this._group.lastIndex=0,r=o.slice(0,n-2)+o.slice(n-1);else if(this._decimal.test(s))this._decimal.lastIndex=0,f?this.input?.nativeElement.setSelectionRange(n-1,n-1):r=o.slice(0,n-1)+o.slice(n);else if(u>0&&n>u){let M=this.isDecimalMode()&&(this.minFractionDigits||0)<f?"":"0";r=o.slice(0,n-1)+M+o.slice(n)}else b===1?(r=o.slice(0,n-1)+"0"+o.slice(n),r=this.parseValue(r)>0?r:""):r=o.slice(0,n-1)+o.slice(n)}else this.mode==="currency"&&this._currency&&s.search(this._currency)!=-1&&(r=o.slice(1));this.updateValue(e,r,null,"delete-single")}else r=this.deleteRange(o,n,i),this.updateValue(e,r,null,"delete-range");break}case"Delete":if(e.preventDefault(),n===i){if(n==0&&this.prefix||n==o.length-1&&this.suffix)break;let s=o.charAt(n),{decimalCharIndex:u,decimalCharIndexWithoutPrefix:b}=this.getDecimalCharIndexes(o);if(this.isNumeralChar(s)){let f=this.getDecimalLength(o);if(this._group.test(s))this._group.lastIndex=0,r=o.slice(0,n)+o.slice(n+2);else if(this._decimal.test(s))this._decimal.lastIndex=0,f?this.input?.nativeElement.setSelectionRange(n+1,n+1):r=o.slice(0,n)+o.slice(n+1);else if(u>0&&n>u){let M=this.isDecimalMode()&&(this.minFractionDigits||0)<f?"":"0";r=o.slice(0,n)+M+o.slice(n+1)}else b===1?(r=o.slice(0,n)+"0"+o.slice(n+1),r=this.parseValue(r)>0?r:""):r=o.slice(0,n)+o.slice(n+1)}this.updateValue(e,r,null,"delete-back-single")}else r=this.deleteRange(o,n,i),this.updateValue(e,r,null,"delete-range");break;case"Home":this.min()&&(this.updateModel(e,this.min()),e.preventDefault());break;case"End":this.max()&&(this.updateModel(e,this.max()),e.preventDefault());break;default:break}this.onKeyDown.emit(e)}onInputKeyPress(e){if(this.readonly)return;let n=e.which||e.keyCode,i=String.fromCharCode(n),o=this.isDecimalSign(i),r=this.isMinusSign(i);n!=13&&e.preventDefault(),!o&&e.code==="NumpadDecimal"&&(o=!0,i=this._decimalChar,n=i.charCodeAt(0));let{value:s,selectionStart:u,selectionEnd:b}=this.input.nativeElement,f=this.parseValue(s+i),M=f!=null?f.toString():"",z=s.substring(u,b),E=this.parseValue(z),A=E!=null?E.toString():"";if(u!==b&&A.length>0){this.insert(e,i,{isDecimalSign:o,isMinusSign:r});return}let H=this.maxlength();H&&M.length>H||(48<=n&&n<=57||r||o)&&this.insert(e,i,{isDecimalSign:o,isMinusSign:r})}onPaste(e){if(!this.$disabled()&&!this.readonly){e.preventDefault();let n=(e.clipboardData||this.document.defaultView.clipboardData).getData("Text");if(this.inputId==="integeronly"&&/[^\d-]/.test(n))return;if(n){this.maxlength()&&(n=n.toString().substring(0,this.maxlength()));let i=this.parseValue(n);i!=null&&this.insert(e,i.toString())}}}allowMinusSign(){let e=this.min();return e==null||e<0}isMinusSign(e){return this._minusSign.test(e)||e==="-"?(this._minusSign.lastIndex=0,!0):!1}isDecimalSign(e){return this._decimal.test(e)?(this._decimal.lastIndex=0,!0):!1}isDecimalMode(){return this.mode==="decimal"}getDecimalCharIndexes(e){let n=e.search(this._decimal);this._decimal.lastIndex=0;let o=e.replace(this._prefix,"").trim().replace(/\s/g,"").replace(this._currency,"").search(this._decimal);return this._decimal.lastIndex=0,{decimalCharIndex:n,decimalCharIndexWithoutPrefix:o}}getCharIndexes(e){let n=e.search(this._decimal);this._decimal.lastIndex=0;let i=e.search(this._minusSign);this._minusSign.lastIndex=0;let o=e.search(this._suffix);this._suffix.lastIndex=0;let r=e.search(this._currency);return this._currency.lastIndex=0,{decimalCharIndex:n,minusCharIndex:i,suffixCharIndex:o,currencyCharIndex:r}}insert(e,n,i={isDecimalSign:!1,isMinusSign:!1}){let o=n.search(this._minusSign);if(this._minusSign.lastIndex=0,!this.allowMinusSign()&&o!==-1)return;let r=this.input?.nativeElement.selectionStart,s=this.input?.nativeElement.selectionEnd,u=this.input?.nativeElement.value.trim(),{decimalCharIndex:b,minusCharIndex:f,suffixCharIndex:M,currencyCharIndex:z}=this.getCharIndexes(u),E;if(i.isMinusSign)r===0&&(E=u,(f===-1||s!==0)&&(E=this.insertText(u,n,0,s)),this.updateValue(e,E,n,"insert"));else if(i.isDecimalSign)b>0&&r===b?this.updateValue(e,u,n,"insert"):b>r&&b<s?(E=this.insertText(u,n,r,s),this.updateValue(e,E,n,"insert")):b===-1&&this.maxFractionDigits&&(E=this.insertText(u,n,r,s),this.updateValue(e,E,n,"insert"));else{let A=this.numberFormat.resolvedOptions().maximumFractionDigits,H=r!==s?"range-insert":"insert";if(b>0&&r>b){if(r+n.length-(b+1)<=A){let ee=z>=r?z-1:M>=r?M:u.length;E=u.slice(0,r)+n+u.slice(r+n.length,ee)+u.slice(ee),this.updateValue(e,E,n,H)}}else E=this.insertText(u,n,r,s),this.updateValue(e,E,n,H)}}insertText(e,n,i,o){if((n==="."?n:n.split(".")).length===2){let s=e.slice(i,o).search(this._decimal);return this._decimal.lastIndex=0,s>0?e.slice(0,i)+this.formatValue(n)+e.slice(o):e||this.formatValue(n)}else return o-i===e.length?this.formatValue(n):i===0?n+e.slice(o):o===e.length?e.slice(0,i)+n:e.slice(0,i)+n+e.slice(o)}deleteRange(e,n,i){let o;return i-n===e.length?o="":n===0?o=e.slice(i):i===e.length?o=e.slice(0,n):o=e.slice(0,n)+e.slice(i),o}initCursor(){let e=this.input?.nativeElement.selectionStart,n=this.input?.nativeElement.selectionEnd,i=this.input?.nativeElement.value,o=i.length,r=null,s=(this.prefixChar||"").length;i=i.replace(this._prefix,""),(e===n||e!==0||n<s)&&(e-=s);let u=i.charAt(e);if(this.isNumeralChar(u))return e+s;let b=e-1;for(;b>=0;)if(u=i.charAt(b),this.isNumeralChar(u)){r=b+s;break}else b--;if(r!==null)this.input?.nativeElement.setSelectionRange(r+1,r+1);else{for(b=e;b<o;)if(u=i.charAt(b),this.isNumeralChar(u)){r=b+s;break}else b++;r!==null&&this.input?.nativeElement.setSelectionRange(r,r)}return r||0}onInputClick(){let e=this.input?.nativeElement.value;!this.readonly&&e!==zt()&&this.initCursor()}isNumeralChar(e){return e.length===1&&(this._numeral.test(e)||this._decimal.test(e)||this._group.test(e)||this._minusSign.test(e))?(this.resetRegex(),!0):!1}resetRegex(){this._numeral.lastIndex=0,this._decimal.lastIndex=0,this._group.lastIndex=0,this._minusSign.lastIndex=0}updateValue(e,n,i,o){let r=this.input?.nativeElement.value,s=null;n!=null&&(s=this.parseValue(n),s=!s&&!this.allowEmpty?0:s,this.updateInput(s,i,o,n),this.handleOnInput(e,r,s))}handleOnInput(e,n,i){this.isValueChanged(n,i)&&(this.input.nativeElement.value=this.formatValue(i),this.input?.nativeElement.setAttribute("aria-valuenow",i),this.updateModel(e,i),this.onInput.emit({originalEvent:e,value:i,formattedValue:n}))}isValueChanged(e,n){if(n===null&&e!==null)return!0;if(n!=null){let i=typeof e=="string"?this.parseValue(e):e;return n!==i}return!1}validateValue(e){if(e==="-"||e==null)return null;let n=this.min(),i=this.max();return n!=null&&e<n?this.min():i!=null&&e>i?i:e}updateInput(e,n,i,o){n=n||"";let r=this.input?.nativeElement.value,s=this.formatValue(e),u=r.length;if(s!==o&&(s=this.concatValues(s,o)),u===0){this.input.nativeElement.value=s,this.input.nativeElement.setSelectionRange(0,0);let f=this.initCursor()+n.length;this.input.nativeElement.setSelectionRange(f,f)}else{let b=this.input.nativeElement.selectionStart,f=this.input.nativeElement.selectionEnd,M=this.maxlength();if(M&&s.length>M&&(s=s.slice(0,M),b=Math.min(b,M),f=Math.min(f,M)),M&&M<s.length)return;this.input.nativeElement.value=s;let z=s.length;if(i==="range-insert"){let E=this.parseValue((r||"").slice(0,b)),H=(E!==null?E.toString():"").split("").join(`(${this.groupChar})?`),ee=new RegExp(H,"g");ee.test(s);let ve=n.split("").join(`(${this.groupChar})?`),Ie=new RegExp(ve,"g");Ie.test(s.slice(ee.lastIndex)),f=ee.lastIndex+Ie.lastIndex,this.input.nativeElement.setSelectionRange(f,f)}else if(z===u)i==="insert"||i==="delete-back-single"?this.input.nativeElement.setSelectionRange(f+1,f+1):i==="delete-single"?this.input.nativeElement.setSelectionRange(f-1,f-1):(i==="delete-range"||i==="spin")&&this.input.nativeElement.setSelectionRange(f,f);else if(i==="delete-back-single"){let E=r.charAt(f-1),A=r.charAt(f),H=u-z,ee=this._group.test(A);ee&&H===1?f+=1:!ee&&this.isNumeralChar(E)&&(f+=-1*H+1),this._group.lastIndex=0,this.input.nativeElement.setSelectionRange(f,f)}else if(r==="-"&&i==="insert"){this.input.nativeElement.setSelectionRange(0,0);let A=this.initCursor()+n.length+1;this.input.nativeElement.setSelectionRange(A,A)}else f=f+(z-u),this.input.nativeElement.setSelectionRange(f,f)}this.input.nativeElement.setAttribute("aria-valuenow",e)}concatValues(e,n){if(e&&n){let i=n.search(this._decimal);return this._decimal.lastIndex=0,this.suffixChar?i!==-1?e.replace(this.suffixChar,"").split(this._decimal)[0]+n.replace(this.suffixChar,"").slice(i)+this.suffixChar:e:i!==-1?e.split(this._decimal)[0]+n.slice(i):e}return e}getDecimalLength(e){if(e){let n=e.split(this._decimal);if(n.length===2)return n[1].replace(this._suffix,"").trim().replace(/\s/g,"").replace(this._currency,"").length}return 0}onInputFocus(e){this.focused=!0,this.onFocus.emit(e)}onInputBlur(e){this.focused=!1;let n=this.validateValue(this.parseValue(this.input.nativeElement.value)),i=n?.toString();this.input.nativeElement.value=this.formatValue(i),this.input.nativeElement.setAttribute("aria-valuenow",i),this.updateModel(e,n),this.onModelTouched(),this.onBlur.emit(e)}formattedValue(){let e=!this.value&&!this.allowEmpty?0:this.value;return this.formatValue(e)}updateModel(e,n){let i=this.ngControl?.control?.updateOn==="blur";this.value!==n?(this.value=n,i&&this.focused||this.onModelChange(n)):i&&this.onModelChange(n)}writeControlValue(e,n){this.value=e&&Number(e),n(e),this.cd.markForCheck()}clearTimer(){this.timer&&clearInterval(this.timer)}static \u0275fac=function(n){return new(n||t)(Ce(yt))};static \u0275cmp=S({type:t,selectors:[["p-inputNumber"],["p-inputnumber"],["p-input-number"]],contentQueries:function(n,i,o){if(n&1&&(v(o,ji,4),v(o,$i,4),v(o,qi,4),v(o,ne,4)),n&2){let r;m(r=g())&&(i.clearIconTemplate=r.first),m(r=g())&&(i.incrementButtonIconTemplate=r.first),m(r=g())&&(i.decrementButtonIconTemplate=r.first),m(r=g())&&(i.templates=r)}},viewQuery:function(n,i){if(n&1&&Q(Wi,5),n&2){let o;m(o=g())&&(i.input=o.first)}},hostVars:2,hostBindings:function(n,i){n&2&&h(i.cn(i.cx("root"),i.styleClass))},inputs:{showButtons:[2,"showButtons","showButtons",T],format:[2,"format","format",T],buttonLayout:"buttonLayout",inputId:"inputId",styleClass:"styleClass",placeholder:"placeholder",tabindex:[2,"tabindex","tabindex",$],title:"title",ariaLabelledBy:"ariaLabelledBy",ariaDescribedBy:"ariaDescribedBy",ariaLabel:"ariaLabel",ariaRequired:[2,"ariaRequired","ariaRequired",T],autocomplete:"autocomplete",incrementButtonClass:"incrementButtonClass",decrementButtonClass:"decrementButtonClass",incrementButtonIcon:"incrementButtonIcon",decrementButtonIcon:"decrementButtonIcon",readonly:[2,"readonly","readonly",T],allowEmpty:[2,"allowEmpty","allowEmpty",T],locale:"locale",localeMatcher:"localeMatcher",mode:"mode",currency:"currency",currencyDisplay:"currencyDisplay",useGrouping:[2,"useGrouping","useGrouping",T],minFractionDigits:[2,"minFractionDigits","minFractionDigits",e=>$(e,void 0)],maxFractionDigits:[2,"maxFractionDigits","maxFractionDigits",e=>$(e,void 0)],prefix:"prefix",suffix:"suffix",inputStyle:"inputStyle",inputStyleClass:"inputStyleClass",showClear:[2,"showClear","showClear",T],autofocus:[2,"autofocus","autofocus",T]},outputs:{onInput:"onInput",onFocus:"onFocus",onBlur:"onBlur",onKeyDown:"onKeyDown",onClear:"onClear"},features:[te([kn,li,{provide:si,useExisting:t},{provide:me,useExisting:t}]),re([F]),k],decls:6,vars:36,consts:[["input",""],["pInputText","","role","spinbutton","inputmode","decimal",3,"input","keydown","keypress","paste","click","focus","blur","value","ngStyle","variant","invalid","pSize","pt","pAutoFocus","fluid"],[4,"ngIf"],[3,"pBind","class",4,"ngIf"],["type","button","tabindex","-1",3,"pBind","class","mousedown","mouseup","mouseleave","keydown","keyup",4,"ngIf"],["data-p-icon","times",3,"pBind","class","click",4,"ngIf"],[3,"pBind","class","click",4,"ngIf"],["data-p-icon","times",3,"click","pBind"],[3,"click","pBind"],[4,"ngTemplateOutlet"],[3,"pBind"],["type","button","tabindex","-1",3,"mousedown","mouseup","mouseleave","keydown","keyup","pBind"],[3,"pBind","ngClass",4,"ngIf"],[3,"pBind","ngClass"],["data-p-icon","angle-up",3,"pBind",4,"ngIf"],["data-p-icon","angle-up",3,"pBind"],["data-p-icon","angle-down",3,"pBind",4,"ngIf"],["data-p-icon","angle-down",3,"pBind"]],template:function(n,i){if(n&1){let o=K();_(0,"input",1,0),O("input",function(s){return y(o),C(i.onUserInput(s))})("keydown",function(s){return y(o),C(i.onInputKeyDown(s))})("keypress",function(s){return y(o),C(i.onInputKeyPress(s))})("paste",function(s){return y(o),C(i.onPaste(s))})("click",function(){return y(o),C(i.onInputClick())})("focus",function(s){return y(o),C(i.onInputFocus(s))})("blur",function(s){return y(o),C(i.onInputBlur(s))}),w(),d(2,en,3,2,"ng-container",2)(3,un,7,17,"span",3)(4,_n,3,7,"button",4)(5,vn,3,7,"button",4)}n&2&&(h(i.cn(i.cx("pcInputText"),i.inputStyleClass)),a("value",i.formattedValue())("ngStyle",i.inputStyle)("variant",i.$variant())("invalid",i.invalid())("pSize",i.size())("pt",i.ptm("pcInputText"))("pAutoFocus",i.autofocus)("fluid",i.hasFluid),B("id",i.inputId)("aria-valuemin",i.min())("aria-valuemax",i.max())("aria-valuenow",i.value)("placeholder",i.placeholder)("aria-label",i.ariaLabel)("aria-labelledby",i.ariaLabelledBy)("aria-describedby",i.ariaDescribedBy)("title",i.title)("size",i.inputSize())("name",i.name())("autocomplete",i.autocomplete)("maxlength",i.maxlength())("minlength",i.minlength())("tabindex",i.tabindex)("aria-required",i.ariaRequired)("min",i.min())("max",i.max())("step",i.step()??1)("required",i.required()?"":void 0)("readonly",i.readonly?"":void 0)("disabled",i.$disabled()?"":void 0),c(2),a("ngIf",i.buttonLayout!="vertical"&&i.showClear&&i.value),c(),a("ngIf",i.showButtons&&i.buttonLayout==="stacked"),c(),a("ngIf",i.showButtons&&i.buttonLayout!=="stacked"),c(),a("ngIf",i.showButtons&&i.buttonLayout!=="stacked"))},dependencies:[ue,Te,le,se,Be,At,Ot,Rt,ii,Yt,Y,we,F],encapsulation:2,changeDetection:0})}return t})();var ci=`
    .p-paginator {
        display: flex;
        align-items: center;
        justify-content: center;
        flex-wrap: wrap;
        background: dt('paginator.background');
        color: dt('paginator.color');
        padding: dt('paginator.padding');
        border-radius: dt('paginator.border.radius');
        gap: dt('paginator.gap');
    }

    .p-paginator-content {
        display: flex;
        align-items: center;
        justify-content: center;
        flex-wrap: wrap;
        gap: dt('paginator.gap');
    }

    .p-paginator-content-start {
        margin-inline-end: auto;
    }

    .p-paginator-content-end {
        margin-inline-start: auto;
    }

    .p-paginator-page,
    .p-paginator-next,
    .p-paginator-last,
    .p-paginator-first,
    .p-paginator-prev {
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        line-height: 1;
        user-select: none;
        overflow: hidden;
        position: relative;
        background: dt('paginator.nav.button.background');
        border: 0 none;
        color: dt('paginator.nav.button.color');
        min-width: dt('paginator.nav.button.width');
        height: dt('paginator.nav.button.height');
        transition:
            background dt('paginator.transition.duration'),
            color dt('paginator.transition.duration'),
            outline-color dt('paginator.transition.duration'),
            box-shadow dt('paginator.transition.duration');
        border-radius: dt('paginator.nav.button.border.radius');
        padding: 0;
        margin: 0;
    }

    .p-paginator-page:focus-visible,
    .p-paginator-next:focus-visible,
    .p-paginator-last:focus-visible,
    .p-paginator-first:focus-visible,
    .p-paginator-prev:focus-visible {
        box-shadow: dt('paginator.nav.button.focus.ring.shadow');
        outline: dt('paginator.nav.button.focus.ring.width') dt('paginator.nav.button.focus.ring.style') dt('paginator.nav.button.focus.ring.color');
        outline-offset: dt('paginator.nav.button.focus.ring.offset');
    }

    .p-paginator-page:not(.p-disabled):not(.p-paginator-page-selected):hover,
    .p-paginator-first:not(.p-disabled):hover,
    .p-paginator-prev:not(.p-disabled):hover,
    .p-paginator-next:not(.p-disabled):hover,
    .p-paginator-last:not(.p-disabled):hover {
        background: dt('paginator.nav.button.hover.background');
        color: dt('paginator.nav.button.hover.color');
    }

    .p-paginator-page.p-paginator-page-selected {
        background: dt('paginator.nav.button.selected.background');
        color: dt('paginator.nav.button.selected.color');
    }

    .p-paginator-current {
        color: dt('paginator.current.page.report.color');
    }

    .p-paginator-pages {
        display: flex;
        align-items: center;
        gap: dt('paginator.gap');
    }

    .p-paginator-jtp-input .p-inputtext {
        max-width: dt('paginator.jump.to.page.input.max.width');
    }

    .p-paginator-first:dir(rtl),
    .p-paginator-prev:dir(rtl),
    .p-paginator-next:dir(rtl),
    .p-paginator-last:dir(rtl) {
        transform: rotate(180deg);
    }
`;var Mn=["dropdownicon"],Dn=["firstpagelinkicon"],Bn=["previouspagelinkicon"],Pn=["lastpagelinkicon"],Ln=["nextpagelinkicon"],Je=t=>({$implicit:t}),Vn=t=>({pageLink:t});function zn(t,l){t&1&&V(0)}function Fn(t,l){if(t&1&&(_(0,"div",10),d(1,zn,1,0,"ng-container",11),w()),t&2){let e=p();h(e.cx("contentStart")),a("pBind",e.ptm("contentStart")),c(),a("ngTemplateOutlet",e.templateLeft)("ngTemplateOutletContext",j(5,Je,e.paginatorState))}}function Nn(t,l){if(t&1&&(_(0,"span",10),ke(1),w()),t&2){let e=p();h(e.cx("current")),a("pBind",e.ptm("current")),c(),De(e.currentPageReport)}}function Rn(t,l){if(t&1&&(x(),P(0,"svg",14)),t&2){let e=p(2);h(e.cx("firstIcon")),a("pBind",e.ptm("firstIcon"))}}function On(t,l){}function Hn(t,l){t&1&&d(0,On,0,0,"ng-template")}function An(t,l){if(t&1&&(_(0,"span"),d(1,Hn,1,0,null,15),w()),t&2){let e=p(2);h(e.cx("firstIcon")),c(),a("ngTemplateOutlet",e.firstPageLinkIconTemplate||e._firstPageLinkIconTemplate)}}function Kn(t,l){if(t&1){let e=K();_(0,"button",12),O("click",function(i){y(e);let o=p();return C(o.changePageToFirst(i))}),d(1,Rn,1,3,"svg",13)(2,An,2,3,"span",4),w()}if(t&2){let e=p();h(e.cx("first")),a("pBind",e.ptm("first")),B("aria-label",e.getAriaLabel("firstPageLabel")),c(),a("ngIf",!e.firstPageLinkIconTemplate&&!e._firstPageLinkIconTemplate),c(),a("ngIf",e.firstPageLinkIconTemplate||e._firstPageLinkIconTemplate)}}function Qn(t,l){if(t&1&&(x(),P(0,"svg",16)),t&2){let e=p();h(e.cx("prevIcon")),a("pBind",e.ptm("prevIcon"))}}function Un(t,l){}function Gn(t,l){t&1&&d(0,Un,0,0,"ng-template")}function jn(t,l){if(t&1&&(_(0,"span"),d(1,Gn,1,0,null,15),w()),t&2){let e=p();h(e.cx("prevIcon")),c(),a("ngTemplateOutlet",e.previousPageLinkIconTemplate||e._previousPageLinkIconTemplate)}}function $n(t,l){if(t&1){let e=K();_(0,"button",12),O("click",function(i){let o=y(e).$implicit,r=p(2);return C(r.onPageLinkClick(i,o-1))}),ke(1),w()}if(t&2){let e=l.$implicit,n=p(2);h(n.cx("page",j(6,Vn,e))),a("pBind",n.ptm("page")),B("aria-label",n.getPageAriaLabel(e))("aria-current",e-1==n.getPage()?"page":void 0),c(),xt(" ",n.getLocalization(e)," ")}}function qn(t,l){if(t&1&&(_(0,"span",10),d(1,$n,2,8,"button",17),w()),t&2){let e=p();h(e.cx("pages")),a("pBind",e.ptm("pages")),c(),a("ngForOf",e.pageLinks)}}function Wn(t,l){if(t&1&&ke(0),t&2){let e=p(2);De(e.currentPageReport)}}function Zn(t,l){t&1&&V(0)}function Jn(t,l){if(t&1&&d(0,Zn,1,0,"ng-container",11),t&2){let e=l.$implicit,n=p(3);a("ngTemplateOutlet",n.jumpToPageItemTemplate)("ngTemplateOutletContext",j(2,Je,e))}}function Xn(t,l){t&1&&(U(0),d(1,Jn,1,4,"ng-template",21),G())}function Yn(t,l){t&1&&V(0)}function eo(t,l){if(t&1&&d(0,Yn,1,0,"ng-container",15),t&2){let e=p(3);a("ngTemplateOutlet",e.dropdownIconTemplate||e._dropdownIconTemplate)}}function to(t,l){t&1&&d(0,eo,1,1,"ng-template",22)}function io(t,l){if(t&1){let e=K();_(0,"p-select",18),O("onChange",function(i){y(e);let o=p();return C(o.onPageDropdownChange(i))}),d(1,Wn,1,1,"ng-template",19)(2,Xn,2,0,"ng-container",20)(3,to,1,0,null,20),w()}if(t&2){let e=p();a("options",e.pageItems)("ngModel",e.getPage())("disabled",e.empty())("styleClass",e.cx("pcJumpToPageDropdown"))("appendTo",e.dropdownAppendTo||e.$appendTo())("scrollHeight",e.dropdownScrollHeight)("pt",e.ptm("pcJumpToPageDropdown")),B("aria-label",e.getAriaLabel("jumpToPageDropdownLabel")),c(2),a("ngIf",e.jumpToPageItemTemplate),c(),a("ngIf",e.dropdownIconTemplate||e._dropdownIconTemplate)}}function no(t,l){if(t&1&&(x(),P(0,"svg",23)),t&2){let e=p();h(e.cx("nextIcon")),a("pBind",e.ptm("nextIcon"))}}function oo(t,l){}function ro(t,l){t&1&&d(0,oo,0,0,"ng-template")}function ao(t,l){if(t&1&&(_(0,"span"),d(1,ro,1,0,null,15),w()),t&2){let e=p();h(e.cx("nextIcon")),c(),a("ngTemplateOutlet",e.nextPageLinkIconTemplate||e._nextPageLinkIconTemplate)}}function lo(t,l){if(t&1&&(x(),P(0,"svg",25)),t&2){let e=p(2);h(e.cx("lastIcon")),a("pBind",e.ptm("lastIcon"))}}function so(t,l){}function co(t,l){t&1&&d(0,so,0,0,"ng-template")}function po(t,l){if(t&1&&(_(0,"span"),d(1,co,1,0,null,15),w()),t&2){let e=p(2);h(e.cx("lastIcon")),c(),a("ngTemplateOutlet",e.lastPageLinkIconTemplate||e._lastPageLinkIconTemplate)}}function uo(t,l){if(t&1){let e=K();_(0,"button",2),O("click",function(i){y(e);let o=p();return C(o.changePageToLast(i))}),d(1,lo,1,3,"svg",24)(2,po,2,3,"span",4),w()}if(t&2){let e=p();h(e.cx("last")),a("pBind",e.ptm("last"))("disabled",e.isLastPage()||e.empty()),B("aria-label",e.getAriaLabel("lastPageLabel")),c(),a("ngIf",!e.lastPageLinkIconTemplate&&!e._lastPageLinkIconTemplate),c(),a("ngIf",e.lastPageLinkIconTemplate||e._lastPageLinkIconTemplate)}}function ho(t,l){if(t&1){let e=K();_(0,"p-inputnumber",26),O("ngModelChange",function(i){y(e);let o=p();return C(o.changePage(i-1))}),w()}if(t&2){let e=p();h(e.cx("pcJumpToPageInput")),a("pt",e.ptm("pcJumpToPageInput"))("ngModel",e.currentPage())("disabled",e.empty())}}function mo(t,l){t&1&&V(0)}function go(t,l){if(t&1&&d(0,mo,1,0,"ng-container",11),t&2){let e=l.$implicit,n=p(3);a("ngTemplateOutlet",n.dropdownItemTemplate)("ngTemplateOutletContext",j(2,Je,e))}}function fo(t,l){t&1&&(U(0),d(1,go,1,4,"ng-template",21),G())}function bo(t,l){t&1&&V(0)}function _o(t,l){if(t&1&&d(0,bo,1,0,"ng-container",15),t&2){let e=p(3);a("ngTemplateOutlet",e.dropdownIconTemplate||e._dropdownIconTemplate)}}function yo(t,l){t&1&&d(0,_o,1,1,"ng-template",22)}function Co(t,l){if(t&1){let e=K();_(0,"p-select",27),vt("ngModelChange",function(i){y(e);let o=p();return Tt(o.rows,i)||(o.rows=i),C(i)}),O("onChange",function(i){y(e);let o=p();return C(o.onRppChange(i))}),d(1,fo,2,0,"ng-container",20)(2,yo,1,0,null,20),w()}if(t&2){let e=p();a("options",e.rowsPerPageItems),wt("ngModel",e.rows),a("styleClass",e.cx("pcRowPerPageDropdown"))("disabled",e.empty())("appendTo",e.dropdownAppendTo||e.$appendTo())("scrollHeight",e.dropdownScrollHeight)("ariaLabel",e.getAriaLabel("rowsPerPageLabel"))("pt",e.ptm("pcRowPerPageDropdown")),c(),a("ngIf",e.dropdownItemTemplate),c(),a("ngIf",e.dropdownIconTemplate||e._dropdownIconTemplate)}}function xo(t,l){t&1&&V(0)}function wo(t,l){if(t&1&&(_(0,"div",10),d(1,xo,1,0,"ng-container",11),w()),t&2){let e=p();h(e.cx("contentEnd")),a("pBind",e.ptm("contentEnd")),c(),a("ngTemplateOutlet",e.templateRight)("ngTemplateOutletContext",j(5,Je,e.paginatorState))}}var To={paginator:({instance:t})=>["p-paginator p-component"],content:"p-paginator-content",contentStart:"p-paginator-content-start",contentEnd:"p-paginator-content-end",first:({instance:t})=>["p-paginator-first",{"p-disabled":t.isFirstPage()||t.empty()}],firstIcon:"p-paginator-first-icon",prev:({instance:t})=>["p-paginator-prev",{"p-disabled":t.isFirstPage()||t.empty()}],prevIcon:"p-paginator-prev-icon",next:({instance:t})=>["p-paginator-next",{"p-disabled":t.isLastPage()||t.empty()}],nextIcon:"p-paginator-next-icon",last:({instance:t})=>["p-paginator-last",{"p-disabled":t.isLastPage()||t.empty()}],lastIcon:"p-paginator-last-icon",pages:"p-paginator-pages",page:({instance:t,pageLink:l})=>["p-paginator-page",{"p-paginator-page-selected":l-1==t.getPage()}],current:"p-paginator-current",pcRowPerPageDropdown:"p-paginator-rpp-dropdown",pcJumpToPageDropdown:"p-paginator-jtp-dropdown",pcJumpToPageInput:"p-paginator-jtp-input"},pi=(()=>{class t extends he{name="paginator";style=ci;classes=To;static \u0275fac=(()=>{let e;return function(i){return(e||(e=I(t)))(i||t)}})();static \u0275prov=oe({token:t,factory:t.\u0275fac})}return t})();var di=new pe("PAGINATOR_INSTANCE"),ht=(()=>{class t extends fe{bindDirectiveInstance=R(F,{self:!0});$pcPaginator=R(di,{optional:!0,skipSelf:!0})??void 0;onAfterViewChecked(){this.bindDirectiveInstance.setAttrs(this.ptms(["host","root"]))}pageLinkSize=5;styleClass;alwaysShow=!0;dropdownAppendTo;templateLeft;templateRight;dropdownScrollHeight="200px";currentPageReportTemplate="{currentPage} of {totalPages}";showCurrentPageReport;showFirstLastIcon=!0;totalRecords=0;rows=0;rowsPerPageOptions;showJumpToPageDropdown;showJumpToPageInput;jumpToPageItemTemplate;showPageLinks=!0;locale;dropdownItemTemplate;get first(){return this._first}set first(e){this._first=e}appendTo=ie(void 0);onPageChange=new D;dropdownIconTemplate;firstPageLinkIconTemplate;previousPageLinkIconTemplate;lastPageLinkIconTemplate;nextPageLinkIconTemplate;templates;_dropdownIconTemplate;_firstPageLinkIconTemplate;_previousPageLinkIconTemplate;_lastPageLinkIconTemplate;_nextPageLinkIconTemplate;pageLinks;pageItems;rowsPerPageItems;paginatorState;_first=0;_page=0;_componentStyle=R(pi);$appendTo=Oe(()=>this.appendTo()||this.config.overlayAppendTo());get display(){return this.alwaysShow||this.pageLinks&&this.pageLinks.length>1?null:"none"}constructor(){super()}onInit(){this.updatePaginatorState()}onAfterContentInit(){this.templates.forEach(e=>{switch(e.getType()){case"dropdownicon":this._dropdownIconTemplate=e.template;break;case"firstpagelinkicon":this._firstPageLinkIconTemplate=e.template;break;case"previouspagelinkicon":this._previousPageLinkIconTemplate=e.template;break;case"lastpagelinkicon":this._lastPageLinkIconTemplate=e.template;break;case"nextpagelinkicon":this._nextPageLinkIconTemplate=e.template;break}})}getAriaLabel(e){return this.config.translation.aria?this.config.translation.aria[e]:void 0}getPageAriaLabel(e){return this.config.translation.aria?this.config.translation.aria.pageLabel?.replace(/{page}/g,`${e}`):void 0}getLocalization(e){let n=[...new Intl.NumberFormat(this.locale,{useGrouping:!1}).format(9876543210)].reverse(),i=new Map(n.map((o,r)=>[r,o]));return e>9?String(e).split("").map(r=>i.get(Number(r))).join(""):i.get(e)}onChanges(e){e.totalRecords&&(this.updatePageLinks(),this.updatePaginatorState(),this.updateFirst(),this.updateRowsPerPageOptions()),e.first&&(this._first=e.first.currentValue,this.updatePageLinks(),this.updatePaginatorState()),e.rows&&(this.updatePageLinks(),this.updatePaginatorState()),e.rowsPerPageOptions&&this.updateRowsPerPageOptions(),e.pageLinkSize&&this.updatePageLinks()}updateRowsPerPageOptions(){if(this.rowsPerPageOptions){this.rowsPerPageItems=[];let e=null;for(let n of this.rowsPerPageOptions)typeof n=="object"&&n.showAll?e={label:n.showAll,value:this.totalRecords}:this.rowsPerPageItems.push({label:String(this.getLocalization(n)),value:n});e&&this.rowsPerPageItems.push(e)}}isFirstPage(){return this.getPage()===0}isLastPage(){return this.getPage()===this.getPageCount()-1}getPageCount(){return Math.ceil(this.totalRecords/this.rows)}calculatePageLinkBoundaries(){let e=this.getPageCount(),n=Math.min(this.pageLinkSize,e),i=Math.max(0,Math.ceil(this.getPage()-n/2)),o=Math.min(e-1,i+n-1);var r=this.pageLinkSize-(o-i+1);return i=Math.max(0,i-r),[i,o]}updatePageLinks(){this.pageLinks=[];let e=this.calculatePageLinkBoundaries(),n=e[0],i=e[1];for(let o=n;o<=i;o++)this.pageLinks.push(o+1);if(this.showJumpToPageDropdown){this.pageItems=[];for(let o=0;o<this.getPageCount();o++)this.pageItems.push({label:String(o+1),value:o})}}changePage(e){var n=this.getPageCount();if(e>=0&&e<n){this._first=this.rows*e;var i={page:e,first:this.first,rows:this.rows,pageCount:n};this.updatePageLinks(),this.onPageChange.emit(i),this.updatePaginatorState()}}updateFirst(){let e=this.getPage();e>0&&this.totalRecords&&this.first>=this.totalRecords&&Promise.resolve(null).then(()=>this.changePage(e-1))}getPage(){return Math.floor(this.first/this.rows)}changePageToFirst(e){this.isFirstPage()||this.changePage(0),e.preventDefault()}changePageToPrev(e){this.changePage(this.getPage()-1),e.preventDefault()}changePageToNext(e){this.changePage(this.getPage()+1),e.preventDefault()}changePageToLast(e){this.isLastPage()||this.changePage(this.getPageCount()-1),e.preventDefault()}onPageLinkClick(e,n){this.changePage(n),e.preventDefault()}onRppChange(e){this.changePage(this.getPage())}onPageDropdownChange(e){this.changePage(e.value)}updatePaginatorState(){this.paginatorState={page:this.getPage(),pageCount:this.getPageCount(),rows:this.rows,first:this.first,totalRecords:this.totalRecords}}empty(){return this.getPageCount()===0}currentPage(){return this.getPageCount()>0?this.getPage()+1:0}get currentPageReport(){return this.currentPageReportTemplate.replace("{currentPage}",String(this.currentPage())).replace("{totalPages}",String(this.getPageCount())).replace("{first}",String(this.totalRecords>0?this._first+1:0)).replace("{last}",String(Math.min(this._first+this.rows,this.totalRecords))).replace("{rows}",String(this.rows)).replace("{totalRecords}",String(this.totalRecords))}static \u0275fac=function(n){return new(n||t)};static \u0275cmp=S({type:t,selectors:[["p-paginator"]],contentQueries:function(n,i,o){if(n&1&&(v(o,Mn,4),v(o,Dn,4),v(o,Bn,4),v(o,Pn,4),v(o,Ln,4),v(o,ne,4)),n&2){let r;m(r=g())&&(i.dropdownIconTemplate=r.first),m(r=g())&&(i.firstPageLinkIconTemplate=r.first),m(r=g())&&(i.previousPageLinkIconTemplate=r.first),m(r=g())&&(i.lastPageLinkIconTemplate=r.first),m(r=g())&&(i.nextPageLinkIconTemplate=r.first),m(r=g())&&(i.templates=r)}},hostVars:4,hostBindings:function(n,i){n&2&&(h(i.cn(i.cx("paginator"),i.styleClass)),de("display",i.display))},inputs:{pageLinkSize:[2,"pageLinkSize","pageLinkSize",$],styleClass:"styleClass",alwaysShow:[2,"alwaysShow","alwaysShow",T],dropdownAppendTo:"dropdownAppendTo",templateLeft:"templateLeft",templateRight:"templateRight",dropdownScrollHeight:"dropdownScrollHeight",currentPageReportTemplate:"currentPageReportTemplate",showCurrentPageReport:[2,"showCurrentPageReport","showCurrentPageReport",T],showFirstLastIcon:[2,"showFirstLastIcon","showFirstLastIcon",T],totalRecords:[2,"totalRecords","totalRecords",$],rows:[2,"rows","rows",$],rowsPerPageOptions:"rowsPerPageOptions",showJumpToPageDropdown:[2,"showJumpToPageDropdown","showJumpToPageDropdown",T],showJumpToPageInput:[2,"showJumpToPageInput","showJumpToPageInput",T],jumpToPageItemTemplate:"jumpToPageItemTemplate",showPageLinks:[2,"showPageLinks","showPageLinks",T],locale:"locale",dropdownItemTemplate:"dropdownItemTemplate",first:"first",appendTo:[1,"appendTo"]},outputs:{onPageChange:"onPageChange"},features:[te([pi,{provide:di,useExisting:t},{provide:me,useExisting:t}]),re([F]),k],decls:15,vars:23,consts:[[3,"pBind","class",4,"ngIf"],["type","button","pRipple","",3,"pBind","class","click",4,"ngIf"],["type","button","pRipple","",3,"click","pBind","disabled"],["data-p-icon","angle-left",3,"pBind","class",4,"ngIf"],[3,"class",4,"ngIf"],[3,"options","ngModel","disabled","styleClass","appendTo","scrollHeight","pt","onChange",4,"ngIf"],["data-p-icon","angle-right",3,"pBind","class",4,"ngIf"],["type","button","pRipple","",3,"pBind","disabled","class","click",4,"ngIf"],[3,"pt","ngModel","class","disabled","ngModelChange",4,"ngIf"],[3,"options","ngModel","styleClass","disabled","appendTo","scrollHeight","ariaLabel","pt","ngModelChange","onChange",4,"ngIf"],[3,"pBind"],[4,"ngTemplateOutlet","ngTemplateOutletContext"],["type","button","pRipple","",3,"click","pBind"],["data-p-icon","angle-double-left",3,"pBind","class",4,"ngIf"],["data-p-icon","angle-double-left",3,"pBind"],[4,"ngTemplateOutlet"],["data-p-icon","angle-left",3,"pBind"],["type","button","pRipple","",3,"pBind","class","click",4,"ngFor","ngForOf"],[3,"onChange","options","ngModel","disabled","styleClass","appendTo","scrollHeight","pt"],["pTemplate","selectedItem"],[4,"ngIf"],["pTemplate","item"],["pTemplate","dropdownicon"],["data-p-icon","angle-right",3,"pBind"],["data-p-icon","angle-double-right",3,"pBind","class",4,"ngIf"],["data-p-icon","angle-double-right",3,"pBind"],[3,"ngModelChange","pt","ngModel","disabled"],[3,"ngModelChange","onChange","options","ngModel","styleClass","disabled","appendTo","scrollHeight","ariaLabel","pt"]],template:function(n,i){n&1&&(d(0,Fn,2,7,"div",0)(1,Nn,2,4,"span",0)(2,Kn,3,6,"button",1),_(3,"button",2),O("click",function(r){return i.changePageToPrev(r)}),d(4,Qn,1,3,"svg",3)(5,jn,2,3,"span",4),w(),d(6,qn,2,4,"span",0)(7,io,4,10,"p-select",5),_(8,"button",2),O("click",function(r){return i.changePageToNext(r)}),d(9,no,1,3,"svg",6)(10,ao,2,3,"span",4),w(),d(11,uo,3,7,"button",7)(12,ho,1,5,"p-inputnumber",8)(13,Co,3,10,"p-select",9)(14,wo,2,7,"div",0)),n&2&&(a("ngIf",i.templateLeft),c(),a("ngIf",i.showCurrentPageReport),c(),a("ngIf",i.showFirstLastIcon),c(),h(i.cx("prev")),a("pBind",i.ptm("prev"))("disabled",i.isFirstPage()||i.empty()),B("aria-label",i.getAriaLabel("prevPageLabel")),c(),a("ngIf",!i.previousPageLinkIconTemplate&&!i._previousPageLinkIconTemplate),c(),a("ngIf",i.previousPageLinkIconTemplate||i._previousPageLinkIconTemplate),c(),a("ngIf",i.showPageLinks),c(),a("ngIf",i.showJumpToPageDropdown),c(),h(i.cx("next")),a("pBind",i.ptm("next"))("disabled",i.isLastPage()||i.empty()),B("aria-label",i.getAriaLabel("nextPageLabel")),c(),a("ngIf",!i.nextPageLinkIconTemplate&&!i._nextPageLinkIconTemplate),c(),a("ngIf",i.nextPageLinkIconTemplate||i._nextPageLinkIconTemplate),c(),a("ngIf",i.showFirstLastIcon),c(),a("ngIf",i.showJumpToPageInput),c(),a("ngIf",i.rowsPerPageOptions),c(),a("ngIf",i.templateRight))},dependencies:[ue,He,le,se,Kt,ut,Ue,kt,Et,We,Jt,Xt,ei,ti,Y,ne,F],encapsulation:2,changeDetection:0})}return t})(),ui=(()=>{class t{static \u0275fac=function(n){return new(n||t)};static \u0275mod=xe({type:t});static \u0275inj=ye({imports:[ht,Y,Y]})}return t})();var Io=["colgroup"],So=["caption"],ko=["header"],Eo=["body"],Mo=["footer"],Do=["summary"],Bo=["emptymessage"],Po=["paginatorleft"],Lo=["paginatorright"],Vo=["paginatordropdownitem"],zo=["frozenheader"],Fo=["frozenbody"],No=["frozenfooter"],Ro=["frozencolgroup"],Oo=["loadingicon"],Ho=["reorderindicatorupicon"],Ao=["reorderindicatordownicon"],Ko=["sorticon"],Qo=["checkboxicon"],Uo=["headercheckboxicon"],Go=["togglericon"],jo=["paginatorfirstpagelinkicon"],$o=["paginatorlastpagelinkicon"],qo=["paginatorpreviouspagelinkicon"],Wo=["paginatornextpagelinkicon"],Zo=["loader"],Jo=["resizeHelper"],Xo=["reorderIndicatorUp"],Yo=["reorderIndicatorDown"],er=["table"],tr=["scrollableView"],ir=["scrollableFrozenView"],be=t=>({$implicit:t}),nr=(t,l)=>({left:t,width:l}),or=(t,l)=>[t,l],rr=t=>({width:t});function ar(t,l){if(t&1&&P(0,"i"),t&2){let e=p(2);h(e.cn(e.cx("loadingIcon"),"pi-spin"+e.loadingIcon))}}function lr(t,l){if(t&1&&(x(),P(0,"svg",13)),t&2){let e=p(3);h(e.cx("loadingIcon")),a("spin",!0)}}function sr(t,l){}function cr(t,l){t&1&&d(0,sr,0,0,"ng-template")}function pr(t,l){if(t&1&&(_(0,"span"),d(1,cr,1,0,null,14),w()),t&2){let e=p(3);h(e.cx("loadingIcon")),c(),a("ngTemplateOutlet",e.loadingIconTemplate||e._loadingIconTemplate)}}function dr(t,l){if(t&1&&(U(0),d(1,lr,1,3,"svg",12)(2,pr,2,3,"span",10),G()),t&2){let e=p(2);c(),a("ngIf",!e.loadingIconTemplate&&!e._loadingIconTemplate),c(),a("ngIf",e.loadingIconTemplate||e._loadingIconTemplate)}}function ur(t,l){if(t&1&&(_(0,"div",9)(1,"div",9),d(2,ar,1,2,"i",10)(3,dr,3,2,"ng-container",11),w()()),t&2){let e=p();h(e.cx("loading")),a("pBind",e.ptm("loading")),c(),h(e.cx("mask")),a("pBind",e.ptm("mask")),c(),a("ngIf",e.loadingIcon),c(),a("ngIf",!e.loadingIcon)}}function hr(t,l){t&1&&V(0)}function mr(t,l){if(t&1&&(_(0,"div",9),d(1,hr,1,0,"ng-container",14),w()),t&2){let e=p();h(e.cx("header")),a("pBind",e.ptm("header")),c(),a("ngTemplateOutlet",e.captionTemplate||e._captionTemplate)}}function gr(t,l){t&1&&V(0)}function fr(t,l){if(t&1&&d(0,gr,1,0,"ng-container",14),t&2){let e=p(3);a("ngTemplateOutlet",e.paginatorFirstPageLinkIconTemplate||e._paginatorFirstPageLinkIconTemplate)}}function br(t,l){t&1&&d(0,fr,1,1,"ng-template",16)}function _r(t,l){t&1&&V(0)}function yr(t,l){if(t&1&&d(0,_r,1,0,"ng-container",14),t&2){let e=p(3);a("ngTemplateOutlet",e.paginatorPreviousPageLinkIconTemplate||e._paginatorPreviousPageLinkIconTemplate)}}function Cr(t,l){t&1&&d(0,yr,1,1,"ng-template",17)}function xr(t,l){t&1&&V(0)}function wr(t,l){if(t&1&&d(0,xr,1,0,"ng-container",14),t&2){let e=p(3);a("ngTemplateOutlet",e.paginatorLastPageLinkIconTemplate||e._paginatorLastPageLinkIconTemplate)}}function Tr(t,l){t&1&&d(0,wr,1,1,"ng-template",18)}function vr(t,l){t&1&&V(0)}function Ir(t,l){if(t&1&&d(0,vr,1,0,"ng-container",14),t&2){let e=p(3);a("ngTemplateOutlet",e.paginatorNextPageLinkIconTemplate||e._paginatorNextPageLinkIconTemplate)}}function Sr(t,l){t&1&&d(0,Ir,1,1,"ng-template",19)}function kr(t,l){if(t&1){let e=K();_(0,"p-paginator",15),O("onPageChange",function(i){y(e);let o=p();return C(o.onPageChange(i))}),d(1,br,1,0,null,11)(2,Cr,1,0,null,11)(3,Tr,1,0,null,11)(4,Sr,1,0,null,11),w()}if(t&2){let e=p();a("pt",e.ptm("pcPaginator"))("rows",e.rows)("first",e.first)("totalRecords",e.totalRecords)("pageLinkSize",e.pageLinks)("styleClass",e.cx("pcPaginator"))("alwaysShow",e.alwaysShowPaginator)("rowsPerPageOptions",e.rowsPerPageOptions)("templateLeft",e.paginatorLeftTemplate??e._paginatorLeftTemplate)("templateRight",e.paginatorRightTemplate??e._paginatorRightTemplate)("appendTo",e.paginatorDropdownAppendTo)("currentPageReportTemplate",e.currentPageReportTemplate)("showFirstLastIcon",e.showFirstLastIcon)("dropdownItemTemplate",e.paginatorDropdownItemTemplate??e._paginatorDropdownItemTemplate)("showCurrentPageReport",e.showCurrentPageReport)("showJumpToPageDropdown",e.showJumpToPageDropdown)("showPageLinks",e.showPageLinks)("locale",e.paginatorLocale),c(),a("ngIf",e.paginatorFirstPageLinkIconTemplate||e._paginatorFirstPageLinkIconTemplate),c(),a("ngIf",e.paginatorPreviousPageLinkIconTemplate||e._paginatorPreviousPageLinkIconTemplate),c(),a("ngIf",e.paginatorLastPageLinkIconTemplate||e._paginatorLastPageLinkIconTemplate),c(),a("ngIf",e.paginatorNextPageLinkIconTemplate||e._paginatorNextPageLinkIconTemplate)}}function Er(t,l){t&1&&V(0)}function Mr(t,l){t&1&&V(0)}function Dr(t,l){t&1&&V(0)}function Br(t,l){if(t&1&&(_(0,"div",9)(1,"table",20,0),d(3,Er,1,0,"ng-container",21),_(4,"thead",22),d(5,Mr,1,0,"ng-container",21),w(),P(6,"tbody",23),_(7,"tfoot",22),d(8,Dr,1,0,"ng-container",21),w()()()),t&2){let e=p();h(e.cx("wrapper")),a("pBind",e.ptm("wrapper")),c(),a("pBind",e.ptm("table"))("ngClass",e.tableStyleClass)("ngStyle",e.tableStyle),c(2),a("ngTemplateOutlet",e.colGroupTemplate||e._colGroupTemplate)("ngTemplateOutletContext",j(23,be,e.columns)),c(),h(e.cx("thead")),a("pBind",e.ptm("thead")),c(),a("ngTemplateOutlet",e.headerTemplate||e._headerTemplate)("ngTemplateOutletContext",j(25,be,e.columns)),c(),h(e.cx("tbody")),a("pBind",e.ptm("tbody"))("pTreeTableBody",e.columns)("pTreeTableBodyTemplate",e.bodyTemplate??e._bodyTemplate),c(),h(e.cx("tfoot")),a("pBind",e.ptm("tfoot")),c(),a("ngTemplateOutlet",e.footerTemplate||e._footerTemplate)("ngTemplateOutletContext",j(27,be,e.columns))}}function Pr(t,l){if(t&1&&P(0,"div",26,2),t&2){let e=p(2);a("ngClass",ge(6,or,e.cx("scrollableView"),e.cx("frozenView")))("ttScrollableView",e.frozenColumns)("frozen",!0)("ngStyle",j(9,rr,e.frozenWidth))("scrollHeight",e.scrollHeight)("pBind",e.ptm("scrollableView"))}}function Lr(t,l){if(t&1&&(_(0,"div",9),d(1,Pr,2,11,"div",24),P(2,"div",25,1),w()),t&2){let e=p();h(e.cx("scrollableWrapper")),a("pBind",e.ptm("scrollableWrapper")),c(),a("ngIf",e.frozenColumns||e.frozenBodyTemplate||e._frozenBodyTemplate),c(),h(e.cx("scrollableView")),a("pBind",e.ptm("scrollableView"))("ttScrollableView",e.columns)("frozen",!1)("scrollHeight",e.scrollHeight)("ngStyle",ge(11,nr,e.frozenWidth,"calc(100% - "+e.frozenWidth+")"))}}function Vr(t,l){t&1&&V(0)}function zr(t,l){if(t&1&&d(0,Vr,1,0,"ng-container",14),t&2){let e=p(3);a("ngTemplateOutlet",e.paginatorFirstPageLinkIconTemplate||e._paginatorFirstPageLinkIconTemplate)}}function Fr(t,l){t&1&&d(0,zr,1,1,"ng-template",16)}function Nr(t,l){t&1&&V(0)}function Rr(t,l){if(t&1&&d(0,Nr,1,0,"ng-container",14),t&2){let e=p(3);a("ngTemplateOutlet",e.paginatorPreviousPageLinkIconTemplate||e._paginatorPreviousPageLinkIconTemplate)}}function Or(t,l){t&1&&d(0,Rr,1,1,"ng-template",17)}function Hr(t,l){t&1&&V(0)}function Ar(t,l){if(t&1&&d(0,Hr,1,0,"ng-container",14),t&2){let e=p(3);a("ngTemplateOutlet",e.paginatorLastPageLinkIconTemplate||e._paginatorLastPageLinkIconTemplate)}}function Kr(t,l){t&1&&d(0,Ar,1,1,"ng-template",18)}function Qr(t,l){t&1&&V(0)}function Ur(t,l){if(t&1&&d(0,Qr,1,0,"ng-container",14),t&2){let e=p(3);a("ngTemplateOutlet",e.paginatorNextPageLinkIconTemplate||e._paginatorNextPageLinkIconTemplate)}}function Gr(t,l){t&1&&d(0,Ur,1,1,"ng-template",19)}function jr(t,l){if(t&1){let e=K();_(0,"p-paginator",15),O("onPageChange",function(i){y(e);let o=p();return C(o.onPageChange(i))}),d(1,Fr,1,0,null,11)(2,Or,1,0,null,11)(3,Kr,1,0,null,11)(4,Gr,1,0,null,11),w()}if(t&2){let e=p();a("pt",e.ptm("pcPaginator"))("rows",e.rows)("first",e.first)("totalRecords",e.totalRecords)("pageLinkSize",e.pageLinks)("styleClass",e.cx("pcPaginator"))("alwaysShow",e.alwaysShowPaginator)("rowsPerPageOptions",e.rowsPerPageOptions)("templateLeft",e.paginatorLeftTemplate??e._paginatorLeftTemplate)("templateRight",e.paginatorRightTemplate??e._paginatorRightTemplate)("appendTo",e.paginatorDropdownAppendTo)("currentPageReportTemplate",e.currentPageReportTemplate)("showFirstLastIcon",e.showFirstLastIcon)("dropdownItemTemplate",e.paginatorDropdownItemTemplate??e._paginatorDropdownItemTemplate)("showCurrentPageReport",e.showCurrentPageReport)("showJumpToPageDropdown",e.showJumpToPageDropdown)("showPageLinks",e.showPageLinks)("locale",e.paginatorLocale),c(),a("ngIf",e.paginatorFirstPageLinkIconTemplate||e._paginatorFirstPageLinkIconTemplate),c(),a("ngIf",e.paginatorPreviousPageLinkIconTemplate||e._paginatorPreviousPageLinkIconTemplate),c(),a("ngIf",e.paginatorLastPageLinkIconTemplate||e._paginatorLastPageLinkIconTemplate),c(),a("ngIf",e.paginatorNextPageLinkIconTemplate||e._paginatorNextPageLinkIconTemplate)}}function $r(t,l){t&1&&V(0)}function qr(t,l){if(t&1&&(_(0,"div",9),d(1,$r,1,0,"ng-container",14),w()),t&2){let e=p();h(e.cx("footer")),a("pBind",e.ptm("footer")),c(),a("ngTemplateOutlet",e.summaryTemplate||e._summaryTemplate)}}function Wr(t,l){if(t&1&&P(0,"div",9,3),t&2){let e=p();h(e.cx("columnResizerHelper")),de("display","none"),a("pBind",e.ptm("columnResizerHelper"))}}function Zr(t,l){t&1&&(x(),P(0,"svg",28))}function Jr(t,l){}function Xr(t,l){t&1&&d(0,Jr,0,0,"ng-template")}function Yr(t,l){if(t&1&&(_(0,"span",9,4),d(2,Zr,1,0,"svg",27)(3,Xr,1,0,null,14),w()),t&2){let e=p();h(e.cx("reorderIndicatorUp")),de("display","none"),a("pBind",e.ptm("reorderIndicatorUp")),c(2),a("ngIf",!e.reorderIndicatorUpIconTemplate&&!e._reorderIndicatorUpIconTemplate),c(),a("ngTemplateOutlet",e.reorderIndicatorUpIconTemplate||e._reorderIndicatorUpIconTemplate)}}function ea(t,l){t&1&&(x(),P(0,"svg",30))}function ta(t,l){}function ia(t,l){t&1&&d(0,ta,0,0,"ng-template")}function na(t,l){if(t&1&&(_(0,"span",9,5),d(2,ea,1,0,"svg",29)(3,ia,1,0,null,14),w()),t&2){let e=p();h(e.cx("reorderIndicatorDown")),de("display","none"),a("pBind",e.ptm("reorderIndicatorDown")),c(2),a("ngIf",!e.reorderIndicatorDownIconTemplate&&!e._reorderIndicatorDownIconTemplate),c(),a("ngTemplateOutlet",e.reorderIndicatorDownIconTemplate||e._reorderIndicatorDownIconTemplate)}}var oa=["pTreeTableBody",""],ra=(t,l,e,n)=>({$implicit:t,node:l,rowData:e,columns:n}),aa=(t,l)=>({$implicit:t,frozen:l});function la(t,l){t&1&&V(0)}function sa(t,l){if(t&1&&(U(0),d(1,la,1,0,"ng-container",2),G()),t&2){let e=p().$implicit,n=p();c(),a("ngTemplateOutlet",n.template)("ngTemplateOutletContext",St(2,ra,e,e.node,e.node.data,n.columns))}}function ca(t,l){if(t&1&&d(0,sa,2,7,"ng-container",1),t&2){let e=l.$implicit;a("ngIf",e.visible)}}function pa(t,l){t&1&&V(0)}function da(t,l){if(t&1&&(U(0),d(1,pa,1,0,"ng-container",2),G()),t&2){let e=p();c(),a("ngTemplateOutlet",e.tt.emptyMessageTemplate)("ngTemplateOutletContext",ge(2,aa,e.columns,e.frozen))}}var ua=["scrollHeader"],ha=["scrollHeaderBox"],ma=["scrollBody"],ga=["scrollTable"],fa=["loadingTable"],ba=["scrollFooter"],_a=["scrollFooterBox"],ya=["scrollableAligner"],Ca=["scroller"],xa=["ttScrollableView",""],wa=t=>({height:t}),hi=(t,l)=>({$implicit:t,options:l}),Ta=t=>({options:t}),va=(t,l)=>({"max-height":t,"overflow-y":l}),Ia=()=>({});function Sa(t,l){t&1&&V(0)}function ka(t,l){t&1&&V(0)}function Ea(t,l){t&1&&V(0)}function Ma(t,l){if(t&1&&d(0,Ea,1,0,"ng-container",13),t&2){let e=l.$implicit,n=l.options;p(2);let i=Ye(11);a("ngTemplateOutlet",i)("ngTemplateOutletContext",ge(2,hi,e,n))}}function Da(t,l){t&1&&V(0)}function Ba(t,l){if(t&1&&d(0,Da,1,0,"ng-container",13),t&2){let e=l.options,n=p(3);a("ngTemplateOutlet",n.tt.loaderTemplate||n.tt._loaderTemplate)("ngTemplateOutletContext",j(2,Ta,e))}}function Pa(t,l){t&1&&(U(0),d(1,Ba,1,4,"ng-template",null,5,Re),G())}function La(t,l){if(t&1){let e=K();_(0,"p-scroller",18,3),O("onLazyLoad",function(i){y(e);let o=p();return C(o.tt.onLazyItemLoad(i))}),d(2,Ma,1,5,"ng-template",null,4,Re)(4,Pa,3,0,"ng-container",16),w()}if(t&2){let e=p();Me(j(10,wa,e.tt.scrollHeight!=="flex"?e.tt.scrollHeight:void 0)),a("items",e.tt.serializedValue)("styleClass",e.cx("scrollableBody"))("scrollHeight",e.scrollHeight!=="flex"?void 0:"100%")("itemSize",e.tt.virtualScrollItemSize||e.tt._virtualRowHeight)("lazy",e.tt.lazy)("options",e.tt.virtualScrollOptions)("pt",e.ptm("virtualScroller")),c(4),a("ngIf",e.tt.loaderTemplate||e.tt._loaderTemplate)}}function Va(t,l){t&1&&V(0)}function za(t,l){if(t&1&&(U(0),_(1,"div",12,6),d(3,Va,1,0,"ng-container",13),w(),G()),t&2){let e=p(),n=Ye(11);c(),h(e.cx("scrollableBody")),a("pBind",e.ptm("scrollableBody"))("ngStyle",ge(6,va,e.tt.scrollHeight!=="flex"?e.scrollHeight:void 0,!e.frozen&&e.tt.scrollHeight?"scroll":void 0)),c(2),a("ngTemplateOutlet",n)("ngTemplateOutletContext",ge(10,hi,e.serializedValue,It(9,Ia)))}}function Fa(t,l){t&1&&V(0)}function Na(t,l){t&1&&P(0,"div",null,8),t&2&&de("background-color","transparent")}function Ra(t,l){if(t&1&&(_(0,"table",19,7),d(2,Fa,1,0,"ng-container",13),P(3,"tbody",20),w(),d(4,Na,2,2,"div",21)),t&2){let e=l.$implicit,n=l.options,i=p();Me(n.contentStyle),h(i.tt.tableStyleClass),a("pBind",i.ptm("table"))("ngClass",n.contentStyleClass)("ngStyle",i.tt.tableStyle),c(2),a("ngTemplateOutlet",i.frozen?i.tt.frozenColGroupTemplate||i.tt._frozenColGroupTemplate||i.tt.colGroupTemplate||i.tt._colGroupTemplate:i.tt.colGroupTemplate||i.tt._colGroupTemplate)("ngTemplateOutletContext",j(18,be,i.columns)),c(),h(i.cx("tbody")),a("pBind",i.ptm("tbody"))("pBind",i.ptm("tbody"))("pTreeTableBody",i.columns)("pTreeTableBodyTemplate",i.frozen?i.tt.frozenBodyTemplate||i.tt._frozenBodyTemplate||i.tt.bodyTemplate||i.tt._bodyTemplate:i.tt.bodyTemplate||i.tt._bodyTemplate)("serializedNodes",e)("frozen",i.frozen),c(),a("ngIf",i.frozen)}}function Oa(t,l){t&1&&V(0)}function Ha(t,l){t&1&&V(0)}function Aa(t,l){if(t&1&&(_(0,"div",11,9)(2,"div",11,10)(4,"table",22),d(5,Oa,1,0,"ng-container",13),_(6,"tfoot",14),d(7,Ha,1,0,"ng-container",13),w()()()()),t&2){let e=p();h(e.cx("scrollableFooter")),a("pBind",e.ptm("scrollableFooter")),c(2),h(e.cx("scrollableFooterBox")),a("pBind",e.ptm("scrollableFooterBox")),c(2),h(e.cx("scrollableFooterTable")),a("ngClass",e.tt.tableStyleClass)("ngStyle",e.tt.tableStyle)("pBind",e.ptm("scrollableFooterTable")),c(),a("ngTemplateOutlet",e.frozen?e.tt.frozenColGroupTemplate||e.tt._frozenColGroupTemplate||e.tt.colGroupTemplate||e.tt._colGroupTemplate:e.tt.colGroupTemplate||e.tt._colGroupTemplate)("ngTemplateOutletContext",j(18,be,e.columns)),c(),h(e.cx("tfoot")),a("pBind",e.ptm("tfoot")),c(),a("ngTemplateOutlet",e.frozen?e.tt.frozenFooterTemplate||e.tt._frozenFooterTemplate||e.tt.footerTemplate||e.tt._footerTemplate:e.tt.footerTemplate||e.tt._footerTemplate)("ngTemplateOutletContext",j(20,be,e.columns))}}function Ka(t,l){if(t&1&&(x(),P(0,"svg",5)),t&2){let e=p(2);a("pBind",e.ptm("nodetoggleicon")),B("aria-hidden",!0)}}function Qa(t,l){if(t&1&&(x(),P(0,"svg",6)),t&2){let e=p(2);a("pBind",e.ptm("nodetoggleicon")),B("aria-hidden",!0)}}function Ua(t,l){if(t&1&&(U(0),d(1,Ka,1,2,"svg",3)(2,Qa,1,2,"svg",4),G()),t&2){let e=p();c(),a("ngIf",e.rowNode.node.expanded),c(),a("ngIf",!e.rowNode.node.expanded)}}function Ga(t,l){}function ja(t,l){t&1&&d(0,Ga,0,0,"ng-template")}var $a=`
/* For PrimeNG */
.p-treetable {
    position: relative;
}

.p-treetable table {
    border-collapse: collapse;
    width: 100%;
    table-layout: fixed;
}

.p-treetable .p-sortable-column {
    cursor: pointer;
    user-select: none;
}

.p-treetable .p-sortable-column .p-column-title,
.p-treetable .p-sortable-column .p-sortable-column-icon,
.p-treetable .p-sortable-column .p-sortable-column-badge {
    vertical-align: middle;
}

.p-treetable-sort-icon {
    color: dt('treetable.sort.icon.color');
    font-size: dt('treetable.sort.icon.size');
    width: dt('treetable.sort.icon.size');
    height: dt('treetable.sort.icon.size');
    transition: color dt('treetable.transition.duration');
}

.p-treetable .p-sortable-column .p-sortable-column-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.p-treetable-auto-layout>.p-treetable-wrapper {
    overflow-x: auto;
}

.p-treetable-auto-layout>.p-treetable-wrapper>table {
    table-layout: auto;
}

.p-treetable-hoverable-rows .p-treetable-tbody>tr {
    cursor: pointer;
}

.p-treetable-toggler {
    cursor: pointer;
    user-select: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    vertical-align: middle;
    overflow: hidden;
    position: relative;
}


/* Scrollable */
.p-treetable-scrollable-wrapper {
    position: relative;
}

.p-treetable-scrollable-header,
.p-treetable-scrollable-footer {
    overflow: hidden;
    flex-shrink: 0;
}

.p-treetable-scrollable-body {
    overflow: auto;
    position: relative;
}

.p-treetable-virtual-table {
    position: absolute;
}

/* Frozen Columns */
.p-treetable-frozen-view .p-treetable-scrollable-body {
    overflow: hidden;
}

.p-treetable-frozen-view>.p-treetable-scrollable-body>table>.p-treetable-tbody>tr>td:last-child {
    border-right: 0 none;
}

.p-treetable-unfrozen-view {
    position: absolute;
    top: 0;
}

/* Flex Scrollable */
.p-treetable-flex-scrollable {
    display: flex;
    flex-direction: column;
    flex: 1;
    height: 100%;
}

.p-treetable-flex-scrollable .p-treetable-scrollable-wrapper,
.p-treetable-flex-scrollable .p-treetable-scrollable-view {
    display: flex;
    flex-direction: column;
    flex: 1;
    height: 100%;
}

.p-treetable-flex-scrollable .p-treetable-virtual-scrollable-body {
    flex: 1;
}

/* Resizable */
.p-treetable-resizable>.p-treetable-wrapper {
    overflow-x: auto;
}

.p-treetable-resizable .p-treetable-thead>tr>th,
.p-treetable-resizable .p-treetable-tfoot>tr>td,
.p-treetable-resizable .p-treetable-tbody>tr>td {
    overflow: hidden;
}

.p-treetable-resizable .p-resizable-column {
    background-clip: padding-box;
    position: relative;
}

.p-treetable-resizable-fit .p-resizable-column:last-child .p-column-resizer {
    display: none;
}

.p-treetable .p-column-resizer {
    display: block;
    position: absolute;
    top: 0;
    right: 0;
    margin: 0;
    width: dt('treetable.column.resizer.width');
    height: 100%;
    padding: 0px;
    cursor: col-resize;
    border: 1px solid transparent;
}

.p-treetable .p-column-resizer-helper {
    width: dt('treetable.resize.indicator.width');
    position: absolute;
    z-index: 10;
    display: none;
    background: dt('treetable.resize.indicator.color');
}

.p-treetable .p-row-editor-init,
.p-treetable .p-row-editor-save,
.p-treetable .p-row-editor-cancel {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    position: relative;
}


/* Reorder */
.p-treetable-reorder-indicator-up,
.p-treetable-reorder-indicator-down {
    position: absolute;
    display: none;
}

[ttReorderableColumn] {
    cursor: move;
}

/* Loader */
.p-treetable-mask {
    position: absolute !important;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 2;
}

.p-treetable-loading-icon {
    font-size: dt('treetable.loading.icon.size');
    width: dt('treetable.loading.icon.size');
    height: dt('treetable.loading.icon.size');
}

/* Virtual Scroll */
.p-treetable .p-scroller-loading {
    transform: none !important;
    min-height: 0;
    position: sticky;
    top: 0;
    left: 0;
}

.p-treetable .p-paginator-top {
    border-color: dt('treetable.paginator.top.border.color');
    border-style: solid;
    border-width: dt('treetable.paginator.top.border.width');
}

.p-treetable .p-paginator-bottom {
    border-color: dt('treetable.paginator.bottom.border.color');
    border-style: solid;
    border-width: dt('treetable.paginator.bottom.border.width');
}

.p-treetable .p-treetable-header {
    background: dt('treetable.header.background');
    color: dt('treetable.header.color');
    border-color: dt('treetable.header.border.color');
    border-style: solid;
    border-width: dt('treetable.header.border.width');
    padding: dt('treetable.header.padding');
    font-weight: dt('treetable.column.title.font.weight');
}

.p-treetable .p-treetable-footer {
    background: dt('treetable.footer.background');
    color: dt('treetable.footer.color');
    border-color: dt('treetable.footer.border.color');
    border-style: solid;
    border-width: dt('treetable.footer.border.width');
    padding: dt('treetable.footer.padding');
    font-weight: dt('treetable.column.footer.font.weight');
}

.p-treetable .p-treetable-thead>tr>th {
    padding: dt('treetable.header.cell.padding');
    background: dt('treetable.header.cell.background');
    border-color: dt('treetable.header.cell.border.color');
    border-style: solid;
    border-width: 0 0 1px 0;
    color: dt('treetable.header.cell.color');
    font-weight: dt('treetable.column.title.font.weight');
    text-align: start;
    transition: background dt('treetable.transition.duration'), color dt('treetable.transition.duration'), border-color dt('treetable.transition.duration'),
            outline-color dt('treetable.transition.duration'), box-shadow dt('treetable.transition.duration');
}

.p-treetable .p-treetable-tfoot>tr>td {
    text-align: start;
    padding: dt('treetable.footer.cell.padding');
    border-color: dt('treetable.footer.cell.border.color');
    border-style: solid;
    border-width: 0 0 1px 0;
    color: dt('treetable.footer.cell.color');
    background: dt('treetable.footer.cell.background');
    font-weight: dt('treetable.column.footer.font.weight');
}

.p-treetable .p-sortable-column {
    cursor: pointer;
    user-select: none;
    outline-color: transparent;
    vertical-align: middle;
}

.p-treetable .p-sortable-column .p-sortable-column-icon {
    color: dt('treetable.sort.icon.color');
    transition: color dt('treetable.transition.duration');
}


.p-treetable .p-sortable-column:not(.p-treetable-column-sorted):hover {
    background: dt('treetable.header.cell.hover.background');
    color: dt('treetable.header.cell.hover.color');
}

.p-treetable .p-sortable-column:not(.p-treetable-column-sorted):hover .p-sortable-column-icon {
    color: dt('treetable.sort.icon.hover.color');
}

.p-treetable .p-sortable-column.p-treetable-column-sorted {
    background: dt('treetable.header.cell.selected.background');
    color: dt('treetable.header.cell.selected.color');
}

.p-treetable .p-sortable-column.p-treetable-column-sorted .p-sortable-column-icon {
    color: dt('treetable.header.cell.selected.color');
}

.p-treetable .p-sortable-column:focus-visible {
    box-shadow: dt('treetable.header.cell.focus.ring.shadow');
    outline: dt('treetable.header.cell.focus.ring.width') dt('treetable.header.cell.focus.ring.style') dt('treetable.header.cell.focus.ring.color');
    outline-offset: dt('treetable.header.cell.focus.ring.offset');
}

.p-treetable-hoverable .p-treetable-selectable-row {
    cursor: pointer;
}

.p-treetable .p-treetable-tbody > tr {
    outline-color: transparent;
    background: dt('treetable.row.background');
    color: dt('treetable.row.color');
    transition: background dt('treetable.transition.duration'), color dt('treetable.transition.duration'), border-color dt('treetable.transition.duration'),
            outline-color dt('treetable.transition.duration'), box-shadow dt('treetable.transition.duration');
}

.p-treetable .p-treetable-tbody>tr>td {
    text-align: start;
    border-color: dt('treetable.body.cell.border.color');
    border-style: solid;
    border-width: 0 0 1px 0;
    padding: dt('treetable.body.cell.padding');
}

.p-treetable .p-treetable-tbody>tr>td .p-treetable-toggler {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    position: relative;
    width: dt('treetable.node.toggle.button.size');
    height: dt('treetable.node.toggle.button.size');
    color: dt('treetable.node.toggle.button.color');
    border: 0 none;
    background: transparent;
    cursor: pointer;
    border-radius: dt('treetable.node.toggle.button.border.radius');
    transition: background dt('treetable.transition.duration'), color dt('treetable.transition.duration'), border-color dt('treetable.transition.duration'),
            outline-color dt('treetable.transition.duration'), box-shadow dt('treetable.transition.duration');
    outline-color: transparent;
    user-select: none;
}

.p-treetable .p-treetable-tbody>tr>td .p-treetable-toggler:enabled:hover {
    color: dt('treetable.node.toggle.button.hover.color');
    background: dt('treetable.node.toggle.button.hover.background');
}

.p-treetable .p-treetable-tbody>tr>tr.treetable-row-selected .p-treetable-toggler:hover {
    background: dt('treetable.node.toggle.button.selected.hover.background');
    color: dt('treetable.node.toggle.button.selected.hover.color');
}

.p-treetable .p-treetable-tbody>tr>td .p-treetable-toggler:focus-visible {
    box-shadow: dt('treetable.node.toggle.button.focus.ring.shadow');
    outline: dt('treetable.node.toggle.button.focus.ring.width') dt('treetable.node.toggle.button.focus.ring.style') dt('treetable.node.toggle.button.focus.ring.color');
    outline-offset: dt('treetable.node.toggle.button.focus.ring.offset');
}


.p-treetable .p-treetable-tbody>tr.p-treetable-row-selected {
    background: dt('treetable.row.selected.background');
    color: dt('treetable.row.selected.color');
}

.p-treetable-tbody > tr:focus-visible,
.p-treetable-tbody > tr.p-treetable-contextmenu-row-selected {
    box-shadow: dt('treetable.row.focus.ring.shadow');
    outline: dt('treetable.row.focus.ring.width') dt('treetable.row.focus.ring.style') dt('treetable.row.focus.ring.color');
    outline-offset: dt('treetable.row.focus.ring.offset');
}

.p-treetable .p-treetable-tbody>tr.p-treetable-row-selected .p-treetable-toggler {
    color: inherit;
}

.p-treetable .p-treetable-tbody>tr.p-treetable-row-selected .p-treetable-toggler:hover {
    background: dt('treetable.node.toggle.button.selected.hover.background');
    color: dt('treetable.node.toggle.button.selected.hover.color');
}

.p-treetable.p-treetable-hoverable-rows .p-treetable-tbody>tr:not(.p-treetable-row-selected):hover {
    background: dt('treetable.row.hover.background');
    color: dt('treetable.row.hover.color');
}

.p-treetable-gridlines .p-treetable-header {
    border-width: 1px 1px 0 1px;
}

.p-treetable-gridlines .p-treetable-footer {
    border-width: 0 1px 1px 1px;
}

.p-treetable-gridlines .p-treetable-paginator-top {
    border-width: 1px 1px 0 1px;
}

.p-treetable-gridlines .p-treetable-paginator-bottom {
    border-width: 0 1px 1px 1px;
}

.p-treetable-gridlines .p-treetable-thead > tr > th {
    border-width: 1px 0 1px 1px;
}

.p-treetable-gridlines .p-treetable-thead > tr > th:last-child {
    border-width: 1px;
}

.p-treetable-gridlines .p-treetable-tbody > tr > td {
    border-width: 1px 0 0 1px;
}

.p-treetable-gridlines .p-treetable-tbody > tr > td:last-child {
    border-width: 1px 1px 0 1px;
}

.p-treetable-gridlines .p-treetable-tbody > tr:last-child > td {
    border-width: 1px 0 1px 1px;
}

.p-treetable-gridlines .p-treetable-tbody > tr:last-child > td:last-child {
    border-width: 1px;
}

.p-treetable-gridlines .p-treetable-tfoot > tr > td {
    border-width: 1px 0 1px 1px;
}

.p-treetable-gridlines .p-treetable-tfoot > tr > td:last-child {
    border-width: 1px 1px 1px 1px;
}

.p-treetable.p-treetable-gridlines .p-treetable-thead + .p-treetable-tfoot > tr > td {
    border-width: 0 0 1px 1px;
}

.p-treetable.p-treetable-gridlines .p-treetable-thead + .p-treetable-tfoot > tr > td:last-child {
    border-width: 0 1px 1px 1px;
}

.p-treetable.p-treetable-gridlines:has(.p-treetable-thead):has(.p-treetable-tbody) .p-treetable-tbody > tr > td {
    border-width: 0 0 1px 1px;
}

.p-treetable.p-treetable-gridlines:has(.p-treetable-thead):has(.p-treetable-tbody) .p-treetable-tbody > tr > td:last-child {
    border-width: 0 1px 1px 1px;
}

.p-treetable.p-treetable-gridlines:has(.p-treetable-tbody):has(.p-treetable-tfoot) .p-treetable-tbody > tr:last-child > td {
    border-width: 0 0 0 1px;
}

.p-treetable.p-treetable-gridlines:has(.p-treetable-tbody):has(.p-treetable-tfoot) .p-treetable-tbody > tr:last-child > td:last-child {
    border-width: 0 1px 0 1px;
}

.p-treetable.p-treetable-sm .p-treetable-header {
    padding: 0.65625rem 0.875rem;
}

.p-treetable.p-treetable-sm .p-treetable-thead>tr>th {
    padding: 0.375rem 0.5rem;
}

.p-treetable.p-treetable-sm .p-treetable-tbody>tr>td {
    padding: 0.375rem 0.5rem;
}

.p-treetable.p-treetable-sm .p-treetable-tfoot>tr>td {
    padding: 0.375rem 0.5rem;
}

.p-treetable.p-treetable-sm .p-treetable-footer {
    padding: 0.375rem 0.5rem;
}

.p-treetable.p-treetable-lg .p-treetable-header {
    padding: 0.9375rem 1.25rem;
}

.p-treetable.p-treetable-lg .p-treetable-thead>tr>th {
    padding: 0.9375rem 1.25rem;
}

.p-treetable.p-treetable-lg .p-treetable-tbody>tr>td {
    padding: 0.9375rem 1.25rem;
}

.p-treetable.p-treetable-lg .p-treetable-tfoot>tr>td {
    padding: 0.9375rem 1.25rem;
}

.p-treetable.p-treetable-lg .p-treetable-footer {
    padding: 0.9375rem 1.25rem;
}

p-treetabletoggler + p-treetablecheckbox .p-checkbox,
p-treetable-toggler + p-treetable-checkbox .p-checkbox,
p-tree-table-toggler + p-tree-table-checkbox .p-checkbox {
    vertical-align: middle;
}

p-treetabletoggler + p-treetablecheckbox + span,
p-treetable-toggler + p-treetable-checkbox + span,
p-tree-table-toggler + p-tree-table-checkbox + span {
    vertical-align: middle;
}

p-treetable-sort-icon {
    display: inline-flex;
    align-items: center;
    gap: dt('treetable.header.cell.gap');
}
`,qa={root:({instance:t})=>["p-treetable p-component",{"p-treetable-gridlines":t.showGridlines,"p-treetable-hoverable-rows":t.rowHover||t.selectionMode==="single"||t.selectionMode==="multiple","p-treetable-auto-layout":t.autoLayout,"p-treetable-resizable":t.resizableColumns,"p-treetable-resizable-fit":t.resizableColumns&&t.columnResizeMode==="fit","p-treetable-flex-scrollable":t.scrollable&&t.scrollHeight==="flex"}],loading:"p-treetable-loading",mask:"p-treetable-mask p-overlay-mask",loadingIcon:"p-treetable-loading-icon",header:"p-treetable-header",pcPaginator:({instance:t})=>["p-treetable-paginator-"+t.paginatorPosition,t.paginatorStyleClass],tableContainer:"p-treetable-table-container",table:({instance:t})=>({"p-treetable-table":!0,"p-treetable-scrollable-table":t.scrollable,"p-treetable-resizable-table":t.resizableColumns,"p-treetable-resizable-table-fit":t.resizableColumns&&t.columnResizeMode==="fit"}),thead:"p-treetable-thead",sortableColumn:({instance:t})=>({"p-sortable-column":t.isEnabled(),"p-treetable-column-sorted":t.sorted}),sortableColumnIcon:"p-treetable-sort-icon",sortableColumnBadge:"p-sortable-column-badge",columnResizer:"p-treetable-column-resizer",columnHeaderContent:"p-treetable-column-header-content",columnTitle:"p-treetable-column-title",sortIcon:"p-treetable-sort-icon",pcSortBadge:"p-treetable-sort-badge",tbody:"p-treetable-tbody",row:({instance:t})=>({"p-treetable-row-selected":t.selected}),contextMenuRow:({instance:t})=>({"p-treetable-contextmenu-row-selected":t.selected}),toggler:"p-treetable-toggler",nodeToggleButton:"p-treetable-node-toggle-button",nodeToggleIcon:"p-treetable-node-toggle-icon",pcNodeCheckbox:"p-treetable-node-checkbox",tfoot:"p-treetable-tfoot",footerCell:({instance:t})=>({"p-treetable-frozen-column":t.columnProp("frozen")}),footer:"p-treetable-footer",columnResizeIndicator:"p-treetable-column-resize-indicator",wrapper:"p-treetable-wrapper",scrollableWrapper:"p-treetable-scrollable-wrapper",scrollableView:"p-treetable-scrollable-view",frozenView:"p-treetable-frozen-view",columnResizerHelper:"p-column-resizer-helper",reorderIndicatorUp:"p-treetable-reorder-indicator-up",reorderIndicatorDown:"p-treetable-reorder-indicator-down",scrollableHeader:"p-treetable-scrollable-header",scrollableHeaderBox:"p-treetable-scrollable-header-box",scrollableHeaderTable:"p-treetable-scrollable-header-table",scrollableBody:"p-treetable-scrollable-body",scrollableFooter:"p-treetable-scrollable-footer",scrollableFooterBox:"p-treetable-scrollable-footer-box",scrollableFooterTable:"p-treetable-scrollable-footer-table"},Ee=(()=>{class t extends he{name="treetable";style=$a;classes=qa;static \u0275fac=(()=>{let e;return function(i){return(e||(e=I(t)))(i||t)}})();static \u0275prov=oe({token:t,factory:t.\u0275fac})}return t})();var Wa=new pe("TREETABLE_INSTANCE"),mt=(()=>{class t{sortSource=new Se;selectionSource=new Se;contextMenuSource=new Se;uiUpdateSource=new Se;totalRecordsSource=new Se;sortSource$=this.sortSource.asObservable();selectionSource$=this.selectionSource.asObservable();contextMenuSource$=this.contextMenuSource.asObservable();uiUpdateSource$=this.uiUpdateSource.asObservable();totalRecordsSource$=this.totalRecordsSource.asObservable();onSort(e){this.sortSource.next(e)}onSelectionChange(){this.selectionSource.next(null)}onContextMenu(e){this.contextMenuSource.next(e)}onUIUpdate(e){this.uiUpdateSource.next(e)}onTotalRecordsChange(e){this.totalRecordsSource.next(e)}static \u0275fac=function(n){return new(n||t)};static \u0275prov=oe({token:t,factory:t.\u0275fac})}return t})(),gt=(()=>{class t extends fe{_componentStyle=R(Ee);bindDirectiveInstance=R(F,{self:!0});onAfterViewChecked(){this.bindDirectiveInstance.setAttrs(this.ptms(["host","root"]))}columns;styleClass;tableStyle;tableStyleClass;autoLayout;lazy=!1;lazyLoadOnInit=!0;paginator;rows;first=0;pageLinks=5;rowsPerPageOptions;alwaysShowPaginator=!0;paginatorPosition="bottom";paginatorStyleClass;paginatorDropdownAppendTo;currentPageReportTemplate="{currentPage} of {totalPages}";showCurrentPageReport;showJumpToPageDropdown;showFirstLastIcon=!0;showPageLinks=!0;defaultSortOrder=1;sortMode="single";resetPageOnSort=!0;customSort;selectionMode;contextMenuSelection;contextMenuSelectionMode="separate";dataKey;metaKeySelection=!1;compareSelectionBy="deepEquals";rowHover;loading;loadingIcon;showLoader=!0;scrollable;scrollHeight;virtualScroll;virtualScrollItemSize;virtualScrollOptions;virtualScrollDelay=150;frozenWidth;frozenColumns;resizableColumns;columnResizeMode="fit";reorderableColumns;contextMenu;rowTrackBy=(e,n)=>n;filters={};globalFilterFields;filterDelay=300;filterMode="lenient";filterLocale;paginatorLocale;get totalRecords(){return this._totalRecords}set totalRecords(e){this._totalRecords=e,this.tableService.onTotalRecordsChange(this._totalRecords)}get sortField(){return this._sortField}set sortField(e){this._sortField=e}get sortOrder(){return this._sortOrder}set sortOrder(e){this._sortOrder=e}get multiSortMeta(){return this._multiSortMeta}set multiSortMeta(e){this._multiSortMeta=e}get selection(){return this._selection}set selection(e){this._selection=e}get value(){return this._value}set value(e){this._value=e}get virtualRowHeight(){return this._virtualRowHeight}set virtualRowHeight(e){this._virtualRowHeight=e,console.log("The virtualRowHeight property is deprecated, use virtualScrollItemSize property instead.")}get selectionKeys(){return this._selectionKeys}set selectionKeys(e){this._selectionKeys=e,this.selectionKeysChange.emit(this._selectionKeys)}showGridlines=!1;selectionChange=new D;contextMenuSelectionChange=new D;onFilter=new D;onNodeExpand=new D;onNodeCollapse=new D;onPage=new D;onSort=new D;onLazyLoad=new D;sortFunction=new D;onColResize=new D;onColReorder=new D;onNodeSelect=new D;onNodeUnselect=new D;onContextMenuSelect=new D;onHeaderCheckboxToggle=new D;onEditInit=new D;onEditComplete=new D;onEditCancel=new D;selectionKeysChange=new D;resizeHelperViewChild;reorderIndicatorUpViewChild;reorderIndicatorDownViewChild;tableViewChild;scrollableViewChild;scrollableFrozenViewChild;_value=[];_virtualRowHeight=28;_selectionKeys;serializedValue;_totalRecords=0;_multiSortMeta;_sortField;_sortOrder=1;filteredNodes;filterTimeout;_colGroupTemplate;colGroupTemplate;_captionTemplate;captionTemplate;_headerTemplate;headerTemplate;_bodyTemplate;bodyTemplate;_footerTemplate;footerTemplate;_summaryTemplate;summaryTemplate;_emptyMessageTemplate;emptyMessageTemplate;_paginatorLeftTemplate;paginatorLeftTemplate;_paginatorRightTemplate;paginatorRightTemplate;_paginatorDropdownItemTemplate;paginatorDropdownItemTemplate;_frozenHeaderTemplate;frozenHeaderTemplate;_frozenBodyTemplate;frozenBodyTemplate;_frozenFooterTemplate;frozenFooterTemplate;_frozenColGroupTemplate;frozenColGroupTemplate;_loadingIconTemplate;loadingIconTemplate;_reorderIndicatorUpIconTemplate;reorderIndicatorUpIconTemplate;_reorderIndicatorDownIconTemplate;reorderIndicatorDownIconTemplate;_sortIconTemplate;sortIconTemplate;_checkboxIconTemplate;checkboxIconTemplate;_headerCheckboxIconTemplate;headerCheckboxIconTemplate;_togglerIconTemplate;togglerIconTemplate;_paginatorFirstPageLinkIconTemplate;paginatorFirstPageLinkIconTemplate;_paginatorLastPageLinkIconTemplate;paginatorLastPageLinkIconTemplate;_paginatorPreviousPageLinkIconTemplate;paginatorPreviousPageLinkIconTemplate;_paginatorNextPageLinkIconTemplate;paginatorNextPageLinkIconTemplate;_loaderTemplate;loaderTemplate;lastResizerHelperX;reorderIconWidth;reorderIconHeight;draggedColumn;dropPosition;preventSelectionSetterPropagation;_selection;selectedKeys={};rowTouched;editingCell;editingCellData;editingCellField;editingCellClick;documentEditListener;initialized;toggleRowIndex;onInit(){this.lazy&&this.lazyLoadOnInit&&!this.virtualScroll&&this.onLazyLoad.emit(this.createLazyLoadMetadata()),this.initialized=!0}templates;onAfterContentInit(){this.templates.forEach(e=>{switch(e.getType()){case"caption":this.captionTemplate=e.template;break;case"header":this.headerTemplate=e.template;break;case"body":this.bodyTemplate=e.template;break;case"footer":this.footerTemplate=e.template;break;case"summary":this.summaryTemplate=e.template;break;case"colgroup":this.colGroupTemplate=e.template;break;case"emptymessage":this.emptyMessageTemplate=e.template;break;case"paginatorleft":this.paginatorLeftTemplate=e.template;break;case"paginatorright":this.paginatorRightTemplate=e.template;break;case"paginatordropdownitem":this.paginatorDropdownItemTemplate=e.template;break;case"frozenheader":this.frozenHeaderTemplate=e.template;break;case"frozenbody":this.frozenBodyTemplate=e.template;break;case"frozenfooter":this.frozenFooterTemplate=e.template;break;case"frozencolgroup":this.frozenColGroupTemplate=e.template;break;case"loadingicon":this.loadingIconTemplate=e.template;break;case"reorderindicatorupicon":this.reorderIndicatorUpIconTemplate=e.template;break;case"reorderindicatordownicon":this.reorderIndicatorDownIconTemplate=e.template;break;case"sorticon":this.sortIconTemplate=e.template;break;case"checkboxicon":this.checkboxIconTemplate=e.template;break;case"headercheckboxicon":this.headerCheckboxIconTemplate=e.template;break;case"togglericon":this.togglerIconTemplate=e.template;break;case"paginatorfirstpagelinkicon":this.paginatorFirstPageLinkIconTemplate=e.template;break;case"paginatorlastpagelinkicon":this.paginatorLastPageLinkIconTemplate=e.template;break;case"paginatorpreviouspagelinkicon":this.paginatorPreviousPageLinkIconTemplate=e.template;break;case"paginatornextpagelinkicon":this.paginatorNextPageLinkIconTemplate=e.template;break;case"loader":this.loaderTemplate=e.template;break}})}filterService=R(Ft);tableService=R(mt);zone=R(Ne);onChanges(e){e.value&&(this._value=e.value.currentValue,this.lazy||(this.totalRecords=this._value?this._value.length:0,this.sortMode=="single"&&this.sortField?this.sortSingle():this.sortMode=="multiple"&&this.multiSortMeta?this.sortMultiple():this.hasFilter()&&this._filter()),this.updateSerializedValue(),this.tableService.onUIUpdate(this.value)),e.sortField&&(this._sortField=e.sortField.currentValue,(!this.lazy||this.initialized)&&this.sortMode==="single"&&this.sortSingle()),e.sortOrder&&(this._sortOrder=e.sortOrder.currentValue,(!this.lazy||this.initialized)&&this.sortMode==="single"&&this.sortSingle()),e.multiSortMeta&&(this._multiSortMeta=e.multiSortMeta.currentValue,this.sortMode==="multiple"&&this.sortMultiple()),e.selection&&(this._selection=e.selection.currentValue,this.preventSelectionSetterPropagation||(this.updateselectedKeys(),this.tableService.onSelectionChange()),this.preventSelectionSetterPropagation=!1)}updateSerializedValue(){this.serializedValue=[],this.paginator?this.serializePageNodes():this.serializeNodes(null,this.filteredNodes||this.value,0,!0)}serializeNodes(e,n,i,o){if(n&&n.length)for(let r of n){r.parent=e;let s={node:r,parent:e,level:i,visible:o&&(e?e.expanded:!0)};this.serializedValue.push(s),s.visible&&r.expanded&&this.serializeNodes(r,r.children,i+1,s.visible)}}serializePageNodes(){let e=this.filteredNodes||this.value;if(this.serializedValue=[],e&&e.length){let n=this.lazy?0:this.first;for(let i=n;i<n+this.rows;i++){let o=e[i];o&&(this.serializedValue.push({node:o,parent:null,level:0,visible:!0}),this.serializeNodes(o,o.children,1,!0))}}}updateselectedKeys(){if(this.dataKey&&this._selection)if(this.selectedKeys={},Array.isArray(this._selection))for(let e of this._selection)this.selectedKeys[String(J(e.data,this.dataKey))]=1;else this.selectedKeys[String(J(this._selection.data,this.dataKey))]=1}onPageChange(e){this.first=e.first,this.rows=e.rows,this.lazy?this.onLazyLoad.emit(this.createLazyLoadMetadata()):this.serializePageNodes(),this.onPage.emit({first:this.first,rows:this.rows}),this.tableService.onUIUpdate(this.value),this.scrollable&&this.resetScrollTop()}sort(e){let n=e.originalEvent;if(this.sortMode==="single"&&(this._sortOrder=this.sortField===e.field?this.sortOrder*-1:this.defaultSortOrder,this._sortField=e.field,this.sortSingle(),this.resetPageOnSort&&this.scrollable&&this.resetScrollTop()),this.sortMode==="multiple"){let i=n.metaKey||n.ctrlKey,o=this.getSortMeta(e.field);o?i?o.order=o.order*-1:(this._multiSortMeta=[{field:e.field,order:o.order*-1}],this.resetPageOnSort&&this.scrollable&&this.resetScrollTop()):((!i||!this.multiSortMeta)&&(this._multiSortMeta=[],this.resetPageOnSort&&this.scrollable&&this.resetScrollTop()),this.multiSortMeta.push({field:e.field,order:this.defaultSortOrder})),this.sortMultiple()}}sortSingle(){if(this.sortField&&this.sortOrder){this.lazy?this.onLazyLoad.emit(this.createLazyLoadMetadata()):this.value&&(this.sortNodes(this.value),this.hasFilter()&&this._filter());let e={field:this.sortField,order:this.sortOrder};this.onSort.emit(e),this.tableService.onSort(e),this.updateSerializedValue()}}sortNodes(e){if(!(!e||e.length===0)){this.customSort?this.sortFunction.emit({data:e,mode:this.sortMode,field:this.sortField,order:this.sortOrder}):e.sort((n,i)=>{let o=J(n.data,this.sortField),r=J(i.data,this.sortField),s=0;return o==null&&r!=null?s=-1:o!=null&&r==null?s=1:o==null&&r==null?s=0:typeof o=="string"&&typeof r=="string"?s=o.localeCompare(r,void 0,{numeric:!0}):s=o<r?-1:o>r?1:0,this.sortOrder*s});for(let n of e)this.sortNodes(n.children)}}sortMultiple(){this.multiSortMeta&&(this.lazy?this.onLazyLoad.emit(this.createLazyLoadMetadata()):this.value&&(this.sortMultipleNodes(this.value),this.hasFilter()&&this._filter()),this.onSort.emit({multisortmeta:this.multiSortMeta}),this.updateSerializedValue(),this.tableService.onSort(this.multiSortMeta))}sortMultipleNodes(e){if(!(!e||e.length===0)){this.customSort?this.sortFunction.emit({data:this.value,mode:this.sortMode,multiSortMeta:this.multiSortMeta}):e.sort((n,i)=>this.multisortField(n,i,this.multiSortMeta,0));for(let n of e)this.sortMultipleNodes(n.children)}}multisortField(e,n,i,o){if(Pe(this.multiSortMeta)||Pe(i[o]))return 0;let r=J(e.data,i[o].field),s=J(n.data,i[o].field),u=0;if(r==null&&s!=null?u=-1:r!=null&&s==null?u=1:r==null&&s==null&&(u=0),typeof r=="string"||r instanceof String){if(r.localeCompare&&r!=s)return i[o].order*r.localeCompare(s,void 0,{numeric:!0})}else u=r<s?-1:1;return r==s?i.length-1>o?this.multisortField(e,n,i,o+1):0:i[o].order*u}getSortMeta(e){if(this.multiSortMeta&&this.multiSortMeta.length){for(let n=0;n<this.multiSortMeta.length;n++)if(this.multiSortMeta[n].field===e)return this.multiSortMeta[n]}return null}isSorted(e){if(this.sortMode==="single")return this.sortField&&this.sortField===e;if(this.sortMode==="multiple"){let n=!1;if(this.multiSortMeta){for(let i=0;i<this.multiSortMeta.length;i++)if(this.multiSortMeta[i].field==e){n=!0;break}}return n}}createLazyLoadMetadata(){return{first:this.first,rows:this.rows,sortField:this.sortField,sortOrder:this.sortOrder,filters:this.filters,globalFilter:this.filters&&this.filters.global?this.filters.global.value:null,multiSortMeta:this.multiSortMeta,forceUpdate:()=>this.cd.detectChanges()}}onLazyItemLoad(e){this.onLazyLoad.emit(ze(_e(_e({},this.createLazyLoadMetadata()),e),{rows:e.last-e.first}))}resetScrollTop(){this.virtualScroll?this.scrollToVirtualIndex(0):this.scrollTo({top:0})}scrollToVirtualIndex(e){this.scrollableViewChild&&this.scrollableViewChild.scrollToVirtualIndex(e),this.scrollableFrozenViewChild&&this.scrollableViewChild.scrollToVirtualIndex(e)}scrollTo(e){this.scrollableViewChild&&this.scrollableViewChild.scrollTo(e),this.scrollableFrozenViewChild&&this.scrollableViewChild.scrollTo(e)}isEmpty(){let e=this.filteredNodes||this.value;return e==null||e.length==0}getBlockableElement(){return this.el.nativeElement.children[0]}onColumnResizeBegin(e){let n=Ve(this.el?.nativeElement).left;this.lastResizerHelperX=e.pageX-n+this.el?.nativeElement.scrollLeft,e.preventDefault()}onColumnResize(e){let n=Ve(this.el?.nativeElement).left;je(this.el?.nativeElement,"p-unselectable-text"),this.resizeHelperViewChild.nativeElement.style.height=this.el?.nativeElement.offsetHeight+"px",this.resizeHelperViewChild.nativeElement.style.top="0px",this.resizeHelperViewChild.nativeElement.style.left=e.pageX-n+this.el?.nativeElement.scrollLeft+"px",this.resizeHelperViewChild.nativeElement.style.display="block"}onColumnResizeEnd(e,n){let i=this.resizeHelperViewChild.nativeElement.offsetLeft-this.lastResizerHelperX,o=n.offsetWidth,r=o+i,s=n.style.minWidth||15;if(o+i>parseInt(s)){if(this.columnResizeMode==="fit"){let u=n.nextElementSibling;for(;!u.offsetParent;)u=u.nextElementSibling;if(u){let b=u.offsetWidth-i,f=u.style.minWidth||15;if(r>15&&b>parseInt(f))if(this.scrollable){let M=this.findParentScrollableView(n),z=X(M,".p-treetable-scrollable-body table")||X(M,".p-scroller-viewport table"),E=X(M,"table.p-treetable-scrollable-header-table"),A=X(M,"table.p-treetable-scrollable-footer-table"),H=it(n);this.resizeColGroup(E,H,r,b),this.resizeColGroup(z,H,r,b),this.resizeColGroup(A,H,r,b)}else n.style.width=r+"px",u&&(u.style.width=b+"px")}}else if(this.columnResizeMode==="expand")if(this.scrollable){let u=this.findParentScrollableView(n),b=X(u,".p-treetable-scrollable-body")||X(u,".p-scroller-viewport"),f=X(u,".p-treetable-scrollable-header"),M=X(u,".p-treetable-scrollable-footer"),z=X(u,".p-treetable-scrollable-body table")||X(u,".p-scroller-viewport table"),E=X(u,"table.p-treetable-scrollable-header-table"),A=X(u,"table.p-treetable-scrollable-footer-table");z.style.width=z.offsetWidth+i+"px",E.style.width=E.offsetWidth+i+"px",A&&(A.style.width=A.offsetWidth+i+"px");let H=it(n),ee=n?z.offsetWidth+i:r,ve=n?E.offsetWidth+i:r,Ie=this.el?.nativeElement.offsetWidth>=ee,Xe=(ft,bt,_t,gi)=>{ft&&bt&&(ft.style.width=gi?_t+tt(b)+"px":"auto",bt.style.width=_t+"px")};Xe(b,z,ee,Ie),Xe(f,E,ve,Ie),Xe(M,A,ve,Ie),this.resizeColGroup(E,H,r,null),this.resizeColGroup(z,H,r,null),this.resizeColGroup(A,H,r,null)}else{this.tableViewChild.nativeElement.style.width=this.tableViewChild?.nativeElement.offsetWidth+i+"px",n.style.width=r+"px";let u=this.tableViewChild?.nativeElement.style.width;this.el.nativeElement.style.width=u+"px"}this.onColResize.emit({element:n,delta:i})}this.resizeHelperViewChild.nativeElement.style.display="none",$e(this.el?.nativeElement,"p-unselectable-text")}findParentScrollableView(e){if(e){let n=e.parentElement;for(;n&&!Ge(n,"p-treetable-scrollable-view");)n=n.parentElement;return n}else return null}resizeColGroup(e,n,i,o){if(e){let r=e.children[0].nodeName==="COLGROUP"?e.children[0]:null;if(r){let s=r.children[n],u=s.nextElementSibling;s.style.width=i+"px",u&&o&&(u.style.width=o+"px")}else throw"Scrollable tables require a colgroup to support resizable columns"}}onColumnDragStart(e,n){this.reorderIconWidth=Vt(this.reorderIndicatorUpViewChild?.nativeElement),this.reorderIconHeight=Lt(this.reorderIndicatorDownViewChild?.nativeElement),this.draggedColumn=n,e.dataTransfer.setData("text","b")}onColumnDragEnter(e,n){if(this.reorderableColumns&&this.draggedColumn&&n){e.preventDefault();let i=Ve(this.el?.nativeElement),o=Ve(n);if(this.draggedColumn!=n){let r=o.left-i.left,s=i.top-o.top,u=o.left+n.offsetWidth/2;this.reorderIndicatorUpViewChild.nativeElement.style.top=o.top-i.top-(this.reorderIconHeight-1)+"px",this.reorderIndicatorDownViewChild.nativeElement.style.top=o.top-i.top+n.offsetHeight+"px",e.pageX>u?(this.reorderIndicatorUpViewChild.nativeElement.style.left=r+n.offsetWidth-Math.ceil(this.reorderIconWidth/2)+"px",this.reorderIndicatorDownViewChild.nativeElement.style.left=r+n.offsetWidth-Math.ceil(this.reorderIconWidth/2)+"px",this.dropPosition=1):(this.reorderIndicatorUpViewChild.nativeElement.style.left=r-Math.ceil(this.reorderIconWidth/2)+"px",this.reorderIndicatorDownViewChild.nativeElement.style.left=r-Math.ceil(this.reorderIconWidth/2)+"px",this.dropPosition=-1),this.reorderIndicatorUpViewChild.nativeElement.style.display="block",this.reorderIndicatorDownViewChild.nativeElement.style.display="block"}else e.dataTransfer.dropEffect="none"}}onColumnDragLeave(e){this.reorderableColumns&&this.draggedColumn&&(e.preventDefault(),this.reorderIndicatorUpViewChild.nativeElement.style.display="none",this.reorderIndicatorDownViewChild.nativeElement.style.display="none")}onColumnDrop(e,n){if(e.preventDefault(),this.draggedColumn){let i=nt.indexWithinGroup(this.draggedColumn,"ttreorderablecolumn"),o=nt.indexWithinGroup(n,"ttreorderablecolumn"),r=i!=o;r&&(o-i==1&&this.dropPosition===-1||i-o==1&&this.dropPosition===1)&&(r=!1),r&&o<i&&this.dropPosition===1&&(o=o+1),r&&o>i&&this.dropPosition===-1&&(o=o-1),r&&(Dt(this.columns,i,o),this.onColReorder.emit({dragIndex:i,dropIndex:o,columns:this.columns})),this.reorderIndicatorUpViewChild.nativeElement.style.display="none",this.reorderIndicatorDownViewChild.nativeElement.style.display="none",this.draggedColumn.draggable=!1,this.draggedColumn=null,this.dropPosition=null}}handleRowClick(e){let n=e.originalEvent.target.nodeName;if(!(n=="INPUT"||n=="BUTTON"||n=="A"||Ge(e.originalEvent.target,"p-clickable"))){if(this.selectionMode){this.preventSelectionSetterPropagation=!0;let i=e.rowNode,o=this.isSelected(i.node),r=this.rowTouched?!1:this.metaKeySelection,s=this.dataKey?String(J(i.node.data,this.dataKey)):null;if(r){let u=e.originalEvent,b=u.metaKey||u.ctrlKey;if(o&&b){if(this.isSingleSelectionMode())this._selection=null,this.selectedKeys={},this.selectionChange.emit(null);else{let f=this.findIndexInSelection(i.node);this._selection=this.selection.filter((M,z)=>z!=f),this.selectionChange.emit(this.selection),s&&delete this.selectedKeys[s]}this.onNodeUnselect.emit({originalEvent:e.originalEvent,node:i.node,type:"row"})}else this.isSingleSelectionMode()?(this._selection=i.node,this.selectionChange.emit(i.node),s&&(this.selectedKeys={},this.selectedKeys[s]=1)):this.isMultipleSelectionMode()&&(b?this._selection=this.selection||[]:(this._selection=[],this.selectedKeys={}),this._selection=[...this.selection,i.node],this.selectionChange.emit(this.selection),s&&(this.selectedKeys[s]=1)),this.onNodeSelect.emit({originalEvent:e.originalEvent,node:i.node,type:"row",index:e.rowIndex})}else if(this.selectionMode==="single")o?(this._selection=null,this.selectedKeys={},this.selectionChange.emit(this.selection),this.onNodeUnselect.emit({originalEvent:e.originalEvent,node:i.node,type:"row"})):(this._selection=i.node,this.selectionChange.emit(this.selection),this.onNodeSelect.emit({originalEvent:e.originalEvent,node:i.node,type:"row",index:e.rowIndex}),s&&(this.selectedKeys={},this.selectedKeys[s]=1));else if(this.selectionMode==="multiple")if(o){let u=this.findIndexInSelection(i.node);this._selection=this.selection.filter((b,f)=>f!=u),this.selectionChange.emit(this.selection),this.onNodeUnselect.emit({originalEvent:e.originalEvent,node:i.node,type:"row"}),s&&delete this.selectedKeys[s]}else this._selection=this.selection?[...this.selection,i.node]:[i.node],this.selectionChange.emit(this.selection),this.onNodeSelect.emit({originalEvent:e.originalEvent,node:i.node,type:"row",index:e.rowIndex}),s&&(this.selectedKeys[s]=1);this.tableService.onSelectionChange()}this.rowTouched=!1}}handleRowTouchEnd(e){this.rowTouched=!0}handleRowRightClick(e){if(this.contextMenu){let n=e.rowNode.node,i=()=>{this.contextMenu.show(e.originalEvent),this.contextMenu.hideCallback=()=>{this.contextMenuSelection=null,this.contextMenuSelectionChange.emit(null),this.tableService.onContextMenu(null)}};if(this.contextMenuSelectionMode==="separate")this.contextMenuSelection=n,this.contextMenuSelectionChange.emit(n),this.onContextMenuSelect.emit({originalEvent:e.originalEvent,node:n}),i(),this.tableService.onContextMenu(n);else if(this.contextMenuSelectionMode==="joint"){this.preventSelectionSetterPropagation=!0;let o=this.isSelected(n),r=this.dataKey?String(J(n.data,this.dataKey)):null;o||(this.isSingleSelectionMode()?(this.selection=n,this.selectionChange.emit(n)):this.isMultipleSelectionMode()&&(this.selection=[n],this.selectionChange.emit(this.selection)),r&&(this.selectedKeys[r]=1)),i(),this.onContextMenuSelect.emit({originalEvent:e.originalEvent,node:n})}}}toggleNodeWithCheckbox(e){this.selection=this.selection||[],this.preventSelectionSetterPropagation=!0;let n=e.rowNode.node;this.isSelected(n)?(this.propagateSelectionDown(n,!1),e.rowNode.parent&&this.propagateSelectionUp(n.parent,!1),this.selectionChange.emit(this.selection),this.onNodeUnselect.emit({originalEvent:e,node:n})):(this.propagateSelectionDown(n,!0),e.rowNode.parent&&this.propagateSelectionUp(n.parent,!0),this.selectionChange.emit(this.selection),this.onNodeSelect.emit({originalEvent:e,node:n})),this.tableService.onSelectionChange()}toggleNodesWithCheckbox(e,n){let i=this.filteredNodes||this.value;this._selection=n&&i?i.slice():[],this.toggleAll(n),n||(this._selection=[],this.selectedKeys={}),this.preventSelectionSetterPropagation=!0,this.selectionChange.emit(this._selection),this.tableService.onSelectionChange(),this.onHeaderCheckboxToggle.emit({originalEvent:e,checked:n})}toggleAll(e){let n=this.filteredNodes||this.value;if(this.selectionKeys){if(n&&n.length){for(let i of n)this.propagateDown(i,e);this.selectionKeysChange.emit(this.selectionKeys)}}else if(n&&n.length)for(let i of n)this.propagateSelectionDown(i,e)}propagateSelectionUp(e,n){if(e.children&&e.children.length){let o=0,r=!1,s=this.dataKey?String(J(e.data,this.dataKey)):null;for(let u of e.children)this.isSelected(u)?o++:u.partialSelected&&(r=!0);if(n&&o==e.children.length)this._selection=[...this.selection||[],e],e.partialSelected=!1,s&&(this.selectedKeys[s]=1);else{if(!n){let u=this.findIndexInSelection(e);u>=0&&(this._selection=this.selection.filter((b,f)=>f!=u),s&&delete this.selectedKeys[s])}r||o>0&&o!=e.children.length?e.partialSelected=!0:e.partialSelected=!1}}let i=e.parent;e.checked=n,i&&this.propagateSelectionUp(i,n)}propagateSelectionDown(e,n){let i=this.findIndexInSelection(e),o=this.dataKey?String(J(e.data,this.dataKey)):null;if(n&&i==-1?(this._selection=[...this.selection||[],e],o&&(this.selectedKeys[o]=1)):!n&&i>-1&&(this._selection=this.selection.filter((r,s)=>s!=i),o&&delete this.selectedKeys[o]),e.partialSelected=!1,e.checked=n,e.children&&e.children.length)for(let r of e.children)this.propagateSelectionDown(r,n)}isSelected(e){return e&&this.selection?this.dataKey?e.hasOwnProperty("checked")?e.checked:this.selectedKeys[J(e.data,this.dataKey)]!==void 0:Array.isArray(this.selection)?this.findIndexInSelection(e)>-1:this.equals(e,this.selection):!1}isNodeSelected(e){return this.selectionMode&&this.selectionKeys?this.selectionKeys[this.nodeKey(e)]?.checked===!0:!1}isNodePartialSelected(e){return this.selectionMode&&this.selectionKeys?this.selectionKeys[this.nodeKey(e)]?.partialChecked===!0:!1}nodeKey(e){return J(e,this.dataKey)||J(e?.data,this.dataKey)}toggleCheckbox(e){let{rowNode:n,check:i,originalEvent:o}=e,r=n.node;this.selectionKeys?(this.propagateDown(r,i),r.parent&&this.propagateUp(r.parent,i),this.selectionKeysChange.emit(this.selectionKeys)):this.toggleNodeWithCheckbox({originalEvent:o,rowNode:n}),this.tableService.onSelectionChange()}propagateDown(e,n){if(n?this.selectionKeys[this.nodeKey(e)]={checked:!0,partialChecked:!1}:delete this.selectionKeys[this.nodeKey(e)],e.children&&e.children.length)for(let i of e.children)this.propagateDown(i,n)}propagateUp(e,n){let i=0,o=!1;for(let s of e.children)this.selectionKeys[this.nodeKey(s)]&&this.selectionKeys[this.nodeKey(s)].checked?i++:this.selectionKeys[this.nodeKey(s)]&&this.selectionKeys[this.nodeKey(s)].partialChecked&&(o=!0);n&&i===e.children.length?this.selectionKeys[this.nodeKey(e)]={checked:!0,partialChecked:!1}:(n||delete this.selectionKeys[this.nodeKey(e)],o||i>0&&i!==e.children.length?this.selectionKeys[this.nodeKey(e)]={checked:!1,partialChecked:!0}:this.selectionKeys[this.nodeKey(e)]={checked:!1,partialChecked:!1});let r=e.parent;r&&this.propagateUp(r,n)}findIndexInSelection(e){let n=-1;if(this.selection&&this.selection.length){for(let i=0;i<this.selection.length;i++)if(this.equals(e,this.selection[i])){n=i;break}}return n}isSingleSelectionMode(){return this.selectionMode==="single"}isMultipleSelectionMode(){return this.selectionMode==="multiple"}equals(e,n){return this.compareSelectionBy==="equals"?Le(e,n):Le(e.data,n.data,this.dataKey)}filter(e,n,i){this.filterTimeout&&clearTimeout(this.filterTimeout),this.isFilterBlank(e)?this.filters[n]&&delete this.filters[n]:this.filters[n]={value:e,matchMode:i},this.filterTimeout=setTimeout(()=>{this._filter(),this.filterTimeout=null},this.filterDelay)}filterGlobal(e,n){this.filter(e,"global",n)}isFilterBlank(e){return e!=null?!!(typeof e=="string"&&e.trim().length==0||Array.isArray(e)&&e.length==0):!0}_filter(){if(this.lazy)this.onLazyLoad.emit(this.createLazyLoadMetadata());else{if(!this.value)return;if(!this.hasFilter())this.filteredNodes=null,this.paginator&&(this.totalRecords=this.value?this.value.length:0);else{let n;if(this.filters.global){if(!this.columns&&!this.globalFilterFields)throw new Error("Global filtering requires dynamic columns or globalFilterFields to be defined.");n=this.globalFilterFields||this.columns}this.filteredNodes=[];let i=this.filterMode==="strict",o=!1;for(let r of this.value){let s=_e({},r),u=!0,b=!1,f;for(let z in this.filters)if(this.filters.hasOwnProperty(z)&&z!=="global"){let E=this.filters[z],A=z,H=E.value,ee=E.matchMode||"startsWith",ve=this.filterService.filters[ee];if(f={filterField:A,filterValue:H,filterConstraint:ve,isStrictMode:i},(i&&!(this.findFilteredNodes(s,f)||this.isFilterMatched(s,f))||!i&&!(this.isFilterMatched(s,f)||this.findFilteredNodes(s,f)))&&(u=!1),!u)break}if(this.filters.global&&!b&&n){let z=_e({},s),E,A=this.filters.global.value,H=this.filterService.filters[this.filters.global.matchMode];f={filterField:E,filterValue:A,filterConstraint:H,isStrictMode:i,globalFilterFieldsArray:n},(i&&(this.findFilteredNodes(z,f)||this.isFilterMatched(z,f))||!i&&(this.isFilterMatched(z,f)||this.findFilteredNodes(z,f)))&&(b=!0,s=z)}let M=u;this.filters.global&&(M=u&&b),M&&this.filteredNodes.push(s),o=o||!u||b||u&&this.filteredNodes.length>0||!b&&this.filteredNodes.length===0}o||(this.filteredNodes=null),this.paginator&&(this.totalRecords=this.filteredNodes?this.filteredNodes.length:this.value?this.value.length:0)}this.cd.markForCheck()}this.first=0;let e=this.filteredNodes||this.value;this.onFilter.emit({filters:this.filters,filteredValue:e}),this.tableService.onUIUpdate(e),this.updateSerializedValue(),this.scrollable&&this.resetScrollTop()}findFilteredNodes(e,n){if(e){let i=!1;if(e.children){let o=[...e.children];e.children=[];for(let r of o){let s=_e({},r);this.isFilterMatched(s,n)&&(i=!0,e.children.push(s))}}if(i)return!0}}isFilterMatched(e,n){let{filterField:i,filterValue:o,filterConstraint:r,isStrictMode:s,globalFilterFieldsArray:u}=n,b=!1,f=M=>r(J(e.data,M),o,this.filterLocale);return b=u?.length?u.some(M=>f(M.field||M)):f(i),(!b||s&&!this.isNodeLeaf(e))&&(b=this.findFilteredNodes(e,{filterField:i,filterValue:o,filterConstraint:r,isStrictMode:s,globalFilterFieldsArray:u})||b),b}isNodeLeaf(e){return e.leaf===!1?!1:!(e.children&&e.children.length)}hasFilter(){let e=!0;for(let n in this.filters)if(this.filters.hasOwnProperty(n)){e=!1;break}return!e}reset(){this._sortField=null,this._sortOrder=1,this._multiSortMeta=null,this.tableService.onSort(null),this.filteredNodes=null,this.filters={},this.first=0,this.lazy?this.onLazyLoad.emit(this.createLazyLoadMetadata()):this.totalRecords=this._value?this._value.length:0}updateEditingCell(e,n,i){this.editingCell=e,this.editingCellData=n,this.editingCellField=i,this.bindDocumentEditListener()}isEditingCellValid(){return this.editingCell&&Pt(this.editingCell,".ng-invalid.ng-dirty").length===0}bindDocumentEditListener(){this.documentEditListener||(this.documentEditListener=this.renderer.listen(this.document,"click",e=>{this.editingCell&&!this.editingCellClick&&this.isEditingCellValid()&&($e(this.editingCell,"p-cell-editing"),this.editingCell=null,this.onEditComplete.emit({field:this.editingCellField,data:this.editingCellData}),this.editingCellField=null,this.editingCellData=null,this.unbindDocumentEditListener()),this.editingCellClick=!1}))}unbindDocumentEditListener(){this.documentEditListener&&(this.documentEditListener(),this.documentEditListener=null)}onDestroy(){this.unbindDocumentEditListener(),this.editingCell=null,this.editingCellField=null,this.editingCellData=null,this.initialized=null}static \u0275fac=(()=>{let e;return function(i){return(e||(e=I(t)))(i||t)}})();static \u0275cmp=S({type:t,selectors:[["p-treeTable"],["p-treetable"],["p-tree-table"]],contentQueries:function(n,i,o){if(n&1&&(v(o,Io,4),v(o,So,4),v(o,ko,4),v(o,Eo,4),v(o,Mo,4),v(o,Do,4),v(o,Bo,4),v(o,Po,4),v(o,Lo,4),v(o,Vo,4),v(o,zo,4),v(o,Fo,4),v(o,No,4),v(o,Ro,4),v(o,Oo,4),v(o,Ho,4),v(o,Ao,4),v(o,Ko,4),v(o,Qo,4),v(o,Uo,4),v(o,Go,4),v(o,jo,4),v(o,$o,4),v(o,qo,4),v(o,Wo,4),v(o,Zo,4),v(o,ne,4)),n&2){let r;m(r=g())&&(i._colGroupTemplate=r.first),m(r=g())&&(i._captionTemplate=r.first),m(r=g())&&(i._headerTemplate=r.first),m(r=g())&&(i._bodyTemplate=r.first),m(r=g())&&(i._footerTemplate=r.first),m(r=g())&&(i._summaryTemplate=r.first),m(r=g())&&(i._emptyMessageTemplate=r.first),m(r=g())&&(i._paginatorLeftTemplate=r.first),m(r=g())&&(i._paginatorRightTemplate=r.first),m(r=g())&&(i._paginatorDropdownItemTemplate=r.first),m(r=g())&&(i._frozenHeaderTemplate=r.first),m(r=g())&&(i._frozenBodyTemplate=r.first),m(r=g())&&(i._frozenFooterTemplate=r.first),m(r=g())&&(i._frozenColGroupTemplate=r.first),m(r=g())&&(i._loadingIconTemplate=r.first),m(r=g())&&(i._reorderIndicatorUpIconTemplate=r.first),m(r=g())&&(i._reorderIndicatorDownIconTemplate=r.first),m(r=g())&&(i._sortIconTemplate=r.first),m(r=g())&&(i._checkboxIconTemplate=r.first),m(r=g())&&(i._headerCheckboxIconTemplate=r.first),m(r=g())&&(i._togglerIconTemplate=r.first),m(r=g())&&(i._paginatorFirstPageLinkIconTemplate=r.first),m(r=g())&&(i._paginatorLastPageLinkIconTemplate=r.first),m(r=g())&&(i._paginatorPreviousPageLinkIconTemplate=r.first),m(r=g())&&(i._paginatorNextPageLinkIconTemplate=r.first),m(r=g())&&(i._loaderTemplate=r.first),m(r=g())&&(i.templates=r)}},viewQuery:function(n,i){if(n&1&&(Q(Jo,5),Q(Xo,5),Q(Yo,5),Q(er,5),Q(tr,5),Q(ir,5)),n&2){let o;m(o=g())&&(i.resizeHelperViewChild=o.first),m(o=g())&&(i.reorderIndicatorUpViewChild=o.first),m(o=g())&&(i.reorderIndicatorDownViewChild=o.first),m(o=g())&&(i.tableViewChild=o.first),m(o=g())&&(i.scrollableViewChild=o.first),m(o=g())&&(i.scrollableFrozenViewChild=o.first)}},hostVars:3,hostBindings:function(n,i){n&2&&(B("data-scrollselectors",".p-treetable-scrollable-body"),h(i.cn(i.cx("root"),i.styleClass)))},inputs:{columns:"columns",styleClass:"styleClass",tableStyle:"tableStyle",tableStyleClass:"tableStyleClass",autoLayout:[2,"autoLayout","autoLayout",T],lazy:[2,"lazy","lazy",T],lazyLoadOnInit:[2,"lazyLoadOnInit","lazyLoadOnInit",T],paginator:[2,"paginator","paginator",T],rows:[2,"rows","rows",$],first:[2,"first","first",$],pageLinks:[2,"pageLinks","pageLinks",$],rowsPerPageOptions:"rowsPerPageOptions",alwaysShowPaginator:[2,"alwaysShowPaginator","alwaysShowPaginator",T],paginatorPosition:"paginatorPosition",paginatorStyleClass:"paginatorStyleClass",paginatorDropdownAppendTo:"paginatorDropdownAppendTo",currentPageReportTemplate:"currentPageReportTemplate",showCurrentPageReport:[2,"showCurrentPageReport","showCurrentPageReport",T],showJumpToPageDropdown:[2,"showJumpToPageDropdown","showJumpToPageDropdown",T],showFirstLastIcon:[2,"showFirstLastIcon","showFirstLastIcon",T],showPageLinks:[2,"showPageLinks","showPageLinks",T],defaultSortOrder:[2,"defaultSortOrder","defaultSortOrder",$],sortMode:"sortMode",resetPageOnSort:[2,"resetPageOnSort","resetPageOnSort",T],customSort:[2,"customSort","customSort",T],selectionMode:"selectionMode",contextMenuSelection:"contextMenuSelection",contextMenuSelectionMode:"contextMenuSelectionMode",dataKey:"dataKey",metaKeySelection:[2,"metaKeySelection","metaKeySelection",T],compareSelectionBy:"compareSelectionBy",rowHover:[2,"rowHover","rowHover",T],loading:[2,"loading","loading",T],loadingIcon:"loadingIcon",showLoader:[2,"showLoader","showLoader",T],scrollable:[2,"scrollable","scrollable",T],scrollHeight:"scrollHeight",virtualScroll:[2,"virtualScroll","virtualScroll",T],virtualScrollItemSize:[2,"virtualScrollItemSize","virtualScrollItemSize",$],virtualScrollOptions:"virtualScrollOptions",virtualScrollDelay:[2,"virtualScrollDelay","virtualScrollDelay",$],frozenWidth:"frozenWidth",frozenColumns:"frozenColumns",resizableColumns:[2,"resizableColumns","resizableColumns",T],columnResizeMode:"columnResizeMode",reorderableColumns:[2,"reorderableColumns","reorderableColumns",T],contextMenu:"contextMenu",rowTrackBy:"rowTrackBy",filters:"filters",globalFilterFields:"globalFilterFields",filterDelay:[2,"filterDelay","filterDelay",$],filterMode:"filterMode",filterLocale:"filterLocale",paginatorLocale:"paginatorLocale",totalRecords:"totalRecords",sortField:"sortField",sortOrder:"sortOrder",multiSortMeta:"multiSortMeta",selection:"selection",value:"value",virtualRowHeight:"virtualRowHeight",selectionKeys:"selectionKeys",showGridlines:[2,"showGridlines","showGridlines",T]},outputs:{selectionChange:"selectionChange",contextMenuSelectionChange:"contextMenuSelectionChange",onFilter:"onFilter",onNodeExpand:"onNodeExpand",onNodeCollapse:"onNodeCollapse",onPage:"onPage",onSort:"onSort",onLazyLoad:"onLazyLoad",sortFunction:"sortFunction",onColResize:"onColResize",onColReorder:"onColReorder",onNodeSelect:"onNodeSelect",onNodeUnselect:"onNodeUnselect",onContextMenuSelect:"onContextMenuSelect",onHeaderCheckboxToggle:"onHeaderCheckboxToggle",onEditInit:"onEditInit",onEditComplete:"onEditComplete",onEditCancel:"onEditCancel",selectionKeysChange:"selectionKeysChange"},standalone:!1,features:[te([mt,Ee,{provide:Wa,useExisting:t},{provide:me,useExisting:t}]),re([F]),k],decls:10,vars:10,consts:[["table",""],["scrollableView",""],["scrollableFrozenView",""],["resizeHelper",""],["reorderIndicatorUp",""],["reorderIndicatorDown",""],[3,"pBind","class",4,"ngIf"],[3,"pt","rows","first","totalRecords","pageLinkSize","styleClass","alwaysShow","rowsPerPageOptions","templateLeft","templateRight","appendTo","currentPageReportTemplate","showFirstLastIcon","dropdownItemTemplate","showCurrentPageReport","showJumpToPageDropdown","showPageLinks","locale","onPageChange",4,"ngIf"],[3,"pBind","class","display",4,"ngIf"],[3,"pBind"],[3,"class",4,"ngIf"],[4,"ngIf"],["data-p-icon","spinner",3,"spin","class",4,"ngIf"],["data-p-icon","spinner",3,"spin"],[4,"ngTemplateOutlet"],[3,"onPageChange","pt","rows","first","totalRecords","pageLinkSize","styleClass","alwaysShow","rowsPerPageOptions","templateLeft","templateRight","appendTo","currentPageReportTemplate","showFirstLastIcon","dropdownItemTemplate","showCurrentPageReport","showJumpToPageDropdown","showPageLinks","locale"],["pTemplate","firstpagelinkicon"],["pTemplate","previouspagelinkicon"],["pTemplate","lastpagelinkicon"],["pTemplate","nextpagelinkicon"],["role","treegrid",3,"pBind","ngClass","ngStyle"],[4,"ngTemplateOutlet","ngTemplateOutletContext"],["role","rowgroup",3,"pBind"],["role","rowgroup",3,"pBind","pTreeTableBody","pTreeTableBodyTemplate"],[3,"ngClass","ttScrollableView","frozen","ngStyle","scrollHeight","pBind",4,"ngIf"],[3,"pBind","ttScrollableView","frozen","scrollHeight","ngStyle"],[3,"ngClass","ttScrollableView","frozen","ngStyle","scrollHeight","pBind"],["data-p-icon","arrow-down",4,"ngIf"],["data-p-icon","arrow-down"],["data-p-icon","arrow-up",4,"ngIf"],["data-p-icon","arrow-up"]],template:function(n,i){n&1&&d(0,ur,4,8,"div",6)(1,mr,2,4,"div",6)(2,kr,5,22,"p-paginator",7)(3,Br,9,29,"div",6)(4,Lr,4,14,"div",6)(5,jr,5,22,"p-paginator",7)(6,qr,2,4,"div",6)(7,Wr,2,5,"div",8)(8,Yr,4,7,"span",8)(9,na,4,7,"span",8),n&2&&(a("ngIf",i.loading&&i.showLoader),c(),a("ngIf",i.captionTemplate||i._captionTemplate),c(),a("ngIf",i.paginator&&(i.paginatorPosition==="top"||i.paginatorPosition=="both")),c(),a("ngIf",!i.scrollable),c(),a("ngIf",i.scrollable),c(),a("ngIf",i.paginator&&(i.paginatorPosition==="bottom"||i.paginatorPosition=="both")),c(),a("ngIf",i.summaryTemplate||i._summaryTemplate),c(),a("ngIf",i.resizableColumns),c(),a("ngIf",i.reorderableColumns),c(),a("ngIf",i.reorderableColumns))},dependencies:()=>[Te,le,se,Be,ht,ne,rt,ct,pt,F,Za,mi],encapsulation:2})}return t})(),mi=(()=>{class t extends fe{tt;treeTableService;columns;template;frozen;serializedNodes;scrollerOptions;subscription;constructor(e,n){super(),this.tt=e,this.treeTableService=n,this.subscription=this.tt.tableService.uiUpdateSource$.subscribe(()=>{this.tt.virtualScroll&&this.cd.detectChanges()})}getScrollerOption(e,n){return this.tt.virtualScroll?(n=n||this.scrollerOptions,n?n[e]:null):null}getRowIndex(e){let n=this.getScrollerOption("getItemOptions");return n?n(e).index:e}onDestroy(){this.subscription&&this.subscription.unsubscribe()}static \u0275fac=function(n){return new(n||t)(Ce(gt),Ce(mt))};static \u0275cmp=S({type:t,selectors:[["","pTreeTableBody",""]],inputs:{columns:[0,"pTreeTableBody","columns"],template:[0,"pTreeTableBodyTemplate","template"],frozen:[2,"frozen","frozen",T],serializedNodes:"serializedNodes",scrollerOptions:"scrollerOptions"},standalone:!1,features:[k],attrs:oa,decls:2,vars:3,consts:[["ngFor","",3,"ngForOf","ngForTrackBy"],[4,"ngIf"],[4,"ngTemplateOutlet","ngTemplateOutletContext"]],template:function(n,i){n&1&&d(0,ca,1,1,"ng-template",0)(1,da,2,5,"ng-container",1),n&2&&(a("ngForOf",i.serializedNodes||i.tt.serializedValue)("ngForTrackBy",i.tt.rowTrackBy),c(),a("ngIf",i.tt.isEmpty()))},dependencies:[He,le,se],encapsulation:2})}return t})(),Za=(()=>{class t extends fe{tt;zone;hostName="TreeTable";columns;frozen;scrollHeaderViewChild;scrollHeaderBoxViewChild;scrollBodyViewChild;scrollTableViewChild;scrollLoadingTableViewChild;scrollFooterViewChild;scrollFooterBoxViewChild;scrollableAlignerViewChild;scroller;headerScrollListener;bodyScrollListener;footerScrollListener;frozenSiblingBody;totalRecordsSubscription;_scrollHeight;preventBodyScrollPropagation;_componentStyle=R(Ee);get scrollHeight(){return this._scrollHeight}set scrollHeight(e){this._scrollHeight=e,e!=null&&(e.includes("%")||e.includes("calc"))&&console.log('Percentage scroll height calculation is removed in favor of the more performant CSS based flex mode, use scrollHeight="flex" instead.')}constructor(e,n){super(),this.tt=e,this.zone=n}onAfterViewInit(){if(Ae(this.platformId)){if(this.frozen)this.scrollableAlignerViewChild&&this.scrollableAlignerViewChild.nativeElement&&(this.scrollableAlignerViewChild.nativeElement.style.height=Bt()+"px");else{(this.tt.frozenColumns||this.tt.frozenBodyTemplate||this.tt._frozenBodyTemplate)&&je(this.el.nativeElement,"p-treetable-unfrozen-view");let e=this.el.nativeElement.previousElementSibling;if(e&&(this.tt.virtualScroll?this.frozenSiblingBody=X(e,".p-scroller-viewport"):this.frozenSiblingBody=X(e,".p-treetable-scrollable-body")),this.scrollHeight){let n=tt();this.scrollHeaderBoxViewChild?.nativeElement&&(this.scrollHeaderBoxViewChild.nativeElement.style.paddingRight=n+"px"),this.scrollFooterBoxViewChild&&this.scrollFooterBoxViewChild.nativeElement&&(this.scrollFooterBoxViewChild.nativeElement.style.paddingRight=n+"px")}}this.bindEvents()}}bindEvents(){Ae(this.platformId)&&this.zone.runOutsideAngular(()=>{this.scrollHeaderViewChild&&this.scrollHeaderViewChild.nativeElement&&(this.headerScrollListener=this.renderer.listen(this.scrollHeaderBoxViewChild?.nativeElement,"scroll",this.onHeaderScroll.bind(this))),this.scrollFooterViewChild&&this.scrollFooterViewChild.nativeElement&&(this.footerScrollListener=this.renderer.listen(this.scrollFooterViewChild.nativeElement,"scroll",this.onFooterScroll.bind(this))),this.frozen||(this.tt.virtualScroll?this.bodyScrollListener=this.renderer.listen((this.scroller?.getElementRef()).nativeElement,"scroll",this.onBodyScroll.bind(this)):this.bodyScrollListener=this.renderer.listen(this.scrollBodyViewChild?.nativeElement,"scroll",this.onBodyScroll.bind(this)))})}unbindEvents(){Ae(this.platformId)&&(this.scrollHeaderViewChild&&this.scrollHeaderViewChild.nativeElement&&this.headerScrollListener&&(this.headerScrollListener(),this.headerScrollListener=null),this.scrollFooterViewChild&&this.scrollFooterViewChild.nativeElement&&this.footerScrollListener&&(this.footerScrollListener(),this.footerScrollListener=null),this.scrollBodyViewChild&&this.scrollBodyViewChild.nativeElement&&this.bodyScrollListener&&(this.bodyScrollListener(),this.bodyScrollListener=null),this.scroller&&this.scroller.getElementRef()&&this.bodyScrollListener&&(this.bodyScrollListener(),this.bodyScrollListener=null))}onHeaderScroll(){let e=this.scrollHeaderViewChild?.nativeElement.scrollLeft;this.scrollBodyViewChild.nativeElement.scrollLeft=e,this.scrollFooterViewChild&&this.scrollFooterViewChild.nativeElement&&(this.scrollFooterViewChild.nativeElement.scrollLeft=e),this.preventBodyScrollPropagation=!0}onFooterScroll(){let e=this.scrollFooterViewChild?.nativeElement.scrollLeft;this.scrollBodyViewChild.nativeElement.scrollLeft=e,this.scrollHeaderViewChild&&this.scrollHeaderViewChild.nativeElement&&(this.scrollHeaderViewChild.nativeElement.scrollLeft=e),this.preventBodyScrollPropagation=!0}onBodyScroll(e){if(this.preventBodyScrollPropagation){this.preventBodyScrollPropagation=!1;return}this.scrollHeaderViewChild&&this.scrollHeaderViewChild.nativeElement&&(this.scrollHeaderBoxViewChild.nativeElement.style.marginLeft=-1*e.target.scrollLeft+"px"),this.scrollFooterViewChild&&this.scrollFooterViewChild.nativeElement&&(this.scrollFooterBoxViewChild.nativeElement.style.marginLeft=-1*e.target.scrollLeft+"px"),this.frozenSiblingBody&&(this.frozenSiblingBody.scrollTop=e.target.scrollTop)}scrollToVirtualIndex(e){this.scroller&&this.scroller.scrollToIndex(e)}scrollTo(e){this.scroller?this.scroller.scrollTo(e):this.scrollBodyViewChild?.nativeElement.scrollTo?this.scrollBodyViewChild.nativeElement.scrollTo(e):(this.scrollBodyViewChild.nativeElement.scrollLeft=e.left,this.scrollBodyViewChild.nativeElement.scrollTop=e.top)}onDestroy(){this.unbindEvents(),this.frozenSiblingBody=null}static \u0275fac=function(n){return new(n||t)(Ce(gt),Ce(Ne))};static \u0275cmp=S({type:t,selectors:[["","ttScrollableView",""]],viewQuery:function(n,i){if(n&1&&(Q(ua,5),Q(ha,5),Q(ma,5),Q(ga,5),Q(fa,5),Q(ba,5),Q(_a,5),Q(ya,5),Q(Ca,5)),n&2){let o;m(o=g())&&(i.scrollHeaderViewChild=o.first),m(o=g())&&(i.scrollHeaderBoxViewChild=o.first),m(o=g())&&(i.scrollBodyViewChild=o.first),m(o=g())&&(i.scrollTableViewChild=o.first),m(o=g())&&(i.scrollLoadingTableViewChild=o.first),m(o=g())&&(i.scrollFooterViewChild=o.first),m(o=g())&&(i.scrollFooterBoxViewChild=o.first),m(o=g())&&(i.scrollableAlignerViewChild=o.first),m(o=g())&&(i.scroller=o.first)}},inputs:{columns:[0,"ttScrollableView","columns"],frozen:[2,"frozen","frozen",T],scrollHeight:"scrollHeight"},standalone:!1,features:[te([Ee]),k],attrs:xa,decls:13,vars:24,consts:[["scrollHeader",""],["scrollHeaderBox",""],["buildInItems",""],["scroller",""],["content",""],["loader",""],["scrollBody",""],["scrollTable",""],["scrollableAligner",""],["scrollFooter",""],["scrollFooterBox",""],[3,"pBind"],[3,"pBind","ngStyle"],[4,"ngTemplateOutlet","ngTemplateOutletContext"],["role","rowgroup",3,"pBind"],[3,"items","styleClass","style","scrollHeight","itemSize","lazy","options","pt","onLazyLoad",4,"ngIf"],[4,"ngIf"],[3,"class","pBind",4,"ngIf"],[3,"onLazyLoad","items","styleClass","scrollHeight","itemSize","lazy","options","pt"],["role","treegrid",3,"pBind","ngClass","ngStyle"],["role","rowgroup",3,"pBind","pTreeTableBody","pTreeTableBodyTemplate","serializedNodes","frozen"],[3,"background-color",4,"ngIf"],[3,"ngClass","ngStyle","pBind"]],template:function(n,i){n&1&&(_(0,"div",11,0)(2,"div",11,1)(4,"table",12),d(5,Sa,1,0,"ng-container",13),_(6,"thead",14),d(7,ka,1,0,"ng-container",13),w()()()(),d(8,La,5,12,"p-scroller",15)(9,za,4,13,"ng-container",16)(10,Ra,5,20,"ng-template",null,2,Re)(12,Aa,8,22,"div",17)),n&2&&(h(i.cx("scrollableHeader")),a("pBind",i.ptm("scrollableHeader")),c(2),h(i.cx("scrollableHeaderBox")),a("pBind",i.ptm("scrollableHeaderBox")),c(2),h(i.cn(i.cx("scrollableHeaderTable"),i.tt.tableStyleClass)),a("pBind",i.ptm("scrollableHeaderTable"))("ngStyle",i.tt.tableStyle),c(),a("ngTemplateOutlet",i.frozen?i.tt.frozenColGroupTemplate||i.tt._frozenColGroupTemplate||i.tt.colGroupTemplate||i.tt._colGroupTemplate:i.tt.colGroupTemplate||i.tt._colGroupTemplate)("ngTemplateOutletContext",j(20,be,i.columns)),c(),h(i.cx("thead")),a("pBind",i.ptm("thead")),c(),a("ngTemplateOutlet",i.frozen?i.tt.frozenHeaderTemplate||i.tt._frozenHeaderTemplate||i.tt.headerTemplate||i.tt._headerTemplate:i.tt.headerTemplate||i.tt._headerTemplate)("ngTemplateOutletContext",j(22,be,i.columns)),c(),a("ngIf",i.tt.virtualScroll),c(),a("ngIf",!i.tt.virtualScroll),c(3),a("ngIf",i.tt.footerTemplate||i.tt._footerTemplate))},dependencies:()=>[Te,le,se,Be,at,F,mi],encapsulation:2})}return t})();var Zc=(()=>{class t extends fe{tt;hostName="TreeTable";bindDirectiveInstance=R(F,{self:!0});onAfterViewChecked(){this.bindDirectiveInstance.setAttrs(this.ptm("toggler"))}rowNode;_componentStyle=R(Ee);constructor(e){super(),this.tt=e}get toggleButtonAriaLabel(){return this.config.translation?this.rowNode.expanded?this.config.translation?.aria?.collapseRow:this.config.translation?.aria?.expandRow:void 0}onClick(e){this.rowNode.node.expanded=!this.rowNode.node.expanded,this.rowNode.node.expanded?this.tt.onNodeExpand.emit({originalEvent:e,node:this.rowNode.node}):this.tt.onNodeCollapse.emit({originalEvent:e,node:this.rowNode.node}),this.tt.updateSerializedValue(),this.tt.tableService.onUIUpdate(this.tt.value),e.preventDefault()}static \u0275fac=function(n){return new(n||t)(Ce(gt))};static \u0275cmp=S({type:t,selectors:[["p-treeTableToggler"],["p-treetabletoggler"],["p-treetable-toggler"]],inputs:{rowNode:"rowNode"},standalone:!1,features:[te([Ee]),re([F]),k],decls:3,vars:14,consts:[["type","button","tabindex","-1","pRipple","",3,"click","pBind"],[4,"ngIf"],[4,"ngTemplateOutlet","ngTemplateOutletContext"],["data-p-icon","chevron-down",3,"pBind",4,"ngIf"],["data-p-icon","chevron-right",3,"pBind",4,"ngIf"],["data-p-icon","chevron-down",3,"pBind"],["data-p-icon","chevron-right",3,"pBind"]],template:function(n,i){n&1&&(_(0,"button",0),O("click",function(r){return i.onClick(r)}),d(1,Ua,3,2,"ng-container",1)(2,ja,1,0,null,2),w()),n&2&&(h(i.cx("toggler")),de("visibility",i.rowNode.node.leaf===!1||i.rowNode.node.children&&i.rowNode.node.children.length?"visible":"hidden")("margin-inline-start",i.rowNode.level*16+"px"),a("pBind",i.ptm("rowToggleButton")),B("data-pc-group-section","rowactionbutton")("aria-label",i.toggleButtonAriaLabel),c(),a("ngIf",!i.tt.togglerIconTemplate&&!i.tt._togglerIconTemplate),c(),a("ngTemplateOutlet",i.tt.togglerIconTemplate||i.tt._togglerIconTemplate)("ngTemplateOutletContext",j(12,be,i.rowNode.node.expanded)))},dependencies:()=>[le,se,We,ot,dt,F],encapsulation:2})}return t})(),Jc=(()=>{class t{static \u0275fac=function(n){return new(n||t)};static \u0275mod=xe({type:t});static \u0275inj=ye({imports:[ue,ui,at,rt,ct,pt,ni,ri,oi,jt,qe,ot,dt,st,Y,Ue,we,Y]})}return t})();export{gt as a,Zc as b,Jc as c};
